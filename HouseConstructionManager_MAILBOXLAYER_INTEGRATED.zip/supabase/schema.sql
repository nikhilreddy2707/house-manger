-- Run this once in Supabase SQL Editor.
-- Production hardening: construction files are private. The app stores storage:// references
-- and resolves short-lived signed URLs only for authenticated users.

create table if not exists public.hcm_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.hcm_user_data enable row level security;

drop policy if exists "Users can view own construction data" on public.hcm_user_data;
create policy "Users can view own construction data" on public.hcm_user_data
  for select using (auth.uid() = user_id);

drop policy if exists "Users can insert own construction data" on public.hcm_user_data;
create policy "Users can insert own construction data" on public.hcm_user_data
  for insert with check (auth.uid() = user_id);

drop policy if exists "Users can update own construction data" on public.hcm_user_data;
create policy "Users can update own construction data" on public.hcm_user_data
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

insert into storage.buckets (id, name, public)
values ('construction-files', 'construction-files', false)
on conflict (id) do update set public = false;

update storage.buckets
set public = false,
    file_size_limit = 10485760,
    allowed_mime_types = array['image/jpeg','image/png','image/webp','application/pdf']
where id = 'construction-files';

drop policy if exists "Users can upload construction files" on storage.objects;
create policy "Users can upload construction files" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Users can view construction files" on storage.objects;
create policy "Users can view construction files" on storage.objects
  for select to authenticated
  using (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Users can update construction files" on storage.objects;
create policy "Users can update construction files" on storage.objects
  for update to authenticated
  using (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Users can delete construction files" on storage.objects;
create policy "Users can delete construction files" on storage.objects
  for delete to authenticated
  using (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);
