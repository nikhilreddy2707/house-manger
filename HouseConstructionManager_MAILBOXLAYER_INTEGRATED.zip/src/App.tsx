import React, { useState, useEffect, Suspense, lazy } from 'react';
import { AuthScreen } from './AuthScreen.js';
import { getUser, signOut } from './api/supabaseClient.js';
import { initializeRemoteApi, flushPendingPersistence } from './api/remoteApi.js';
import {
  SummaryData,
  ConstructionLedgerItem,
  Worker,
  Material,
  MaterialPurchase,
  Expense,
  Payment,
  BudgetItem,
  ConstructionStage,
  ProgressPhoto,
  BillReceipt,
} from './types.js';
import { api } from './api/apiClient.js';
import { Sidebar, NavItemKey } from './components/layout/Sidebar.js';
import { Header } from './components/layout/Header.js';
import { MobileNav } from './components/layout/MobileNav.js';
import { VoiceModal } from './components/voice/VoiceModal.js';
import { AssistantDrawer } from './components/voice/AssistantDrawer.js';
import { ToastContainer, ToastMessage } from './components/common/Toast.js';
import { LoadingSkeleton } from './components/common/LoadingSkeleton.js';
import { X, Eye } from 'lucide-react';

// Every tab below renders exactly one of these at a time, so there is no
// reason to ship all of them (plus their chart libraries) in the initial
// bundle. Lazy-loading keeps first paint fast; each view is fetched only
// the first time its tab is opened.
const DashboardView = lazy(() => import('./components/dashboard/DashboardView.js').then(m => ({ default: m.DashboardView })));
const DailySpendingView = lazy(() => import('./components/daily/DailySpendingView.js').then(m => ({ default: m.DailySpendingView })));
const MonthlySpendingView = lazy(() => import('./components/monthly/MonthlySpendingView.js').then(m => ({ default: m.MonthlySpendingView })));
const ConstructionLedgerView = lazy(() => import('./components/ledger/ConstructionLedgerView.js').then(m => ({ default: m.ConstructionLedgerView })));
const WorkersView = lazy(() => import('./components/workers/WorkersView.js').then(m => ({ default: m.WorkersView })));
const MaterialsView = lazy(() => import('./components/materials/MaterialsView.js').then(m => ({ default: m.MaterialsView })));
const ExpensesView = lazy(() => import('./components/expenses/ExpensesView.js').then(m => ({ default: m.ExpensesView })));
const PaymentsView = lazy(() => import('./components/payments/PaymentsView.js').then(m => ({ default: m.PaymentsView })));
const BudgetView = lazy(() => import('./components/budget/BudgetView.js').then(m => ({ default: m.BudgetView })));
const ProgressView = lazy(() => import('./components/progress/ProgressView.js').then(m => ({ default: m.ProgressView })));
const PhotosView = lazy(() => import('./components/photos/PhotosView.js').then(m => ({ default: m.PhotosView })));
const BillsView = lazy(() => import('./components/bills/BillsView.js').then(m => ({ default: m.BillsView })));
const ReportsView = lazy(() => import('./components/reports/ReportsView.js').then(m => ({ default: m.ReportsView })));
const SettingsView = lazy(() => import('./components/settings/SettingsView.js').then(m => ({ default: m.SettingsView })));

function MainApp() {
  const [currentTab, setCurrentTab] = useState<NavItemKey>('dashboard');
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<{id:string; name:string; location?:string; active?:boolean}[]>([]);
  const [activeProjectId, setActiveProjectId] = useState('');

  // Core Data States
  const [summary, setSummary] = useState<SummaryData | null>(null);
  const [ledger, setLedger] = useState<ConstructionLedgerItem[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [attendance, setAttendance] = useState<any[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [purchases, setPurchases] = useState<MaterialPurchase[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [budgetData, setBudgetData] = useState<any>(null);
  const [progressData, setProgressData] = useState<any>(null);
  const [photos, setPhotos] = useState<ProgressPhoto[]>([]);
  const [bills, setBills] = useState<BillReceipt[]>([]);

  // Modals & Drawers
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [proofViewer, setProofViewer] = useState<{ isOpen: boolean; url: string; title: string }>({
    isOpen: false,
    url: '',
    title: '',
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (
    title: string,
    message?: string,
    type: 'success' | 'error' | 'warning' | 'info' = 'success'
  ) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
    setToasts(prev => [...prev, { id, title, message, type }]);
  };

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Fetch all data
  const refreshData = async () => {
    try {
      const [sum, led, wrk, att, mat, pur, exp, pay, bud, prog, pht, bil] = await Promise.all([
        api.getSummary(),
        api.getLedger(),
        api.getWorkers(),
        api.getAttendance(),
        api.getMaterials(),
        api.getMaterialPurchases(),
        api.getExpenses(),
        api.getPayments(),
        api.getBudget(),
        api.getProgress(),
        api.getPhotos(),
        api.getBills(),
      ]);

      setSummary(sum);
      setLedger(led);
      const projectList = await api.getProjects();
      setProjects(projectList);
      setActiveProjectId(sum.house.id);
      setWorkers(wrk);
      setAttendance(att);
      setMaterials(mat);
      setPurchases(pur);
      setExpenses(exp);
      setPayments(pay);
      setBudgetData(bud);
      setProgressData(prog);
      setPhotos(pht);
      setBills(bil);
    } catch (err) {
      console.error('Failed to load application data:', err);
      showToast('Data Load Error', 'Could not load your construction data. Check your Supabase setup and try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleSwitchProject = async (projectId: string) => {
    if (projectId === activeProjectId) return;
    try {
      setLoading(true);
      await api.switchProject(projectId);
      setCurrentTab('dashboard');
      await refreshData();
      showToast('Project Switched', 'Showing data only for the selected construction project.', 'success');
    } catch (err) {
      setLoading(false);
      showToast('Project Switch Failed', 'Could not switch construction project.', 'error');
    }
  };

  const handleCreateProject = async () => {
    const name = window.prompt('Enter a project name:', 'New Construction Project');
    if (!name?.trim()) return;
    try {
      setLoading(true);
      const house = await api.createProject({ name: name.trim() });
      setCurrentTab('dashboard');
      await refreshData();
      showToast('Project Created', `${house.name} is ready with empty data.`, 'success');
    } catch {
      setLoading(false);
      showToast('Project Creation Failed', 'Could not create the new project.', 'error');
    }
  };

  const handleSelectTab = (tab: NavItemKey) => {
    if (tab === 'voice') {
      setIsVoiceOpen(true);
      return;
    }
    setCurrentTab(tab);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Quick Action Handler
  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'add-worker':
        setCurrentTab('workers');
        break;
      case 'add-material':
        setCurrentTab('materials');
        break;
      case 'add-expense':
        setCurrentTab('expenses');
        break;
      case 'record-payment':
        setCurrentTab('payments');
        break;
      case 'add-photo':
        setCurrentTab('progress');
        break;
      case 'add-bill':
        setCurrentTab('bills');
        break;
      default:
        break;
    }
  };

  const handleResetDemo = async () => {
    try {
      await api.resetDemo();
      showToast('Demo Reset', 'Database reset to initial September 2026 baseline records.', 'info');
      await refreshData();
    } catch (err) {
      showToast('Reset Failed', 'Could not reset demo database', 'error');
    }
  };

  const handleMarkPaymentPaid = async (id: string) => {
    try {
      await api.markPaymentPaid(id);
      showToast('Payment Settled', 'Payment marked as completed and added to ledger.', 'success');
      await refreshData();
    } catch (err) {
      showToast('Error', 'Could not update payment status', 'error');
    }
  };

  const handleDeleteLedgerItem = async (id: string) => {
    try {
      const result = await (api as any).deleteLedgerItem(id);
      if (!result?.success) { showToast('Record Not Found', 'The transaction could not be found.', 'warning'); return; }
      showToast('Record Deleted', `${result.type === 'material' ? 'Material purchase' : 'Expense'} removed and totals recalculated.`, 'info');
      await refreshData();
    } catch (err) {
      showToast('Error', 'Could not delete ledger record', 'error');
    }
  };

  const handleDeleteExpense = async (id: string) => {
    try {
      await api.deleteExpense(id);
      showToast('Record Deleted', 'Expense removed and budget recalculated.', 'info');
      await refreshData();
    } catch (err) {
      showToast('Error', 'Could not delete expense', 'error');
    }
  };

  const handleUpdateStage = async (id: string, percentage: number, status?: string, notes?: string) => {
    try {
      await api.updateStage(id, percentage, status, notes);
      showToast('Progress Updated', 'Stage completion updated successfully.', 'success');
      await refreshData();
    } catch (err) {
      showToast('Error', 'Could not update stage progress', 'error');
    }
  };

  const handleAddPhoto = async (photo: Partial<ProgressPhoto>) => {
    try {
      await api.addPhoto(photo);
      showToast('Photo Added', 'Construction milestone photo uploaded to gallery.', 'success');
      await refreshData();
    } catch (err) {
      showToast('Error', 'Could not save photo', 'error');
    }
  };

  const handleAddBill = async (bill: Partial<BillReceipt>) => {
    try {
      await api.addBill(bill);
      showToast('Bill Saved', 'Invoice receipt stored and verified.', 'success');
      await refreshData();
    } catch (err) {
      showToast('Error', 'Could not save bill', 'error');
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100 antialiased font-sans">
      {/* Desktop Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        onOpenVoice={() => setIsVoiceOpen(true)}
        healthScore={summary?.healthScore || 82}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Header */}
        <Header
          onOpenVoice={() => setIsVoiceOpen(true)}
          onOpenAssistant={() => setIsAssistantOpen(true)}
          onQuickAction={handleQuickAction}
          onSearch={term => {
            if (term.trim() && currentTab !== 'ledger') {
              setCurrentTab('ledger');
            }
          }}
          onResetDemo={handleResetDemo}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          projects={projects}
          activeProjectId={activeProjectId}
          onSwitchProject={handleSwitchProject}
          onCreateProject={handleCreateProject}
        />

        {/* Dynamic Page Content */}
        <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto pb-24 lg:pb-12">
          {loading ? (
            <div className="py-12">
              <LoadingSkeleton rows={5} height="h-28" />
            </div>
          ) : !summary ? (
            <div className="text-center py-20 text-slate-400">
              <p>Unable to load construction dashboard.</p>
              <button
                onClick={refreshData}
                className="mt-4 px-4 py-2 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs"
              >
                Retry
              </button>
            </div>
          ) : (
            <Suspense
              fallback={
                <div className="py-12">
                  <LoadingSkeleton rows={5} height="h-28" />
                </div>
              }
            >
              {currentTab === 'dashboard' && (
                <DashboardView
                  summary={summary}
                  ledger={ledger}
                  payments={payments}
                  workers={workers}
                  attendance={attendance}
                  materials={materials}
                  purchases={purchases}
                  onOpenVoice={() => setIsVoiceOpen(true)}
                  onNavigate={handleSelectTab}
                  onMarkPaid={handleMarkPaymentPaid}
                />
              )}

              {currentTab === 'daily' && (
                <DailySpendingView ledger={ledger} summary={summary} />
              )}

              {currentTab === 'workers' && (
                <WorkersView
                  workers={workers}
                  attendance={attendance}
                  onAddWorker={async worker => {
                    await api.addWorker(worker);
                    showToast('Worker Added', `${worker.name} registered successfully.`, 'success');
                    refreshData();
                  }}
                  onRecordAttendance={async items => {
                    await api.recordBulkAttendance(items);
                    showToast('Attendance Saved', 'Wages synchronized with ledger.', 'success');
                    refreshData();
                  }}
                  onUpdateWorker={async (id, updates) => {
                    await api.updateWorker(id, updates);
                    refreshData();
                  }}
                />
              )}

              {currentTab === 'materials' && (
                <MaterialsView
                  materials={materials}
                  purchases={purchases}
                  onAddPurchase={async p => {
                    await api.addMaterialPurchase(p);
                    showToast('Purchase Saved', `Added ${p.quantity} ${p.unit} of ${p.materialName}.`, 'success');
                    refreshData();
                  }}
                />
              )}

              {currentTab === 'ledger' && (
                <ConstructionLedgerView
                  ledger={ledger}
                  onDelete={handleDeleteLedgerItem}
                  onAddExpense={() => setCurrentTab('expenses')}
                  onViewReceipt={(url, title) => setProofViewer({ isOpen: true, url, title })}
                />
              )}

              {currentTab === 'expenses' && (
                <ExpensesView
                  expenses={expenses}
                  onAddExpense={async e => {
                    let uploadedRef = '';
                    try {
                      if (e.receiptFile instanceof File) {
                        uploadedRef = await api.uploadFile(e.receiptFile);
                        e.receiptUrl = uploadedRef;
                        delete e.receiptFile;
                      }
                      await api.addExpense(e);
                      showToast('Expense Recorded', `₹${e.amount} recorded for ${e.category}.`, 'success');
                      await refreshData();
                    } catch (err: any) {
                      if (uploadedRef) await (api as any).deleteFile(uploadedRef).catch(() => {});
                      showToast('Expense Failed', err?.message || 'Could not save the expense.', 'error');
                    }
                  }}
                  onDeleteExpense={handleDeleteExpense}
                  onViewProof={(url, title) => setProofViewer({ isOpen: true, url, title })}
                />
              )}

              {currentTab === 'payments' && (
                <PaymentsView
                  payments={payments}
                  onMarkPaid={handleMarkPaymentPaid}
                  onRecordPayment={async p => {
                    let uploadedRef = '';
                    try {
                      if (p.paymentProofFile instanceof File) {
                        uploadedRef = await api.uploadFile(p.paymentProofFile);
                        p.paymentProofUrl = uploadedRef;
                        delete p.paymentProofFile;
                      }
                      await api.addPayment(p);
                      if (p.status === 'Pending') {
                        showToast('Payment Due Saved', `₹${Number(p.amount).toLocaleString('en-IN')} is now tracked as pending for ${p.recipient}.`, 'success');
                      } else {
                        showToast('Payment Logged', `₹${Number(p.amount).toLocaleString('en-IN')} recorded for ${p.recipient}.`, 'success');
                      }
                      await refreshData();
                    } catch (err: any) {
                      if (uploadedRef) await (api as any).deleteFile(uploadedRef).catch(() => {});
                      showToast('Payment Failed', err?.message || 'Could not save the payment and receipt.', 'error');
                    }
                  }}
                  onViewProof={(url, title) => setProofViewer({ isOpen: true, url, title })}
                  onAttachProof={async (paymentId, file) => {
                    try {
                      await (api as any).attachPaymentProof(paymentId, file);
                      showToast('Receipt Attached', 'Payment proof was securely uploaded.', 'success');
                      await refreshData();
                    } catch (err: any) {
                      showToast('Receipt Upload Failed', err?.message || 'Could not attach the payment receipt.', 'error');
                      throw err;
                    }
                  }}
                />
              )}

              {currentTab === 'budget' && budgetData && (
                <BudgetView budgetData={budgetData} />
              )}

              {currentTab === 'progress' && progressData && (
                <ProgressView
                  progressData={progressData}
                  onUpdateStage={handleUpdateStage}
                />
              )}

              {currentTab === 'reports' && (
                <ReportsView summary={summary} ledger={ledger} showToast={showToast} />
              )}

              {currentTab === 'bills' && (
                <BillsView
                  bills={bills}
                  onAddBill={handleAddBill}
                  onViewProof={(url, title) => setProofViewer({ isOpen: true, url, title })}
                  showToast={showToast}
                />
              )}

              {currentTab === 'settings' && (
                <SettingsView
                  house={summary.house}
                  onResetDemo={handleResetDemo}
                  onUpdateProject={async updates => { await api.updateProject(updates); await refreshData(); }}
                  showToast={showToast}
                />
              )}
            </Suspense>
          )}
        </main>
      </div>

      {/* Centerpiece Telugu Voice Assistant Modal */}
      <VoiceModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onSuccess={() => {
          refreshData();
        }}
        showToast={showToast}
      />

      {/* Natural Language Assistant Drawer */}
      <AssistantDrawer
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
      />

      {/* Mobile Bottom Navigation with Floating Glowing Mic Button */}
      <MobileNav
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        onOpenVoice={() => setIsVoiceOpen(true)}
        onOpenMoreMenu={() => setIsMobileMenuOpen(true)}
        onQuickAdd={() => handleQuickAction('add-expense')}
      />

      {/* Mobile Offcanvas Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex bg-slate-950/80 backdrop-blur-md lg:hidden">
          <div className="w-4/5 max-w-xs bg-slate-900 border-r border-slate-800 h-full p-5 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🏠</span>
                  <span className="font-extrabold text-sm text-white">House Manager</span>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mb-4 rounded-2xl bg-slate-950 border border-slate-800 p-3">
                <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-2">Current Project</p>
                <select
                  value={activeProjectId}
                  onChange={async e => {
                    if (e.target.value === '__create__') await handleCreateProject();
                    else await handleSwitchProject(e.target.value);
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-100 outline-none"
                >
                  {projects.map(project => <option key={project.id} value={project.id}>{project.name}</option>)}
                  <option value="__create__">＋ Create New Project</option>
                </select>
              </div>

              <div className="space-y-1">
                {[
                  { key: 'dashboard', label: '🏠 Dashboard' },
                  { key: 'daily', label: '📅 Daily Work' },
                  { key: 'workers', label: '👷 Workers' },
                  { key: 'materials', label: '🧱 Materials' },
                  { key: 'expenses', label: '💰 Expenses' },
                  { key: 'ledger', label: '📒 Money Ledger' },
                  { key: 'payments', label: '💳 Payments' },
                  { key: 'budget', label: '💵 Budget' },
                  { key: 'progress', label: '🏗️ Construction Progress' },
                  { key: 'reports', label: '📊 Reports' },
                  { key: 'bills', label: '🧾 Bills & Receipts' },
                  { key: 'settings', label: '⚙️ Settings' },
                ].map(item => (
                  <button
                    key={item.key}
                    onClick={() => handleSelectTab(item.key as NavItemKey)}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold transition-colors ${
                      currentTab === item.key
                        ? 'bg-amber-500/15 text-amber-400 border border-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsAssistantOpen(true);
                }}
                className="w-full py-2.5 bg-slate-800 text-amber-400 font-bold rounded-xl text-xs flex items-center justify-center gap-2"
              >
                <span>🤖</span> Ask Telugu Assistant
              </button>
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)} />
        </div>
      )}

      {/* Proof / Receipt Lightbox */}
      {proofViewer.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in">
          <div className="relative max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <h4 className="font-extrabold text-sm text-slate-100">{proofViewer.title}</h4>
              <button
                onClick={() => setProofViewer({ isOpen: false, url: '', title: '' })}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 bg-slate-950 flex items-center justify-center h-[70vh] overflow-hidden">
              {proofViewer.url.toLowerCase().split('?')[0].endsWith('.pdf') ? (
                <iframe
                  src={proofViewer.url}
                  title={proofViewer.title}
                  className="w-full h-full rounded-xl bg-white"
                />
              ) : (
                <img
                  src={proofViewer.url}
                  alt={proofViewer.title}
                  className="max-h-full max-w-full object-contain rounded-xl shadow-lg"
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    <button onClick={async()=>{await flushPendingPersistence().catch(()=>{}); await signOut();location.reload();}} className="fixed bottom-4 right-4 z-40 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold shadow-xl">Logout</button>
</div>
  );
}

export function App() {
  const [authChecked, setAuthChecked] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const user = await getUser();
        if (user) {
          try {
            await initializeRemoteApi(user);
          } catch (cloudError: any) {
            // Authentication is still valid even if the optional cloud data table
            // has not been created yet. Keep the user signed in so the app does not
            // bounce back to the login screen.
            console.error('Cloud data initialization failed:', cloudError);
            setAuthError('Cloud database is not initialized. Run both supabase/schema.sql and supabase/normalized_schema.sql from this project in Supabase SQL Editor.');
          }
          setAuthenticated(true);
        }
      } catch (e: any) {
        console.error('Authentication check failed:', e);
      } finally {
        setAuthChecked(true);
      }
    })();
  }, []);

  if (!authChecked) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-amber-400 font-bold">Loading secure workspace…</div>;
  if (!authenticated) return <AuthScreen />;
  return (
    <>
      {authError && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-[100] max-w-xl w-[calc(100%-2rem)] rounded-xl border border-amber-500/30 bg-slate-900 px-4 py-3 text-xs text-amber-200 shadow-2xl">
          {authError}
        </div>
      )}
      <MainApp />
    </>
  );
}
