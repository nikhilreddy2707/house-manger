import { validateUpload } from './validation.js';
import { inflateWorkspace, type WorkspaceRecord } from './dataModel.js';
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

function assertSupabaseConfig() {
  if (!SUPABASE_URL || !SUPABASE_KEY) throw new Error('Supabase configuration is missing. Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY.');
}

const ACCESS_KEY = 'hcm_supabase_access_token';
const REFRESH_KEY = 'hcm_supabase_refresh_token';

export type AuthUser = { id: string; email?: string; user_metadata?: Record<string, any> };
export type Session = { access_token: string; refresh_token?: string; user: AuthUser };

const headers = (token?: string) => { assertSupabaseConfig(); return ({
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${token || SUPABASE_KEY}`,
  'Content-Type': 'application/json',
}); }

export function getAccessToken() { return localStorage.getItem(ACCESS_KEY); }
export function setSession(s: Session | null) {
  if (!s) { localStorage.removeItem(ACCESS_KEY); localStorage.removeItem(REFRESH_KEY); return; }
  localStorage.setItem(ACCESS_KEY, s.access_token);
  if (s.refresh_token) localStorage.setItem(REFRESH_KEY, s.refresh_token);
}

async function auth(path: string, body: any) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/${path}`, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error_description || data.msg || data.message || 'Authentication failed');
  return data;
}

export async function signUp(email: string, password: string, name: string) {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = name.trim();
  if (!cleanName) throw new Error('Full name is required.');
  if (password.length < 8) throw new Error('Use a password with at least 8 characters.');
  const data = await auth('signup', { email: cleanEmail, password, data: { full_name: cleanName } });
  if (data.access_token) setSession(data);
  return data;
}
export async function signIn(email: string, password: string) {
  const cleanEmail = email.trim().toLowerCase();
  const data = await auth('token?grant_type=password', { email: cleanEmail, password });
  setSession(data); return data;
}
export async function signOut() {
  const token = getAccessToken();
  if (token) await fetch(`${SUPABASE_URL}/auth/v1/logout`, { method: 'POST', headers: headers(token) }).catch(() => {});
  setSession(null);
}
export async function getUser(): Promise<AuthUser | null> {
  let token = getAccessToken(); if (!token) return null;
  let res = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: headers(token) });
  if (res.status === 401) {
    const refresh = localStorage.getItem(REFRESH_KEY);
    if (refresh) { try { const data = await auth('token?grant_type=refresh_token', { refresh_token: refresh }); setSession(data); token = data.access_token; res = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: headers(token) }); } catch {} }
  }
  if (!res.ok) { setSession(null); return null; }
  return res.json();
}
export async function resetPassword(email: string) {
  return auth('recover', { email, redirect_to: window.location.origin });
}


export async function loadNormalizedState(userId: string) {
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/hcm_records?user_id=eq.${encodeURIComponent(userId)}&select=project_id,entity_type,record_id,data`, { headers: headers(token || undefined) });
  if (res.status === 404) throw new Error('NORMALIZED_SCHEMA_MISSING');
  if (!res.ok) throw new Error('Unable to load normalized cloud data');
  const rows = await res.json();
  return inflateWorkspace(rows as WorkspaceRecord[]);
}

export async function listNormalizedRecords(userId: string): Promise<WorkspaceRecord[]> {
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/hcm_records?user_id=eq.${encodeURIComponent(userId)}&select=project_id,entity_type,record_id,data`, { headers: headers(token || undefined) });
  if (res.status === 404) throw new Error('NORMALIZED_SCHEMA_MISSING');
  if (!res.ok) throw new Error('Unable to list normalized cloud data');
  return await res.json();
}

export async function upsertNormalizedRecords(rows: WorkspaceRecord[]) {
  if (!rows.length) return;
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/hcm_records?on_conflict=user_id,project_id,entity_type,record_id`, {
    method: 'POST', headers: { ...headers(token || undefined), Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify(rows.map(row => ({ ...row, updated_at: new Date().toISOString() }))),
  });
  if (res.status === 404) throw new Error('NORMALIZED_SCHEMA_MISSING');
  if (!res.ok) { const t = await res.text(); throw new Error(t || 'Unable to save normalized cloud data'); }
}

export async function deleteNormalizedRecords(userId: string, rows: Pick<WorkspaceRecord,'project_id'|'entity_type'|'record_id'>[]) {
  for (const row of rows) {
    const token = getAccessToken();
    const query = `user_id=eq.${encodeURIComponent(userId)}&project_id=eq.${encodeURIComponent(row.project_id)}&entity_type=eq.${encodeURIComponent(row.entity_type)}&record_id=eq.${encodeURIComponent(row.record_id)}`;
    const res = await fetch(`${SUPABASE_URL}/rest/v1/hcm_records?${query}`, { method: 'DELETE', headers: headers(token || undefined) });
    if (res.status === 404) throw new Error('NORMALIZED_SCHEMA_MISSING');
    if (!res.ok) throw new Error('Unable to delete normalized cloud record');
  }
}

export async function loadCloudState(userId: string) {
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/hcm_user_data?user_id=eq.${encodeURIComponent(userId)}&select=data`, { headers: headers(token || undefined) });
  if (!res.ok) throw new Error('Unable to load cloud data');
  const rows = await res.json(); return rows[0]?.data || null;
}
export async function saveCloudState(userId: string, data: any, opts?: { keepalive?: boolean }) {
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/hcm_user_data?on_conflict=user_id`, {
    method: 'POST', headers: { ...headers(token || undefined), Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify({ user_id: userId, data, updated_at: new Date().toISOString() }),
    keepalive: opts?.keepalive,
  });
  if (!res.ok) { const t = await res.text(); throw new Error(t || 'Unable to save cloud data'); }
}


async function optimizeImage(file: File): Promise<File> {
  if (!file.type.startsWith('image/') || file.size <= 1024 * 1024 || typeof document === 'undefined') return file;
  const bitmap = await createImageBitmap(file);
  const maxSide = 1800;
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext('2d');
  if (!ctx) return file;
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/webp', 0.82));
  bitmap.close();
  return blob ? new File([blob], file.name.replace(/\.[^.]+$/, '.webp'), { type: 'image/webp', lastModified: Date.now() }) : file;
}

export const STORAGE_REF_PREFIX = 'storage://construction-files/';

export async function resolveFileUrl(ref: string, expiresIn = 3600): Promise<string> {
  assertSupabaseConfig();
  if (!ref) return '';
  let path = '';
  if (ref.startsWith(STORAGE_REF_PREFIX)) path = ref.slice(STORAGE_REF_PREFIX.length);
  else {
    const marker = '/storage/v1/object/public/construction-files/';
    const idx = ref.indexOf(marker);
    if (idx >= 0) path = decodeURIComponent(ref.slice(idx + marker.length));
    else return ref;
  }
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/storage/v1/object/sign/construction-files`, {
    method: 'POST',
    headers: { ...headers(token || undefined), 'Content-Type': 'application/json' },
    body: JSON.stringify({ expiresIn, paths: [path] }),
  });
  if (!res.ok) throw new Error('Unable to create a secure file URL');
  const data = await res.json();
  const signed = Array.isArray(data) ? data[0]?.signedURL : data?.signedURL || data?.signedURLs?.[0]?.signedURL;
  if (!signed) throw new Error('Secure file URL was not returned');
  return signed.startsWith('http') ? signed : `${SUPABASE_URL}/storage/v1${signed}`;
}


export async function deleteFile(ref: string) {
  assertSupabaseConfig();
  if (!ref?.startsWith(STORAGE_REF_PREFIX)) return;
  const path = ref.slice(STORAGE_REF_PREFIX.length);
  const token = getAccessToken();
  const res = await fetch(`${SUPABASE_URL}/storage/v1/object/construction-files/${path.split('/').map(encodeURIComponent).join('/')}`, { method: 'DELETE', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${token}` } });
  if (!res.ok && res.status !== 404) throw new Error('Unable to remove uploaded file');
}

export async function scanBillWithOcr(file: File) {
  assertSupabaseConfig();
  validateUpload(file);
  const endpoint = import.meta.env.VITE_OCR_ENDPOINT;
  if (!endpoint) throw new Error('OCR service is not configured. Set VITE_OCR_ENDPOINT before using bill scanning.');
  const form = new FormData();
  form.append('file', file);
  const token = getAccessToken();
  const res = await fetch(endpoint, { method: 'POST', headers: token ? { Authorization: `Bearer ${token}` } : undefined, body: form });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.message || data?.error || 'OCR service failed');
  return data;
}

export async function uploadFile(userId: string, file: File) {
  assertSupabaseConfig();
  validateUpload(file);
  file = await optimizeImage(file);
  validateUpload(file);
  const token = getAccessToken();
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const path = `${userId}/${Date.now()}-${safe}`;
  const res = await fetch(`${SUPABASE_URL}/storage/v1/object/construction-files/${path}`, {
    method: 'POST', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${token}`, 'x-upsert': 'false', 'Content-Type': file.type || 'application/octet-stream' }, body: file
  });
  if (!res.ok) { const t = await res.text(); throw new Error(t || 'File upload failed'); }
  return `${STORAGE_REF_PREFIX}${path}`;
}
