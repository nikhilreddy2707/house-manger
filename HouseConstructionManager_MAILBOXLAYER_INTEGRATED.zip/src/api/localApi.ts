import {
  SummaryData, ConstructionLedgerItem, Worker, Material, MaterialPurchase, Expense, Payment,
  BudgetItem, ConstructionStage, ProgressPhoto, BillReceipt, VoiceExtractedData, ExpenseCategory, House
} from '../types.js';
import { initialSeed } from './seedData.js';
import { safeAmount, safeCategory } from './validation.js';

const clone = <T,>(value: T): T => structuredClone(value);
const BASE_KEY = 'house-construction-manager-workspace-v3';
let storageKey = BASE_KEY;
const today = () => { const d = new Date(); const y = d.getFullYear(); const m = String(d.getMonth() + 1).padStart(2, '0'); const day = String(d.getDate()).padStart(2, '0'); return `${y}-${m}-${day}`; };
const id = (prefix: string) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

type State = {
  house: House;
  workers: Worker[];
  attendance: any[];
  materials: Material[];
  purchases: MaterialPurchase[];
  expenses: Expense[];
  payments: Payment[];
  budgets: BudgetItem[];
  stages: ConstructionStage[];
  photos: ProgressPhoto[];
  bills: BillReceipt[];
};

type Workspace = {
  version: 3;
  activeProjectId: string;
  projects: Record<string, State>;
};

function emptyState(projectId = id('project')): State {
  const start = today();
  return {
    house: {
      id: projectId,
      name: 'My Construction Project',
      ownerName: '',
      location: '',
      totalBudget: 0,
      spentAmount: 0,
      startDate: start,
      expectedEndDate: '',
      currentProgressPct: 0,
      currency: 'INR',
    },
    workers: [], attendance: [], materials: [], purchases: [], expenses: [], payments: [],
    budgets: [], stages: [], photos: [], bills: []
  };
}

function demoState(projectId = id('project')): State {
  const s = clone(initialSeed) as any;
  const remap = (prefix: string, arr: any[]) => arr.map((x: any) => ({ ...x, id: id(prefix), houseId: projectId }));
  const workers = remap('w', s.workers);
  const workerIdMap = new Map(s.workers.map((w: any, i: number) => [w.id, workers[i].id]));
  const attendance = remap('att', s.attendance).map((a: any) => ({ ...a, workerId: workerIdMap.get(a.workerId) || a.workerId }));
  const materials = remap('mat', s.materials);
  const materialIdMap = new Map(s.materials.map((m: any, i: number) => [m.id, materials[i].id]));
  const purchases = remap('mp', s.purchases).map((p: any) => ({ ...p, materialId: materialIdMap.get(p.materialId) || p.materialId }));
  return {
    house: { ...s.house, id: projectId },
    workers,
    attendance,
    materials,
    purchases,
    expenses: remap('exp', s.expenses),
    payments: remap('pay', s.payments),
    budgets: remap('bud', s.budgets),
    stages: remap('stage', s.stages),
    photos: remap('photo', s.photos),
    bills: remap('bill', s.bills),
  };
}

function normalizeProject(raw: any, projectId?: string): State {
  const base = emptyState(projectId || raw?.house?.id || id('project'));
  if (!raw || typeof raw !== 'object') return base;
  const house = { ...base.house, ...(raw.house || {}), id: projectId || raw.house?.id || base.house.id };
  return {
    ...base, ...raw, house,
    workers: Array.isArray(raw.workers) ? raw.workers : [],
    attendance: Array.isArray(raw.attendance) ? raw.attendance : [],
    materials: Array.isArray(raw.materials) ? raw.materials : [],
    purchases: Array.isArray(raw.purchases) ? raw.purchases : [],
    expenses: Array.isArray(raw.expenses) ? raw.expenses : [],
    payments: Array.isArray(raw.payments) ? raw.payments : [],
    budgets: Array.isArray(raw.budgets) ? raw.budgets : [],
    stages: Array.isArray(raw.stages) ? raw.stages : [],
    photos: Array.isArray(raw.photos) ? raw.photos : [],
    bills: Array.isArray(raw.bills) ? raw.bills : [],
  };
}

function migrate(raw: any): Workspace {
  if (raw?.version === 3 && raw.projects && typeof raw.projects === 'object') {
    const projects: Record<string, State> = {};
    for (const [pid, value] of Object.entries(raw.projects)) projects[pid] = normalizeProject(value, pid);
    const ids = Object.keys(projects);
    const active = ids.includes(raw.activeProjectId) ? raw.activeProjectId : ids[0];
    if (active) return { version: 3, activeProjectId: active, projects };
  }
  // Legacy v2/user JSON is migrated into a single project. This prevents old demo data
  // from being silently mixed with newly-created projects.
  if (raw?.house || raw?.workers || raw?.expenses) {
    const pid = raw.house?.id || id('project');
    const legacy = normalizeProject(raw, pid);
    // Strip only the known v1/v2 demo records. User-created records have generated ids
    // and are preserved, so upgrading the app does not wipe genuine user data.
    legacy.workers = legacy.workers.filter(w => !/^w_00[1-5]$/.test(w.id));
    legacy.attendance = legacy.attendance.filter(a => !String(a.id).startsWith('att_seed_'));
    legacy.materials = legacy.materials.filter(m => !/^mat_00[1-4]$/.test(m.id));
    legacy.purchases = legacy.purchases.filter(p => !/^mp_00[1-4]$/.test(p.id));
    legacy.expenses = legacy.expenses.filter(e => !/^exp_00[1-5]$/.test(e.id));
    legacy.payments = legacy.payments.filter(p => !/^pay_00[1-2]$/.test(p.id));
    legacy.budgets = legacy.budgets.filter(b => !/^bud_[1-7]$/.test(b.id));
    legacy.stages = legacy.stages.filter(s => !/^stage_[1-6]$/.test(s.id));
    legacy.photos = legacy.photos.filter(x => !String(x.id).startsWith('photo_'));
    legacy.bills = legacy.bills.filter(x => !String(x.id).startsWith('bill_'));
    legacy.house = { ...legacy.house, id: pid, spentAmount: 0, currentProgressPct: 0 };
    return { version: 3, activeProjectId: pid, projects: { [pid]: legacy } };
  }
  const pid = id('project');
  return { version: 3, activeProjectId: pid, projects: { [pid]: emptyState(pid) } };
}

let workspace: Workspace = (() => {
  try {
    const raw = localStorage.getItem(storageKey);
    return migrate(raw ? JSON.parse(raw) : null);
  } catch {
    const pid = id('project');
    return { version: 3, activeProjectId: pid, projects: { [pid]: emptyState(pid) } };
  }
})();
let state: State = workspace.projects[workspace.activeProjectId] || emptyState(workspace.activeProjectId);
let persistenceHook: ((snapshot: Workspace) => void | Promise<void>) | null = null;

function workspaceSnapshot(): Workspace {
  workspace.projects[workspace.activeProjectId] = clone(state);
  return clone(workspace);
}

// Writes to localStorage synchronously (so a refresh never loses data that's
// already on disk) and hands the latest snapshot to the remote persistence
// hook immediately. The hook (see remoteApi.ts) owns its own debounce and a
// flush-on-close safety net, so there is exactly one place that decides when
// the cloud write actually happens instead of two independent timers racing
// each other.
function persist() {
  workspace.projects[workspace.activeProjectId] = clone(state);
  try { localStorage.setItem(storageKey, JSON.stringify(workspace)); } catch { /* storage is optional */ }
  try { persistenceHook?.(workspaceSnapshot()); } catch { /* network errors are handled by remoteApi */ }
}

export function setStorageScope(userId: string | null) {
  // Every authenticated account gets an isolated browser cache. Never reuse the
  // previous account's workspace when a second customer signs in on the same browser.
  storageKey = userId ? `${BASE_KEY}:${userId}` : BASE_KEY;
  try {
    const raw = userId ? localStorage.getItem(storageKey) : null;
    workspace = migrate(raw ? JSON.parse(raw) : null);
    state = workspace.projects[workspace.activeProjectId] || emptyState(workspace.activeProjectId);
  } catch {
    const pid = id('project');
    workspace = { version: 3, activeProjectId: pid, projects: { [pid]: emptyState(pid) } };
    state = workspace.projects[pid];
  }
}

export function clearScopedStorage(userId: string | null) {
  if (!userId) return;
  try { localStorage.removeItem(`${BASE_KEY}:${userId}`); } catch {}
}

export const setPersistenceHook = (hook: ((snapshot: Workspace) => void | Promise<void>) | null) => {
  persistenceHook = hook;
};
export const getStateSnapshot = () => workspaceSnapshot();
export const replaceState = (next: any) => {
  workspace = migrate(next);
  state = workspace.projects[workspace.activeProjectId] || emptyState(workspace.activeProjectId);
  try { localStorage.setItem(storageKey, JSON.stringify(workspace)); } catch {}
};
export const resetState = () => {
  const pid = workspace.activeProjectId || id('project');
  state = emptyState(pid);
  workspace.activeProjectId = pid;
  workspace.projects[pid] = state;
  persist();
};

const activeProjectId = () => workspace.activeProjectId;
const num = (v: any) => Number.isFinite(Number(v)) ? Number(v) : 0;

function ledger(): ConstructionLedgerItem[] {
  const out: ConstructionLedgerItem[] = [];
  const seen = new Set<string>();
  for (const e of state.expenses) {
    if (seen.has(`exp:${e.id}`)) continue;
    seen.add(`exp:${e.id}`);
    out.push({ id: e.id, date: e.date, description: e.description, category: e.category, amount: num(e.amount), paymentStatus: e.paymentStatus,
      paymentMethod: e.paymentMethod, recipientOrSupplier: e.recipient, receiptUrl: e.receiptUrl, paymentProofUrl: e.paymentProofUrl,
      source: e.source || 'Manual', type: e.category === 'Labour' ? 'Labour' : e.category === 'Materials' ? 'Material' : 'Expense', refId: e.id });
  }
  // Material purchases are financial transactions themselves. They are not copied into
  // expenses, which prevents double-counting.
  for (const p of state.purchases) {
    if (seen.has(`purchase:${p.id}`)) continue;
    seen.add(`purchase:${p.id}`);
    out.push({ id: p.id, date: p.date, description: `${p.quantity} ${p.unit} ${p.materialName}`, category: 'Materials', amount: num(p.totalPrice),
      paymentStatus: p.paymentStatus, recipientOrSupplier: p.supplier, receiptUrl: p.receiptUrl, source: 'Material Purchase', type: 'Material', refId: p.id });
  }
  return out.sort((a, b) => b.date.localeCompare(a.date));
}

function summary(): SummaryData {
  const l = ledger();
  const now = new Date();
  const t = today();
  const yDate = new Date(now); yDate.setDate(yDate.getDate() - 1);
  const y = `${yDate.getFullYear()}-${String(yDate.getMonth() + 1).padStart(2, '0')}-${String(yDate.getDate()).padStart(2, '0')}`;
  const month = t.slice(0, 7);
  const todayItems = l.filter(x => x.date === t);
  const yesterdayItems = l.filter(x => x.date === y);
  const paidOnly = (items: ConstructionLedgerItem[]) => items.filter(x => x.paymentStatus === 'Paid');
  const todaySpending = paidOnly(todayItems).reduce((s, x) => s + x.amount, 0);
  const yesterdaySpending = paidOnly(yesterdayItems).reduce((s, x) => s + x.amount, 0);
  const thisMonthSpending = paidOnly(l.filter(x => x.date.startsWith(month))).reduce((s, x) => s + x.amount, 0);
  const totalSpending = paidOnly(l).reduce((s, x) => s + x.amount, 0);
  const committedSpending = l.reduce((s, x) => s + x.amount, 0);
  const ledgerOutstanding = l.filter(x => x.paymentStatus === 'Pending').reduce((s, x) => s + x.amount, 0);
  const present = state.attendance.filter(a => a.date === t && (a.status === 'Present' || a.status === 'Half Day'));
  const pendingPayments = state.payments.filter(p => p.status === 'Pending').reduce((s, p) => s + num(p.amount), 0);
  const progress = state.stages.length ? Math.round(state.stages.reduce((s, x) => s + num(x.percentageComplete), 0) / state.stages.length) : 0;
  const diff = todaySpending - yesterdaySpending;
  const diffPct = yesterdaySpending ? Number(((diff / yesterdaySpending) * 100).toFixed(1)) : 0;
  const cats = new Map<string, number>();
  for (const x of l) cats.set(x.category, (cats.get(x.category) || 0) + x.amount);
  const catTotal = totalSpending || 1;
  const categoryDistribution = Array.from(cats.entries()).sort((a,b) => b[1]-a[1]).map(([name, value]) => ({ name, value, percentage: Math.round(value / catTotal * 100), color: '#f59e0b' }));
  const dailyMap = new Map<string, any>();
  for (const x of paidOnly(l)) {
    const d = dailyMap.get(x.date) || { date: x.date, displayDate: x.date, amount: 0, workers: 0, labour: 0, materials: 0, electrical: 0, transport: 0, other: 0 };
    d.amount += x.amount;
    if (x.category === 'Labour') d.labour += x.amount;
    else if (x.category === 'Materials') d.materials += x.amount;
    else if (x.category === 'Electrical') d.electrical += x.amount;
    else if (x.category === 'Transport') d.transport += x.amount;
    else d.other += x.amount;
    dailyMap.set(x.date, d);
  }
  for (const a of state.attendance) {
    if (a.status === 'Present') {
      const d = dailyMap.get(a.date) || { date: a.date, displayDate: a.date, amount: 0, workers: 0, labour: 0, materials: 0, other: 0 };
      d.workers += 1; dailyMap.set(a.date, d);
    }
  }
  const dailySpendingHistory = Array.from(dailyMap.values()).sort((a,b) => b.date.localeCompare(a.date)).slice(0, 31).map(d => ({ ...d, displayDate: d.date === t ? 'Today' : d.date }));
  const monthlyMap = new Map<string, any>();
  for (const x of paidOnly(l)) {
    const m = x.date.slice(0, 7);
    const d = monthlyMap.get(m) || { month: m, amount: 0, materials: 0, labour: 0, electrical: 0, transport: 0, other: 0, workerDays: 0 };
    d.amount += x.amount;
    if (x.category === 'Materials') d.materials += x.amount;
    else if (x.category === 'Labour') d.labour += x.amount;
    else if (x.category === 'Electrical') d.electrical += x.amount;
    else if (x.category === 'Transport') d.transport += x.amount;
    else d.other += x.amount;
    monthlyMap.set(m, d);
  }
  for (const a of state.attendance) { if (a.status === 'Present' || a.status === 'Half Day') { const m = a.date.slice(0,7); const d = monthlyMap.get(m) || { month:m, amount:0, materials:0, labour:0, electrical:0, transport:0, other:0, workerDays:0 }; d.workerDays += a.status === 'Half Day' ? 0.5 : 1; monthlyMap.set(m,d); } }
  const monthlySpendingHistory = Array.from(monthlyMap.values()).sort((a,b) => b.month.localeCompare(a.month)).map(d => ({ ...d, month: d.month }));
  const remainingBudget = num(state.house.totalBudget) - committedSpending;
  let spendingStreak = 0;
  for (let offset = 0; offset < 366; offset++) {
    const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - offset);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    if (l.some(x => x.date === key && x.amount > 0 && x.paymentStatus === 'Paid')) spendingStreak++; else break;
  }
  const biggestCategory = categoryDistribution[0] || { name: 'None', value: 0, percentage: 0 };
  const mostMaterial = [...state.materials].sort((a,b) => b.totalAmountSpent-a.totalAmountSpent)[0];
  const highestWorker = [...state.workers].sort((a,b) => b.totalWagesEarned-a.totalWagesEarned)[0];
  const biggestPurchase = [...state.purchases].sort((a,b) => num(b.totalPrice)-num(a.totalPrice))[0];
  const averageDailySpending = dailySpendingHistory.length ? totalSpending / dailySpendingHistory.length : 0;
  const averageMonthlySpending = monthlySpendingHistory.length ? totalSpending / monthlySpendingHistory.length : 0;
  const paidTodayItems = paidOnly(todayItems);
  const paidYesterdayItems = paidOnly(yesterdayItems);
  const breakdownNames = Array.from(new Set([...paidTodayItems.map(x=>x.category), ...paidYesterdayItems.map(x=>x.category)]));
  const breakdown = breakdownNames.map(category => ({ category, todayAmount: paidTodayItems.filter(x=>x.category===category).reduce((s,x)=>s+x.amount,0), yesterdayAmount: paidYesterdayItems.filter(x=>x.category===category).reduce((s,x)=>s+x.amount,0), difference: paidTodayItems.filter(x=>x.category===category).reduce((s,x)=>s+x.amount,0)-paidYesterdayItems.filter(x=>x.category===category).reduce((s,x)=>s+x.amount,0) }));
  return {
    house: { ...state.house, spentAmount: totalSpending, currentProgressPct: progress }, today: t, yesterday: y, currentMonth: month,
    totalSpending, committedSpending, outstandingAmount: ledgerOutstanding + pendingPayments, todaySpending, yesterdaySpending, thisMonthSpending, workersToday: present.length,
    todayLabourCost: present.reduce((s,a)=>s+num(a.wageAmount),0), pendingPayments, remainingBudget, constructionProgress: progress,
    healthScore: (() => {
      const budgetHealth = state.house.totalBudget > 0 ? Math.max(0, Math.min(100, 100 - Math.max(0, committedSpending - state.house.totalBudget) / state.house.totalBudget * 100)) : 50;
      const progressHealth = state.house.totalBudget > 0 ? Math.max(0, Math.min(100, progress)) : progress;
      const paymentHealth = (state.payments.length || ledgerOutstanding > 0) ? Math.max(0, 100 - ((ledgerOutstanding + pendingPayments) / Math.max(1, committedSpending)) * 100) : 100;
      return Math.round(budgetHealth * 0.45 + progressHealth * 0.35 + paymentHealth * 0.20);
    })(),
    spendingStreak,
    comparison: { diffAmount: diff, diffPct, isHigher: diff > 0, text: diff === 0 ? 'Same as yesterday' : `${diff > 0 ? 'Higher' : 'Lower'} than yesterday by ₹${Math.abs(diff).toLocaleString('en-IN')}`, breakdown },
    categoryDistribution, dailySpendingHistory, monthlySpendingHistory,
    topInsights: { biggestCategory: { name: biggestCategory.name, amount: biggestCategory.value, pct: biggestCategory.percentage }, mostExpensiveMaterial: { name: mostMaterial?.name || 'None', amount: mostMaterial?.totalAmountSpent || 0 }, highestPaidWorker: { name: highestWorker?.name || 'None', amount: highestWorker?.totalWagesEarned || 0 }, biggestSinglePurchase: { name: biggestPurchase?.materialName || 'None', amount: biggestPurchase?.totalPrice || 0 }, averageDailySpending, averageMonthlySpending }
  };
}

function recalcWorkerTotals(workerId: string) {
  const w = state.workers.find(x => x.id === workerId); if (!w) return;
  const records = state.attendance.filter(a => a.workerId === workerId);
  w.totalDaysWorked = records.filter(a => a.status === 'Present').length + records.filter(a => a.status === 'Half Day').length * 0.5;
  w.totalWagesEarned = records.reduce((s,a)=>s+num(a.wageAmount),0);
  w.totalPaid = records.reduce((s,a)=>s+num(a.paidAmount),0);
  w.pendingBalance = Math.max(0, w.totalWagesEarned - w.totalPaid);
}


const TELUGU_NUMBERS: Record<string, number> = { 'ఒక':1,'ఒక్క':1,'ఇద్దరు':2,'రెండు':2,'ముగ్గురు':3,'మూడు':3,'నలుగురు':4,'నాలుగు':4,'ఐదుగురు':5,'ఐదు':5,'ఆరుగురు':6,'ఆరు':6,'ఏడుగురు':7,'ఏడు':7,'ఎనిమిది':8,'తొమ్మిది':9,'పది':10 };
const rolePatterns: Array<{ role:'Mason'|'Helper'; patterns: RegExp[] }> = [
  { role:'Mason', patterns:[/(\d+)\s*masons?/i, /(\d+)\s*మేస్త్రీలు?/, /(ఒక|ఇద్దరు|ముగ్గురు|నలుగురు|ఐదుగురు|ఆరుగురు|ఏడుగురు)\s*మేస్త్రీలు?/] },
  { role:'Helper', patterns:[/(\d+)\s*helpers?/i, /(\d+)\s*హెల్పర్లు?/, /(ఒక|ఇద్దరు|ముగ్గురు|నలుగురు|ఐదుగురు|ఆరుగురు|ఏడుగురు)\s*హెల్పర్లు?/] },
];
function numberFromToken(v:string){ return /^\d+$/.test(v) ? Number(v) : TELUGU_NUMBERS[v] ?? 0; }
function extractWage(segment:string){
  const m = segment.match(/(?:₹|rs\.?|rupees?|రూపాయలు|ఇచ్చాను|ఒక్కొక్కరికి|each)[^\d]{0,20}(\d[\d,]*)/i) || segment.match(/(\d[\d,]*)\s*(?:rupees?|₹|రూపాయలు)/i);
  return m ? Number(m[1].replace(/,/g,'')) : 0;
}
function parseVoiceText(text:string){
  const lower=text.toLowerCase();
  const extracted: VoiceExtractedData={workers:[],materials:[],expenses:[],labourTotal:0,materialTotal:0,grandTotal:0,summaryText:`Site update recorded: ${text}`,rawTeluguText:text,englishTranslation:text};
  for(const {role,patterns} of rolePatterns){
    for(const pattern of patterns){ const match=text.match(pattern); if(!match) continue; const count=numberFromToken(match[1]); const start=match.index ?? 0; const segment=text.slice(start, start+180); const wage=extractWage(segment) || (role==='Mason' ? (lower.includes('mason') ? 0 : 0) : 0); if(count>0){ extracted.workers.push({role,count,wagePerPerson:wage,subtotal:count*wage}); extracted.labourTotal += count*wage; break; } }
  }
  const materialPatterns=[
    {keys:['brick','bricks','ఇటుక'],unit:'pieces',name:'Bricks'},
    {keys:['cement','సిమెంట్'],unit:'bags',name:'Cement'},
  ];
  for(const item of materialPatterns){
    const key=item.keys.find(k=>lower.includes(k)); if(!key) continue;
    const idx=lower.indexOf(key); const segment=text.slice(Math.max(0,idx-25),idx+180); const qMatch=segment.match(/(\d[\d,]*)/); if(!qMatch) continue;
    const quantity=Number(qMatch[1].replace(/,/g,'')); const money=[...segment.matchAll(/(\d[\d,]*)\s*(?:rupees?|₹|రూపాయలు|వేల)/gi)].map(m=>Number(m[1].replace(/,/g,''))); let totalPrice=money.length?money[money.length-1]:0; if(/వేల/.test(segment) && totalPrice && totalPrice<1000) totalPrice*=1000;
    extracted.materials.push({name:item.name,quantity,unit:item.unit,totalPrice}); extracted.materialTotal+=totalPrice;
  }
  const expensePatterns:[RegExp, ExpenseCategory, string][]=[[/electrical[^.]*?(\d[\d,]*)/i,'Electrical','Electrical'],[/వైర్లు?[^.]*?(\d[\d,]*)/,'Electrical','Electrical'],[/transport[^.]*?(\d[\d,]*)/i,'Transport','Transport'],[/ట్రాన్స్పోర్ట్[^.]*?(\d[\d,]*)/,'Transport','Transport']];
  for(const [re,category,description] of expensePatterns){ const m=text.match(re); if(m){ const amount=Number(m[1].replace(/,/g,'')); if(amount>0) extracted.expenses.push({category,description,amount}); } }
  extracted.grandTotal=extracted.labourTotal+extracted.materialTotal+extracted.expenses.reduce((s,e)=>s+e.amount,0);
  return {success:true,rawText:text,extracted};
}

export const localApi = {
  getProjects: async () => Object.values(workspace.projects).map(p => ({ id: p.house.id, name: p.house.name, location: p.house.location, totalBudget: p.house.totalBudget, active: p.house.id === activeProjectId() })),
  createProject: async (input: Partial<House>) => {
    const pid = id('project'); const s = emptyState(pid); s.house = { ...s.house, ...input, id: pid, name: input.name?.trim() || 'New Construction Project' };
    workspace.projects[pid] = s; workspace.activeProjectId = pid; state = s; persist(); return clone(s.house);
  },
  switchProject: async (projectId: string) => {
    if (!workspace.projects[projectId]) throw Error('Project not found');
    workspace.projects[workspace.activeProjectId] = clone(state); workspace.activeProjectId = projectId; state = workspace.projects[projectId]; persist(); return clone(state.house);
  },
  updateProject: async (updates: Partial<House>) => { state.house = { ...state.house, ...updates, id: activeProjectId() }; persist(); return clone(state.house); },
  getSummary: async()=>summary(),
  getLedger: async(params?:any)=>{ let a=ledger(); if(params?.search){const q=String(params.search).toLowerCase();a=a.filter(x=>`${x.description} ${x.category} ${x.recipientOrSupplier||''}`.toLowerCase().includes(q));} if(params?.category&&params.category!=='All')a=a.filter(x=>x.category===params.category);if(params?.status&&params.status!=='All')a=a.filter(x=>x.paymentStatus===params.status);if(params?.type&&params.type!=='All')a=a.filter(x=>x.type===params.type);if(params?.date)a=a.filter(x=>x.date===params.date);return a; },
  getWorkers: async()=>clone(state.workers),
  getAttendance: async()=>clone(state.attendance),
  getWorkerDetails: async(workerId:string)=>{const w=state.workers.find(x=>x.id===workerId);if(!w)throw Error('Worker not found');return {...clone(w),attendanceHistory:clone(state.attendance.filter(a=>a.workerId===workerId))};},
  addWorker: async(w:any)=>{const n:any={...w,id:id('w'),houseId:activeProjectId(),totalDaysWorked:0,totalWagesEarned:0,totalPaid:0,pendingBalance:0,status:w.status||'active',joiningDate:w.joiningDate||today()};state.workers.push(n);persist();return clone(n);},
  updateWorker: async(i:string,u:any)=>{const n=state.workers.find(x=>x.id===i);if(!n)throw Error('Worker not found');Object.assign(n,u);recalcWorkerTotals(i);persist();return clone(n);},
  recordBulkAttendance: async(items:any[])=>{const created:any[]=[];for(const x of items){const w=state.workers.find(y=>y.id===x.workerId);if(!w)continue;const date=x.date||today();const existing=state.attendance.find(a=>a.workerId===w.id&&a.date===date);const wage=x.status==='Present'?w.dailyWage:x.status==='Half Day'?w.dailyWage/2:0;const paid=x.paidAmount==null?wage:num(x.paidAmount);const r:any={id:existing?.id||id('att'),houseId:activeProjectId(),workerId:w.id,workerName:w.name,workerRole:w.role,date,status:x.status,wageAmount:wage,paidAmount:paid,paymentStatus:paid>=wage?'Paid':'Pending',notes:x.notes||''};if(existing)Object.assign(existing,r);else state.attendance.push(r);recalcWorkerTotals(w.id);created.push(r);}persist();return {success:true,count:created.length,created:clone(created)};},
  getMaterials: async()=>clone(state.materials), getMaterialPurchases: async()=>clone(state.purchases),
  addMaterialPurchase: async(p:any)=>{const total=num(p.totalPrice) || num(p.quantity)*num(p.pricePerUnit);const material=state.materials.find(x=>x.id===p.materialId)||state.materials.find(x=>x.name.trim().toLowerCase()===String(p.materialName||'').trim().toLowerCase());const n:any={...p,id:id('mp'),houseId:activeProjectId(),materialId:material?.id||id('mat'),date:p.date||today(),quantity:num(p.quantity),unit:p.unit||material?.defaultUnit||'pieces',pricePerUnit:num(p.pricePerUnit)||(num(p.quantity)?total/num(p.quantity):0),totalPrice:total,supplier:p.supplier||'Local Building Supplier',paymentStatus:p.paymentStatus||'Paid',notes:p.notes||''};state.purchases.push(n);if(material){material.totalQuantityPurchased+=n.quantity;material.totalAmountSpent+=total;material.purchaseCount++;material.averagePrice=material.totalQuantityPurchased?material.totalAmountSpent/material.totalQuantityPurchased:0;material.latestPurchaseDate=n.date;}else{state.materials.push({id:n.materialId,houseId:activeProjectId(),name:n.materialName||'Material',category:'Construction',defaultUnit:n.unit,totalQuantityPurchased:n.quantity,totalAmountSpent:total,averagePrice:n.pricePerUnit,purchaseCount:1,firstPurchaseDate:n.date,latestPurchaseDate:n.date});}persist();return clone(n);},
  getExpenses: async()=>clone(state.expenses),
  addExpense: async(e:any)=>{const amount=safeAmount(e.amount,'Expense amount');if(amount<=0)throw new Error('Expense amount must be greater than zero.');const n:any={...e,id:id('exp'),houseId:activeProjectId(),date:e.date||today(),amount,paymentMethod:e.paymentMethod||'Cash',paymentStatus:e.paymentStatus||'Paid',category:safeCategory(e.category),recipient:String(e.recipient||'General').trim()||'General',source:e.source||'Manual'};state.expenses.push(n);persist();return clone(n);},
  deleteExpense: async(i:string)=>{const idx=state.expenses.findIndex(x=>x.id===i);if(idx<0)return false;state.expenses.splice(idx,1);persist();return true;},
  deleteMaterialPurchase: async(i:string)=>{const idx=state.purchases.findIndex(x=>x.id===i);if(idx<0)return false;const purchase=state.purchases[idx];const material=state.materials.find(x=>x.id===purchase.materialId);if(material){material.totalQuantityPurchased=Math.max(0,num(material.totalQuantityPurchased)-num(purchase.quantity));material.totalAmountSpent=Math.max(0,num(material.totalAmountSpent)-num(purchase.totalPrice));material.purchaseCount=Math.max(0,num(material.purchaseCount)-1);material.averagePrice=material.totalQuantityPurchased?material.totalAmountSpent/material.totalQuantityPurchased:0;}state.purchases.splice(idx,1);persist();return true;},
  deleteLedgerItem: async(i:string)=>{const expenseIdx=state.expenses.findIndex(x=>x.id===i);if(expenseIdx>=0){state.expenses.splice(expenseIdx,1);persist();return {success:true,type:'expense'};}const purchaseIdx=state.purchases.findIndex(x=>x.id===i);if(purchaseIdx>=0){await localApi.deleteMaterialPurchase(i);return {success:true,type:'material'};}return {success:false,type:null};},
  getPayments: async()=>clone(state.payments),
  addPayment: async(p:any)=>{const amount=safeAmount(p.amount,'Payment amount');if(amount<=0)throw new Error('Payment amount must be greater than zero.');const recipient=String(p.recipient||'').trim();if(!recipient)throw new Error('Payment recipient is required.');const n:any={...p,id:id('pay'),houseId:activeProjectId(),amount,date:p.date||today(),status:p.status||'Pending',category:safeCategory(p.category),recipient};state.payments.push(n);persist();return clone(n);},
  attachPaymentProof: async(i:string,ref:string)=>{const p=state.payments.find(x=>x.id===i);if(!p)throw Error('Payment not found');p.paymentProofUrl=ref;persist();return clone(p);},
  markPaymentPaid: async(i:string,m='UPI',r='PAID-DIRECT')=>{const p=state.payments.find(x=>x.id===i);if(!p)throw Error('Payment not found');if(p.status==='Paid')return clone(p);p.status='Paid';p.paymentMethod=m as any;p.reference=r;state.expenses.push({id:id('exp'),houseId:activeProjectId(),date:today(),category:p.category,description:`Payment to ${p.recipient}`,amount:num(p.amount),paymentMethod:m,paymentStatus:'Paid',recipient:p.recipient,source:'Payment'} as any);persist();return clone(p);},
  getBudget: async()=>{const totalBudget=num(state.house.totalBudget);const totalSpent=ledger().reduce((s,x)=>s+x.amount,0);const categories=new Map<ExpenseCategory,number>();for(const x of ledger())categories.set(x.category,(categories.get(x.category)||0)+x.amount);const cats=state.budgets.map(b=>({...b,spentAmount:categories.get(b.category)||0,remaining:b.budgetedAmount-(categories.get(b.category)||0),pctUsed:b.budgetedAmount?((categories.get(b.category)||0)/b.budgetedAmount)*100:0}));return {totalBudget,totalSpent,remainingBudget:totalBudget-totalSpent,pctUsed:totalBudget?totalSpent/totalBudget*100:0,categories:clone(cats)};},
  getProgress: async()=>({overallPercentage:state.stages.length?Math.round(state.stages.reduce((s,x)=>s+x.percentageComplete,0)/state.stages.length):0,stages:clone(state.stages)}),
  updateStage: async(i:string,p:number,status?:string,notes?:string)=>{const s=state.stages.find(x=>x.id===i);if(!s)throw Error('Stage not found');s.percentageComplete=Math.max(0,Math.min(100,num(p)));if(status)s.status=status as any;if(s.percentageComplete===100)s.status='Completed';else if(s.percentageComplete>0&&s.status==='Not Started')s.status='In Progress';if(notes!==undefined)s.notes=notes;persist();return clone(s);},
  getPhotos: async()=>clone(state.photos), addPhoto: async(p:any)=>{const n:any={...p,id:id('photo'),houseId:activeProjectId(),date:p.date||today()};state.photos.unshift(n);persist();return clone(n);},
  getBills: async()=>clone(state.bills), addBill: async(b:any)=>{const n:any={...b,id:id('bill'),houseId:activeProjectId(),date:b.date||today()};state.bills.unshift(n);persist();return clone(n);},
  simulateOcr:async()=>{ throw new Error('OCR is not available in offline mode. Connect a configured OCR service before scanning bills.'); },
  parseVoice:async(text:string)=>parseVoiceText(text),
  confirmVoice:async(ex:any,raw:string)=>{const date=today();for(const g of ex.workers||[]){const ws=state.workers.filter(w=>w.role===g.role&&w.status==='active');if(ws.length<g.count)throw new Error(`Voice update requested ${g.count} ${g.role}(s), but only ${ws.length} active ${g.role}(s) are registered. Add the missing workers first.`);await localApi.recordBulkAttendance(ws.slice(0,g.count).map(w=>({workerId:w.id,status:'Present',date,paidAmount:g.wagePerPerson})));}for(const m of ex.materials||[])await localApi.addMaterialPurchase({materialName:m.name,quantity:m.quantity,unit:m.unit,totalPrice:m.totalPrice,pricePerUnit:m.quantity?m.totalPrice/m.quantity:0,date,paymentStatus:'Paid',supplier:'Voice Entry'});for(const e of ex.expenses||[])await localApi.addExpense({date,category:e.category,description:e.description,amount:e.amount,paymentMethod:'Cash',paymentStatus:'Paid',recipient:'Voice Entry'});return {success:true};},
  queryAssistant:async(q:string)=>{const s=summary();const l=q.toLowerCase();let metricValue='';let answerEnglish='I can help with your construction records.';let answerTelugu='మీ నిర్మాణ వివరాల గురించి అడగండి.';if(l.includes('budget')||l.includes('బడ్జెట్')){metricValue=`₹${s.remainingBudget.toLocaleString('en-IN')}`;answerEnglish=`Your remaining construction budget is ${metricValue}.`;answerTelugu=`మీ మిగిలిన బడ్జెట్ ${metricValue}.`;}else if(l.includes('worker')||l.includes('వర్కర్')){metricValue=String(s.workersToday);answerEnglish=`${s.workersToday} workers are recorded as present today.`;answerTelugu=`ఈరోజు ${s.workersToday} మంది వర్కర్లు వచ్చారు.`;}else if(l.includes('today')||l.includes('ఈరోజు')){metricValue=`₹${s.todaySpending.toLocaleString('en-IN')}`;answerEnglish=`Today's recorded spending is ${metricValue}.`;answerTelugu=`ఈరోజు ఖర్చు ${metricValue}.`;}else if(l.includes('complete')||l.includes('progress')){metricValue=`${s.constructionProgress}%`;answerEnglish=`The project is ${metricValue} complete.`;answerTelugu=`నిర్మాణం ${metricValue}% పూర్తయింది.`;}return {question:q,answerTelugu,answerEnglish,metricValue};},
  resetDemo:async()=>{const pid=activeProjectId();state=demoState(pid);workspace.projects[pid]=state;persist();return {success:true};}
};
