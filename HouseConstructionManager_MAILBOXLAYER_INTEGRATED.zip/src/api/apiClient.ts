// The deployed application uses the local state engine with Supabase persistence.
// This avoids requiring a separate Express server or /api proxy on Netlify.
import { remoteApi } from './remoteApi.js';

export const api = remoteApi;
export type ApiClient = typeof api;
