import { ExpenseCategory } from '../types.js';

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
export const ALLOWED_UPLOAD_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'application/pdf']);

export function validateUpload(file: File) {
  if (!ALLOWED_UPLOAD_TYPES.has(file.type)) {
    throw new Error('Unsupported file type. Use JPG, PNG, WEBP, or PDF.');
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new Error('File is too large. Maximum size is 10 MB.');
  }
}

export function safeAmount(value: unknown, field = 'Amount') {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0) throw new Error(`${field} must be a valid non-negative number.`);
  return amount;
}

export function safeCategory(value: unknown): ExpenseCategory {
  const allowed: ExpenseCategory[] = ['Materials','Labour','Transport','Electrical','Plumbing','Flooring','Painting','Contractor','Equipment','Doors/Windows','Other'];
  return allowed.includes(value as ExpenseCategory) ? value as ExpenseCategory : 'Other';
}

export function localDateInputValue(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
