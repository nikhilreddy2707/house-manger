import { localApi, getStateSnapshot, replaceState, setPersistenceHook, setStorageScope } from './localApi.js';
import { getUser, loadCloudState, saveCloudState, loadNormalizedState, listNormalizedRecords, upsertNormalizedRecords, deleteNormalizedRecords, uploadFile, deleteFile, resolveFileUrl, scanBillWithOcr } from './supabaseClient.js';
import { flattenWorkspace, recordKey, type WorkspaceRecord } from './dataModel.js';

let userId = '';
let initialized = false;
let saveTimer: ReturnType<typeof setTimeout> | null = null;
let pendingSnapshot: any = null;
let lastSyncedRows = new Map<string, WorkspaceRecord>();
let normalizedMode = false;
let flushPromise: Promise<void> | null = null;
let flushListenersAttached = false;

async function persistNormalized(snapshot: any) {
  const current = flattenWorkspace(snapshot, userId);
  const currentMap = new Map(current.map(row => [recordKey(row), row]));
  const changed = current.filter(row => {
    const previous = lastSyncedRows.get(recordKey(row));
    return !previous || JSON.stringify(previous.data) !== JSON.stringify(row.data);
  });
  const deleted = [...lastSyncedRows.values()].filter(row => !currentMap.has(recordKey(row)));
  if (changed.length) await upsertNormalizedRecords(changed);
  if (deleted.length) await deleteNormalizedRecords(userId, deleted);
  lastSyncedRows = currentMap;
}

async function persistLatest() {
  if (!userId || !pendingSnapshot) return;
  const snapshot = pendingSnapshot;
  pendingSnapshot = null;
  try {
    if (normalizedMode) await persistNormalized(snapshot);
    else await saveCloudState(userId, snapshot);
  } catch (err) {
    pendingSnapshot = snapshot;
    console.error('Cloud save failed; latest changes remain queued:', err);
    throw err;
  }
}

export async function flushPendingPersistence() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  if (!userId || !pendingSnapshot) return;
  if (flushPromise) return flushPromise;
  flushPromise = persistLatest().finally(() => { flushPromise = null; });
  return flushPromise;
}

function flushPendingSave() {
  void flushPendingPersistence();
}

export async function initializeRemoteApi(existingUser?: any) {
  const user = existingUser || await getUser();
  if (!user) throw new Error('Not authenticated');
  userId = user.id;
  setStorageScope(user.id);

  let cloud: any = null;
  try {
    const existingRows = await listNormalizedRecords(user.id);
    normalizedMode = true;
    lastSyncedRows = new Map(existingRows.map(row => [recordKey(row), row]));
    cloud = existingRows.length ? await loadNormalizedState(user.id) : null;
    // Seamlessly migrate an existing customer's legacy JSON workspace once.
    if (!cloud) {
      const legacy = await loadCloudState(user.id);
      if (legacy) {
        cloud = legacy;
        await persistNormalized(legacy);
      }
    }
  } catch (err: any) {
    if (String(err?.message) !== 'NORMALIZED_SCHEMA_MISSING') throw err;
    normalizedMode = false;
    cloud = await loadCloudState(user.id);
  }

  // A cloud workspace is authoritative. A brand-new account starts empty and is
  // never populated from another user's browser cache.
  if (cloud) replaceState(cloud);

  setPersistenceHook(snapshot => {
    pendingSnapshot = snapshot;
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { void persistLatest().catch(console.error); }, 500);
  });
  initialized = true;

  if (!cloud) {
    const snapshot = getStateSnapshot();
    if (normalizedMode) {
      await persistNormalized(snapshot);
    } else {
      await saveCloudState(user.id, snapshot);
    }
  }

  if (!flushListenersAttached && typeof window !== 'undefined') {
    flushListenersAttached = true;
    window.addEventListener('beforeunload', flushPendingSave);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') flushPendingSave();
    });
  }
  return user;
}

async function resolveRecords(records: any[], fields: string[]) {
  return Promise.all(records.map(async record => {
    const next: any = { ...record };
    for (const field of fields) {
      if (next[field]) {
        try { next[field] = await resolveFileUrl(next[field]); } catch { /* keep inaccessible refs visible as raw refs */ }
      }
    }
    return next;
  }));
}

export const remoteApi = {
  ...localApi,
  async getLedger(params?: any) { return resolveRecords(await localApi.getLedger(params), ['receiptUrl','paymentProofUrl']); },
  async getExpenses() { return resolveRecords(await localApi.getExpenses(), ['receiptUrl','paymentProofUrl']); },
  async getPayments() { return resolveRecords(await localApi.getPayments(), ['paymentProofUrl']); },
  async getPhotos() { return resolveRecords(await localApi.getPhotos(), ['photoUrl']); },
  async getBills() { return resolveRecords(await localApi.getBills(), ['fileUrl']); },
  async addPhoto(photo: any) {
    if (photo.file instanceof File) { photo.photoUrl = await uploadFile(userId, photo.file); delete photo.file; }
    return localApi.addPhoto(photo);
  },
  async scanBill(file: File) { return scanBillWithOcr(file); },
  async addBill(bill: any) {
    let uploadedRef = '';
    try {
      if (bill.file instanceof File) { uploadedRef = await uploadFile(userId, bill.file); bill.fileUrl = uploadedRef; delete bill.file; }
      return await localApi.addBill(bill);
    } catch (err) {
      if (uploadedRef) await deleteFile(uploadedRef).catch(() => {});
      throw err;
    }
  },
  async attachPaymentProof(paymentId: string, file: File) {
    const ref = await uploadFile(userId, file);
    try {
      const result = await localApi.attachPaymentProof(paymentId, ref);
      return result;
    } catch (err) {
      await deleteFile(ref).catch(() => {});
      throw err;
    }
  },
  async uploadFile(file: File) { return uploadFile(userId, file); },
  async deleteFile(ref: string) { return deleteFile(ref); },
  get ready() { return initialized; },
  get persistenceMode() { return normalizedMode ? 'normalized' : 'legacy-json'; },
};
