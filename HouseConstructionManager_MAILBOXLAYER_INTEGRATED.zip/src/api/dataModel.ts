export type WorkspaceRecord = {
  user_id: string;
  project_id: string;
  entity_type: string;
  record_id: string;
  data: any;
  updated_at?: string;
};

const COLLECTIONS = ['workers','attendance','materials','purchases','expenses','payments','budgets','stages','photos','bills'] as const;
export type CollectionName = typeof COLLECTIONS[number];

export function flattenWorkspace(workspace: any, userId: string): WorkspaceRecord[] {
  const rows: WorkspaceRecord[] = [];
  rows.push({ user_id: userId, project_id: '__workspace__', entity_type: 'meta', record_id: 'workspace', data: { version: workspace?.version || 3, activeProjectId: workspace?.activeProjectId || '' } });
  for (const [projectId, project] of Object.entries(workspace?.projects || {})) {
    rows.push({ user_id: userId, project_id: projectId, entity_type: 'project', record_id: projectId, data: (project as any).house || {} });
    for (const collection of COLLECTIONS) {
      const values = Array.isArray((project as any)[collection]) ? (project as any)[collection] : [];
      for (const item of values) {
        const recordId = String((item as any).id || `${collection}_${Math.random()}`);
        rows.push({ user_id: userId, project_id: projectId, entity_type: collection, record_id: recordId, data: item });
      }
    }
  }
  return rows;
}

export function inflateWorkspace(rows: WorkspaceRecord[]): any | null {
  if (!rows?.length) return null;
  const meta = rows.find(r => r.entity_type === 'meta' && r.record_id === 'workspace');
  const projects: Record<string, any> = {};
  for (const row of rows) {
    if (row.entity_type === 'meta') continue;
    const project = projects[row.project_id] ||= {
      house: null, workers: [], attendance: [], materials: [], purchases: [], expenses: [], payments: [], budgets: [], stages: [], photos: [], bills: []
    };
    if (row.entity_type === 'project') project.house = row.data;
    else if ((COLLECTIONS as readonly string[]).includes(row.entity_type)) (project[row.entity_type] as any[]).push(row.data);
  }
  for (const project of Object.values(projects)) if (!project.house) project.house = { id: '', name: 'Construction Project', totalBudget: 0 };
  return { version: meta?.data?.version || 3, activeProjectId: meta?.data?.activeProjectId || Object.keys(projects)[0] || '', projects };
}

export function recordKey(row: Pick<WorkspaceRecord,'project_id'|'entity_type'|'record_id'>) {
  return `${row.project_id}::${row.entity_type}::${row.record_id}`;
}
