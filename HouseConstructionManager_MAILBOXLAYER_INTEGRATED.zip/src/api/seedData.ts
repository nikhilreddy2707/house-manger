import {
  House, Worker, AttendanceRecord, Material, MaterialPurchase, Expense, Payment,
  BudgetItem, ConstructionStage, ProgressPhoto, BillReceipt,
} from '../types.js';

const TODAY = new Date();
const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => { const d = new Date(TODAY); d.setDate(d.getDate() - n); return iso(d); };
const monthStart = new Date(TODAY.getFullYear(), TODAY.getMonth(), 1);

export const initialHouse: House = {
  id: 'house_01', name: 'My Dream Home', ownerName: 'Home Owner', location: 'Hyderabad, Telangana',
  totalBudget: 5000000, spentAmount: 842500, startDate: `${TODAY.getFullYear()}-06-01`,
  expectedEndDate: `${TODAY.getFullYear()+1}-05-31`, currentProgressPct: 32, currency: 'INR'
};

export const initialWorkers: Worker[] = [
  { id:'w_001', houseId:'house_01', name:'Ramesh', role:'Mason', workerType:'Skilled', dailyWage:900, phone:'9876543210', status:'active', joiningDate:daysAgo(80), totalDaysWorked:24, totalWagesEarned:21600, totalPaid:19600, pendingBalance:2000 },
  { id:'w_002', houseId:'house_01', name:'Suresh', role:'Helper', workerType:'Semi-skilled', dailyWage:650, phone:'9876543211', status:'active', joiningDate:daysAgo(70), totalDaysWorked:22, totalWagesEarned:14300, totalPaid:14300, pendingBalance:0 },
  { id:'w_003', houseId:'house_01', name:'Mahesh', role:'Carpenter', workerType:'Skilled', dailyWage:1000, phone:'9876543212', status:'active', joiningDate:daysAgo(60), totalDaysWorked:20, totalWagesEarned:20000, totalPaid:18500, pendingBalance:1500 },
  { id:'w_004', houseId:'house_01', name:'Anil', role:'Electrician', workerType:'Skilled', dailyWage:1100, phone:'9876543213', status:'active', joiningDate:daysAgo(40), totalDaysWorked:12, totalWagesEarned:13200, totalPaid:13200, pendingBalance:0 },
  { id:'w_005', houseId:'house_01', name:'Raju', role:'Plumber', workerType:'Skilled', dailyWage:1050, phone:'9876543214', status:'active', joiningDate:daysAgo(35), totalDaysWorked:10, totalWagesEarned:10500, totalPaid:9000, pendingBalance:1500 },
];

export const initialAttendance: AttendanceRecord[] = initialWorkers.map((w, i) => ({
  id:`att_seed_${i+1}`, houseId:'house_01', workerId:w.id, workerName:w.name, workerRole:w.role,
  date:daysAgo(0), status:'Present', wageAmount:w.dailyWage, paidAmount:w.dailyWage, paymentStatus:'Paid'
}));

export const initialMaterials: Material[] = [
  { id:'mat_001', houseId:'house_01', name:'Cement', category:'Construction', defaultUnit:'bags', totalQuantityPurchased:120, totalAmountSpent:54000, averagePrice:450, purchaseCount:3, firstPurchaseDate:daysAgo(45), latestPurchaseDate:daysAgo(2) },
  { id:'mat_002', houseId:'house_01', name:'Steel', category:'Construction', defaultUnit:'kg', totalQuantityPurchased:1800, totalAmountSpent:126000, averagePrice:70, purchaseCount:2, firstPurchaseDate:daysAgo(40), latestPurchaseDate:daysAgo(5) },
  { id:'mat_003', houseId:'house_01', name:'Bricks', category:'Masonry', defaultUnit:'pieces', totalQuantityPurchased:10000, totalAmountSpent:90000, averagePrice:9, purchaseCount:2, firstPurchaseDate:daysAgo(35), latestPurchaseDate:daysAgo(7) },
  { id:'mat_004', houseId:'house_01', name:'Sand', category:'Construction', defaultUnit:'tons', totalQuantityPurchased:18, totalAmountSpent:72000, averagePrice:4000, purchaseCount:3, firstPurchaseDate:daysAgo(30), latestPurchaseDate:daysAgo(3) },
];

export const initialMaterialPurchases: MaterialPurchase[] = [
  { id:'mp_001', houseId:'house_01', materialId:'mat_001', materialName:'Cement', date:daysAgo(2), quantity:40, unit:'bags', pricePerUnit:450, totalPrice:18000, supplier:'ABC Cement', paymentStatus:'Paid' },
  { id:'mp_002', houseId:'house_01', materialId:'mat_002', materialName:'Steel', date:daysAgo(5), quantity:500, unit:'kg', pricePerUnit:70, totalPrice:35000, supplier:'Sri Sai Steels', paymentStatus:'Paid' },
  { id:'mp_003', houseId:'house_01', materialId:'mat_003', materialName:'Bricks', date:daysAgo(7), quantity:5000, unit:'pieces', pricePerUnit:9, totalPrice:45000, supplier:'Local Brick Works', paymentStatus:'Paid' },
  { id:'mp_004', houseId:'house_01', materialId:'mat_004', materialName:'Sand', date:daysAgo(3), quantity:6, unit:'tons', pricePerUnit:4000, totalPrice:24000, supplier:'Metro Sands', paymentStatus:'Pending' },
];

export const initialExpenses: Expense[] = [
  { id:'exp_001', houseId:'house_01', date:daysAgo(0), category:'Materials', description:'Cement purchase', amount:18000, paymentMethod:'UPI', paymentStatus:'Paid', recipient:'ABC Cement', source:'Manual' },
  { id:'exp_002', houseId:'house_01', date:daysAgo(0), category:'Labour', description:'Site labour wages', amount:4700, paymentMethod:'Cash', paymentStatus:'Paid', recipient:'Site Workers', source:'Manual' },
  { id:'exp_003', houseId:'house_01', date:daysAgo(1), category:'Materials', description:'Steel purchase', amount:35000, paymentMethod:'Bank Transfer', paymentStatus:'Paid', recipient:'Sri Sai Steels', source:'Manual' },
  { id:'exp_004', houseId:'house_01', date:daysAgo(1), category:'Transport', description:'Material transport', amount:3500, paymentMethod:'Cash', paymentStatus:'Paid', recipient:'Transport Vendor', source:'Manual' },
  { id:'exp_005', houseId:'house_01', date:daysAgo(2), category:'Equipment', description:'Mixer rental', amount:5000, paymentMethod:'UPI', paymentStatus:'Paid', recipient:'Equipment Rentals', source:'Manual' },
];

export const initialPayments: Payment[] = [
  { id:'pay_001', houseId:'house_01', recipient:'Ramesh', category:'Labour', amount:2000, date:daysAgo(0), paymentMethod:'Cash', status:'Pending' },
  { id:'pay_002', houseId:'house_01', recipient:'Metro Sands', category:'Materials', amount:24000, date:daysAgo(3), paymentMethod:'UPI', status:'Pending' },
];

const budget = (id:string, category:any, amount:number, spent:number): BudgetItem => ({
  id, houseId:'house_01', category, budgetedAmount:amount, spentAmount:spent,
  remaining:amount-spent, pctUsed:amount ? spent/amount*100 : 0,
  alertLevel: spent > amount ? 'exceeded' : spent/amount > .85 ? 'critical' : spent/amount > .7 ? 'warning' : 'normal'
});
export const initialBudgets: BudgetItem[] = [
  budget('bud_1','Materials',1800000,305000), budget('bud_2','Labour',1200000,85000),
  budget('bud_3','Electrical',350000,0), budget('bud_4','Plumbing',300000,0),
  budget('bud_5','Transport',250000,3500), budget('bud_6','Equipment',200000,5000),
  budget('bud_7','Other',900000,0),
];

export const initialStages: ConstructionStage[] = [
  { id:'stage_1', houseId:'house_01', stageName:'Site Preparation', orderIdx:1, status:'Completed', startDate:daysAgo(90), targetDate:daysAgo(80), actualCompletionDate:daysAgo(82), percentageComplete:100, notes:'Site cleared and prepared.' },
  { id:'stage_2', houseId:'house_01', stageName:'Foundation', orderIdx:2, status:'Completed', startDate:daysAgo(80), targetDate:daysAgo(55), actualCompletionDate:daysAgo(57), percentageComplete:100, notes:'Foundation work completed.' },
  { id:'stage_3', houseId:'house_01', stageName:'Structure', orderIdx:3, status:'In Progress', startDate:daysAgo(55), targetDate:daysAgo(10), percentageComplete:55, notes:'Columns and slab work underway.' },
  { id:'stage_4', houseId:'house_01', stageName:'Brickwork', orderIdx:4, status:'In Progress', startDate:daysAgo(25), targetDate:daysAgo(-20), percentageComplete:30, notes:'Ground floor brickwork underway.' },
  { id:'stage_5', houseId:'house_01', stageName:'Electrical & Plumbing', orderIdx:5, status:'Not Started', targetDate:daysAgo(-45), percentageComplete:0 },
  { id:'stage_6', houseId:'house_01', stageName:'Finishing', orderIdx:6, status:'Not Started', targetDate:daysAgo(-80), percentageComplete:0 },
];

export const initialProgressPhotos: ProgressPhoto[] = [];
export const initialBills: BillReceipt[] = [];

export const initialSeed = {
  house: initialHouse, workers: initialWorkers, attendance: initialAttendance, materials: initialMaterials,
  purchases: initialMaterialPurchases, expenses: initialExpenses, payments: initialPayments,
  budgets: initialBudgets, stages: initialStages, photos: initialProgressPhotos, bills: initialBills,
};
