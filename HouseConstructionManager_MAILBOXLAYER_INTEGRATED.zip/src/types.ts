export type WorkerRole =
  | 'Mason'
  | 'Helper'
  | 'Carpenter'
  | 'Electrician'
  | 'Plumber'
  | 'Painter'
  | 'Other';

export type ExpenseCategory =
  | 'Materials'
  | 'Labour'
  | 'Transport'
  | 'Electrical'
  | 'Plumbing'
  | 'Flooring'
  | 'Painting'
  | 'Contractor'
  | 'Equipment'
  | 'Doors/Windows'
  | 'Other';

export type PaymentMethod = 'Cash' | 'UPI' | 'Bank Transfer' | 'Cheque';
export type PaymentStatus = 'Paid' | 'Pending';
export type StageStatus = 'Not Started' | 'In Progress' | 'Completed' | 'Delayed';

export interface House {
  id: string;
  name: string;
  ownerName: string;
  location: string;
  totalBudget: number;
  spentAmount: number;
  startDate: string;
  expectedEndDate: string;
  currentProgressPct: number;
  currency: string;
}

export interface Worker {
  id: string;
  houseId: string;
  name: string;
  role: WorkerRole;
  workerType: string;
  dailyWage: number;
  phone?: string;
  status: 'active' | 'inactive';
  photo?: string;
  joiningDate: string;
  notes?: string;
  totalDaysWorked: number;
  totalWagesEarned: number;
  totalPaid: number;
  pendingBalance: number;
  attendanceHistory?: AttendanceRecord[];
}

export interface AttendanceRecord {
  id: string;
  houseId: string;
  workerId: string;
  workerName: string;
  workerRole: WorkerRole;
  date: string;
  status: 'Present' | 'Absent' | 'Half Day';
  wageAmount: number;
  paidAmount: number;
  paymentStatus: PaymentStatus;
  notes?: string;
}

export interface Material {
  id: string;
  houseId: string;
  name: string;
  category: string;
  defaultUnit: string;
  totalQuantityPurchased: number;
  totalAmountSpent: number;
  averagePrice: number;
  purchaseCount: number;
  firstPurchaseDate?: string;
  latestPurchaseDate?: string;
}

export interface MaterialPurchase {
  id: string;
  houseId: string;
  materialId: string;
  materialName: string;
  date: string;
  quantity: number;
  unit: string;
  pricePerUnit: number;
  totalPrice: number;
  supplier: string;
  paymentStatus: PaymentStatus;
  receiptUrl?: string;
  notes?: string;
}

export interface Expense {
  id: string;
  houseId: string;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  recipient: string;
  notes?: string;
  receiptUrl?: string;
  paymentProofUrl?: string;
  source?: string;
  voiceEntryId?: string;
}

export interface Payment {
  id: string;
  houseId: string;
  recipient: string;
  category: ExpenseCategory;
  amount: number;
  date: string;
  paymentMethod: PaymentMethod;
  reference?: string;
  notes?: string;
  paymentProofUrl?: string;
  receiptUrl?: string;
  status: PaymentStatus;
}

export interface BudgetItem {
  id: string;
  houseId: string;
  category: ExpenseCategory;
  budgetedAmount: number;
  spentAmount: number;
  remaining?: number;
  pctUsed?: number;
  alertLevel?: 'normal' | 'warning' | 'critical' | 'exceeded';
  alertMessage?: string;
  notes?: string;
}

export interface ConstructionStage {
  id: string;
  houseId: string;
  stageName: string;
  orderIdx: number;
  status: StageStatus;
  startDate?: string;
  targetDate?: string;
  actualCompletionDate?: string;
  percentageComplete: number;
  notes?: string;
}

export interface ProgressPhoto {
  id: string;
  houseId: string;
  stageName: string;
  photoUrl: string;
  date: string;
  description: string;
  notes?: string;
}

export interface BillReceipt {
  id: string;
  houseId: string;
  title: string;
  fileUrl: string;
  fileType: 'image' | 'pdf';
  date: string;
  category: ExpenseCategory;
  amount: number;
  supplier: string;
  status: 'Verified' | 'Pending Review';
  ocrData?: any;
}

export interface VoiceExtractedData {
  workers: {
    role: WorkerRole;
    count: number;
    wagePerPerson: number;
    subtotal: number;
  }[];
  materials: {
    name: string;
    quantity: number;
    unit: string;
    totalPrice: number;
  }[];
  expenses: {
    category: ExpenseCategory;
    description: string;
    amount: number;
  }[];
  labourTotal: number;
  materialTotal: number;
  grandTotal: number;
  summaryText: string;
  rawTeluguText: string;
  englishTranslation?: string;
}

export interface ConstructionLedgerItem {
  id: string;
  date: string;
  description: string;
  category: ExpenseCategory;
  amount: number;
  paymentStatus: PaymentStatus;
  paymentMethod?: string;
  recipientOrSupplier?: string;
  receiptUrl?: string;
  paymentProofUrl?: string;
  source: string;
  type: 'Labour' | 'Material' | 'Expense' | 'Payment';
  refId: string;
}

export interface SummaryData {
  house: House;
  today: string;
  yesterday: string;
  currentMonth: string;
  totalSpending: number;
  committedSpending: number;
  outstandingAmount: number;
  todaySpending: number;
  yesterdaySpending: number;
  thisMonthSpending: number;
  workersToday: number;
  todayLabourCost: number;
  pendingPayments: number;
  remainingBudget: number;
  constructionProgress: number;
  healthScore: number;
  spendingStreak: number;
  comparison: {
    diffAmount: number;
    diffPct: number;
    isHigher: boolean;
    text: string;
    breakdown: {
      category: string;
      todayAmount: number;
      yesterdayAmount: number;
      difference: number;
    }[];
  };
  categoryDistribution: {
    name: string;
    value: number;
    percentage: number;
    color: string;
  }[];
  dailySpendingHistory: {
    date: string;
    displayDate: string;
    amount: number;
    workers: number;
    labour: number;
    materials: number;
    electrical?: number;
    transport?: number;
    other: number;
  }[];
  monthlySpendingHistory: {
    month: string;
    amount: number;
    materials: number;
    labour: number;
    electrical?: number;
    transport?: number;
    other: number;
    workerDays?: number;
  }[];
  topInsights: {
    biggestCategory: { name: string; amount: number; pct: number };
    mostExpensiveMaterial: { name: string; amount: number };
    highestPaidWorker: { name: string; amount: number };
    biggestSinglePurchase: { name: string; amount: number };
    averageDailySpending: number;
    averageMonthlySpending: number;
  };
}
