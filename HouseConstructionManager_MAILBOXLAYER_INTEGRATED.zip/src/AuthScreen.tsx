import React, { useState } from 'react';
import { signIn, signUp, resetPassword } from './api/supabaseClient.js';
import { Lock, Mail, User, ArrowRight, Loader2, ShieldCheck } from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  const validateEmailWithMailboxlayer = async (value: string) => {
    const response = await fetch('/.netlify/functions/validate-email', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email: value.trim().toLowerCase() }),
    });
    const result = await response.json().catch(() => ({ ok: true, skipped: true }));
    if (result?.did_you_mean) {
      throw new Error(`Please check your email. Did you mean ${result.did_you_mean}?`);
    }
    if (result?.skipped !== true && result?.valid === false) {
      throw new Error(result.error || 'Please enter a valid email address.');
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg('');
    try {
      if (mode === 'signup') {
        await validateEmailWithMailboxlayer(email);
        const d = await signUp(email, password, name);
        if (!d.access_token) {
          setMsg('Account created. Check your email to confirm, then sign in.');
          setMode('login');
        } else {
          location.reload();
        }
      } else {
        await signIn(email, password);
        location.reload();
      }
    } catch (err: any) {
      const text = String(err?.message || 'Something went wrong');
      setMsg(text.toLowerCase().includes('already registered')
        ? 'An account already exists for this email. Sign in instead or use a different email.'
        : text);
    } finally {
      setBusy(false);
    }
  };

  const forgot = async () => {
    if (!email) return setMsg('Enter your email first.');
    try {
      await resetPassword(email);
      setMsg('Password reset email sent. Check your inbox.');
    } catch (err: any) {
      setMsg(err.message || 'Unable to send reset email.');
    }
  };

  return <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4"><div className="w-full max-w-md"><div className="text-center mb-8"><div className="mx-auto w-16 h-16 rounded-2xl bg-amber-500 flex items-center justify-center text-3xl shadow-lg shadow-amber-500/20">🏠</div><h1 className="text-3xl font-black text-white mt-4">House Construction Manager</h1><p className="text-slate-400 text-sm mt-2">Secure cloud workspace for your construction projects</p></div><div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl"><div className="flex gap-2 p-1 bg-slate-950 rounded-xl mb-6"><button onClick={()=>setMode('login')} className={`flex-1 py-2 rounded-lg text-sm font-bold ${mode==='login'?'bg-amber-500 text-slate-950':'text-slate-400'}`}>Login</button><button onClick={()=>setMode('signup')} className={`flex-1 py-2 rounded-lg text-sm font-bold ${mode==='signup'?'bg-amber-500 text-slate-950':'text-slate-400'}`}>Create Account</button></div><form onSubmit={submit} className="space-y-4">{mode==='signup'&&<div><label className="text-xs font-bold text-slate-300">Full Name</label><div className="relative mt-1"><User className="absolute left-3 top-3.5 w-4 h-4 text-slate-500"/><input required value={name} onChange={e=>setName(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-3 text-white outline-none focus:border-amber-500" placeholder="Your name"/></div></div>}<div><label className="text-xs font-bold text-slate-300">Email</label><div className="relative mt-1"><Mail className="absolute left-3 top-3.5 w-4 h-4 text-slate-500"/><input required type="email" value={email} onChange={e=>setEmail(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-3 text-white outline-none focus:border-amber-500" placeholder="you@example.com"/></div></div><div><label className="text-xs font-bold text-slate-300">Password</label><div className="relative mt-1"><Lock className="absolute left-3 top-3.5 w-4 h-4 text-slate-500"/><input required minLength={8} type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-3 text-white outline-none focus:border-amber-500" placeholder="At least 8 characters"/></div></div>{mode==='login'&&<button type="button" onClick={forgot} className="text-xs text-amber-400 hover:text-amber-300">Forgot password?</button>}{msg&&<div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">{msg}</div>}<button disabled={busy} className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-60 text-slate-950 font-black py-3 rounded-xl flex items-center justify-center gap-2">{busy?<Loader2 className="w-4 h-4 animate-spin"/>:<ArrowRight className="w-4 h-4"/>}{mode==='login'?'Login Securely':'Create My Account'}</button></form><div className="mt-5 text-[11px] text-slate-500 flex items-center gap-2 justify-center"><ShieldCheck className="w-4 h-4"/>Your project data is isolated to your account.</div></div></div></div>;
};
