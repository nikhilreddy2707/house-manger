import React, { useState } from 'react';
import {
  Search,
  Filter,
  Trash2,
  Edit2,
  Eye,
  FileText,
  Mic,
  Plus,
  Download,
  CheckCircle2,
  Clock,
  ExternalLink,
  Layers,
} from 'lucide-react';
import { ConstructionLedgerItem, ExpenseCategory } from '../../types.js';
import { ConfirmationDialog } from '../common/ConfirmationDialog.js';

interface ConstructionLedgerViewProps {
  ledger: ConstructionLedgerItem[];
  onDelete: (id: string) => void;
  onAddExpense: () => void;
  onViewReceipt: (url: string, title: string) => void;
}

export const ConstructionLedgerView: React.FC<ConstructionLedgerViewProps> = ({
  ledger,
  onDelete,
  onAddExpense,
  onViewReceipt,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sourceFilter, setSourceFilter] = useState<string>('All');
  const [deleteCandidate, setDeleteCandidate] = useState<ConstructionLedgerItem | null>(null);

  const categories: ExpenseCategory[] = [
    'Materials',
    'Labour',
    'Transport',
    'Electrical',
    'Plumbing',
    'Flooring',
    'Painting',
    'Contractor',
    'Equipment',
    'Other',
  ];

  // Filtering
  const filteredItems = ledger.filter(item => {
    if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;
    if (statusFilter !== 'All' && item.paymentStatus !== statusFilter) return false;
    if (sourceFilter === 'Voice' && !item.source?.includes('Voice')) return false;
    if (sourceFilter === 'Manual' && item.source?.includes('Voice')) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchCat = item.category.toLowerCase().includes(q);
      const matchParty = item.recipientOrSupplier?.toLowerCase().includes(q) || false;
      const matchSource = item.source?.toLowerCase().includes(q) || false;
      if (!matchDesc && !matchCat && !matchParty && !matchSource) return false;
    }
    return true;
  });

  const totalFilteredAmount = filteredItems.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            🧾 Complete Construction Money Ledger
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              ప్రధాన ఖాతా పుస్తకం
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            The single source of truth for all construction transactions, worker payments, and supplier bills.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onAddExpense}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
          >
            <Plus className="w-4 h-4" /> Add Record
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by item name, contractor, material, supplier, or invoice..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500/60 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
            />
          </div>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none w-full md:w-44"
          >
            <option value="All">All Categories</option>
            {categories.map(c => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          {/* Payment Status Filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none w-full md:w-36"
          >
            <option value="All">All Statuses</option>
            <option value="Paid">Paid</option>
            <option value="Pending">Pending</option>
          </select>

          {/* Source Filter */}
          <select
            value={sourceFilter}
            onChange={e => setSourceFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none w-full md:w-36"
          >
            <option value="All">All Sources</option>
            <option value="Voice">Voice Assistant</option>
            <option value="Manual">Manual</option>
          </select>
        </div>

        {/* Ledger Summary Stats */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
          <span>
            Showing <strong className="text-slate-200">{filteredItems.length}</strong> transactions
          </span>
          <span>
            Filtered Total: <strong className="text-amber-400 text-sm font-extrabold">₹{totalFilteredAmount.toLocaleString('en-IN')}</strong>
          </span>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] text-slate-400 uppercase bg-slate-950/80 border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4 font-bold">Date</th>
                <th className="py-3.5 px-4 font-bold">Description</th>
                <th className="py-3.5 px-4 font-bold">Category</th>
                <th className="py-3.5 px-4 font-bold">Party / Supplier</th>
                <th className="py-3.5 px-4 font-bold text-right">Amount</th>
                <th className="py-3.5 px-4 font-bold">Status</th>
                <th className="py-3.5 px-4 font-bold">Source</th>
                <th className="py-3.5 px-4 font-bold text-center">Receipt/Proof</th>
                <th className="py-3.5 px-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500 text-xs">
                    No transactions match your filters.
                  </td>
                </tr>
              ) : (
                filteredItems.map(item => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="py-3.5 px-4 font-medium text-slate-400 whitespace-nowrap">
                      {item.date}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-100 max-w-xs">
                      {item.description}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/80">
                        {item.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-400">
                      {item.recipientOrSupplier || '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-black text-slate-100 whitespace-nowrap">
                      ₹{item.amount.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          item.paymentStatus === 'Paid'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {item.paymentStatus === 'Paid' ? (
                          <CheckCircle2 className="w-3 h-3" />
                        ) : (
                          <Clock className="w-3 h-3" />
                        )}
                        {item.paymentStatus}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {item.source?.includes('Voice') ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400">
                          <Mic className="w-3 h-3" /> Voice
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400">{item.source || 'Manual'}</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {item.receiptUrl || item.paymentProofUrl ? (
                        <button
                          onClick={() =>
                            onViewReceipt(
                              item.receiptUrl || item.paymentProofUrl || '',
                              item.description
                            )
                          }
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 hover:text-white transition-colors"
                          title="View Proof / Receipt"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <span className="text-slate-600">—</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => setDeleteCandidate(item)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                        title="Delete Record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirmation Dialog for Destructive Delete (Section 46) */}
      <ConfirmationDialog
        isOpen={!!deleteCandidate}
        title="Delete this construction record?"
        message={`Are you sure you want to delete "${deleteCandidate?.description}" for ₹${deleteCandidate?.amount.toLocaleString('en-IN')}? This will update all totals and budget metrics.`}
        confirmLabel="Delete Record"
        cancelLabel="Keep Record"
        isDestructive={true}
        onConfirm={() => {
          if (deleteCandidate) {
            onDelete(deleteCandidate.refId || deleteCandidate.id);
            setDeleteCandidate(null);
          }
        }}
        onCancel={() => setDeleteCandidate(null)}
      />
    </div>
  );
};
