import React from 'react';
import {
  PieChart as PieChartIcon,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react';
import { BudgetItem } from '../../types.js';

interface BudgetViewProps {
  budgetData: {
    totalBudget: number;
    totalSpent: number;
    remainingBudget: number;
    pctUsed: number;
    categories: BudgetItem[];
  };
}

export const BudgetView: React.FC<BudgetViewProps> = ({ budgetData }) => {
  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            💵 Construction Budget & Overrun Protection
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              బడ్జెట్ ప్రణాళిక
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Automated threshold monitors alerting at 75%, 90% and 100% budget usage per category.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl text-emerald-400 text-xs font-bold">
          <ShieldCheck className="w-4 h-4" />
          <span>Overall Health: {budgetData.totalBudget ? `${Math.max(0, 100 - budgetData.pctUsed).toFixed(1)}% Budget Intact` : 'Budget not set'}</span>
        </div>
      </div>

      {/* Overall Budget KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Total Allocated Budget
          </span>
          <h3 className="text-3xl font-black text-slate-100 mt-1">
            ₹{budgetData.totalBudget.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">Target Capex</p>
        </div>

        <div className="p-6 rounded-3xl bg-slate-900/90 border border-amber-500/20 shadow-xl">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
            Total Actual Spent
          </span>
          <h3 className="text-3xl font-black text-amber-400 mt-1">
            ₹{budgetData.totalSpent.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">{budgetData.pctUsed}% of planned budget</p>
        </div>

        <div className="p-6 rounded-3xl bg-slate-900/90 border border-emerald-500/30 shadow-xl">
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
            Remaining Budget Buffer
          </span>
          <h3 className="text-3xl font-black text-emerald-400 mt-1">
            ₹{budgetData.remainingBudget.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">Uncommitted funds available</p>
        </div>
      </div>

      {/* Active Threshold Warning Banners (Section 31) */}
      <div className="space-y-3">
        {budgetData.categories
          .filter(c => c.alertLevel && c.alertLevel !== 'normal')
          .map((cat, i) => (
            <div
              key={i}
              className={`p-4 rounded-2xl border flex items-center justify-between gap-4 text-xs ${
                cat.alertLevel === 'exceeded'
                  ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                  : cat.alertLevel === 'critical'
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-200'
                  : 'bg-yellow-500/10 border-yellow-500/30 text-yellow-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <h4 className="font-extrabold text-sm">{cat.alertMessage}</h4>
                  <p className="text-[11px] opacity-80 mt-0.5">
                    {cat.category}: ₹{cat.spentAmount.toLocaleString('en-IN')} spent of ₹{cat.budgetedAmount.toLocaleString('en-IN')} planned.
                  </p>
                </div>
              </div>
              <span className="font-black text-sm">{cat.pctUsed}%</span>
            </div>
          ))}
      </div>

      {/* Category Budgets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {budgetData.categories.map(cat => {
          const pct = cat.pctUsed || 0;
          const remaining = (cat.budgetedAmount || 0) - (cat.spentAmount || 0);

          return (
            <div
              key={cat.id}
              className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="font-extrabold text-slate-100 text-base">{cat.category}</h4>
                  <p className="text-xs text-slate-400">{cat.notes || 'Allocated budget bucket'}</p>
                </div>

                <span
                  className={`text-xs font-black px-2.5 py-1 rounded-full ${
                    pct >= 100
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      : pct >= 90
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {pct}% Used
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    pct >= 100
                      ? 'bg-rose-500'
                      : pct >= 90
                      ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                      : 'bg-gradient-to-r from-amber-500 to-emerald-400'
                  }`}
                  style={{ width: `${Math.min(100, pct)}%` }}
                />
              </div>

              {/* Numbers breakdown */}
              <div className="grid grid-cols-3 gap-2 text-xs pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-[10px] text-slate-500 block">Budget</span>
                  <span className="font-bold text-slate-200">
                    ₹{cat.budgetedAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Spent</span>
                  <span className="font-black text-amber-400">
                    ₹{cat.spentAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Remaining</span>
                  <span
                    className={`font-extrabold ${
                      remaining < 0 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    ₹{remaining.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
