import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Users,
  IndianRupee,
  Calendar,
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  HardHat,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Mic,
  ChevronRight,
  Clock,
  Flame,
  ShieldCheck,
  CreditCard,
  Layers,
  ArrowRight,
  FileText,
  Package,
  Bell,
  Check,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend,
} from 'recharts';
import { SummaryData, Payment, ConstructionLedgerItem, Worker, Material } from '../../types.js';

interface DashboardViewProps {
  summary: SummaryData;
  ledger: ConstructionLedgerItem[];
  payments: Payment[];
  workers: Worker[];
  attendance: any[];
  materials: Material[];
  purchases: any[];
  onOpenVoice: () => void;
  onNavigate: (tab: any) => void;
  onMarkPaid: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  summary,
  ledger,
  payments,
  workers,
  attendance,
  materials,
  purchases,
  onOpenVoice,
  onNavigate,
  onMarkPaid,
}) => {
  const pendingPayments = payments.filter(p => p.status === 'Pending').slice(0, 4);

  const todayWorkers = attendance.filter(a => a.date === summary.today && a.status === 'Present')
    .map(a => workers.find(w => w.id === a.workerId)).filter(Boolean) as Worker[];
  const todayMaterialDeliveries = purchases.filter(p => p.date === summary.today);
  const budgetPct = summary.house.totalBudget > 0 ? (summary.totalSpending / summary.house.totalBudget) * 100 : 0;
  const remainingPct = Math.max(0, 100 - budgetPct);
  const comparisonText = summary.comparison.diffAmount === 0 ? 'Same as yesterday.' : `${Math.abs(summary.comparison.diffPct)}% ${summary.comparison.isHigher ? 'higher' : 'lower'} than yesterday.`;
  const roleCounts = todayWorkers.reduce((acc:any,w) => { acc[w.role]=(acc[w.role]||0)+1; return acc; }, {});

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* 1. HERO BANNER: 🎙️ TELUGU VOICE ASSISTANT CENTERPIECE (Section 4, 5, 56) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500/20 via-slate-900 to-amber-950/40 border border-amber-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute -right-10 -top-10 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5" />
              Telugu Construction Command Center
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight font-telugu">
              🎙️ నేటి పనిని చెప్పండి
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Tell today's workers, wages, bricks, cement, wires, or transport naturally. AI extracts structured records and prompts for your review before saving.
            </p>
          </div>

          <button
            onClick={onOpenVoice}
            className="group px-7 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm sm:text-base shadow-xl shadow-amber-500/30 flex items-center gap-3 transition-all transform hover:-translate-y-0.5 active:translate-y-0 active:scale-95 glow-amber"
          >
            <div className="p-2 rounded-xl bg-slate-950/20 text-slate-950 group-hover:rotate-12 transition-transform">
              <Mic className="w-5 h-5 animate-pulse" />
            </div>
            <span>Tell Today's Update</span>
            <span className="font-telugu text-sm font-bold border-l border-slate-950/20 pl-2">
              వాయిస్ ఎంట్రీ
            </span>
          </button>
        </div>
      </div>

      {/* 2. SMART ALERTS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3"><AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" /><div className="text-xs"><span className="font-bold text-amber-300 block">⚠️ Budget</span><p className="text-slate-300 text-[11px] mt-0.5">{summary.house.totalBudget ? `${budgetPct.toFixed(1)}% used • ${remainingPct.toFixed(1)}% available.` : 'Set a project budget in Settings.'}</p></div></div>
        <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3"><CreditCard className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" /><div className="text-xs"><span className="font-bold text-rose-300 block">💳 Pending Payments</span><p className="text-slate-300 text-[11px] mt-0.5">₹{summary.pendingPayments.toLocaleString('en-IN')} currently pending.</p></div></div>
        <div className="p-3.5 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-start gap-3"><TrendingUp className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" /><div className="text-xs"><span className="font-bold text-blue-300 block">📈 Spending</span><p className="text-slate-300 text-[11px] mt-0.5">{comparisonText}</p></div></div>
        <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3"><HardHat className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" /><div className="text-xs"><span className="font-bold text-emerald-300 block">🏗️ Progress</span><p className="text-slate-300 text-[11px] mt-0.5">Project progress is {summary.constructionProgress}%.</p></div></div>
      </div>

      {/* 3. 9 PRIMARY KPI CARDS (Section 5) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Spending */}
        <div className="col-span-2 sm:col-span-1 p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>Total Spending</span>
            <IndianRupee className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-2xl font-black text-slate-100 tracking-tight">
            ₹{summary.totalSpending.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-bold">{budgetPct.toFixed(1)}%</span> of ₹{summary.house.totalBudget.toLocaleString('en-IN')} budget
          </p>
        </div>

        {/* Today's Spending */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span className="font-telugu">నేటి ఖర్చు (Today)</span>
            <Calendar className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-2xl font-black text-amber-400 tracking-tight">
            ₹{summary.todaySpending.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-slate-400 mt-1">{summary.today}</p>
        </div>

        {/* Yesterday's Spending */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>Yesterday (నిన్న)</span>
            <Clock className="w-4 h-4 text-slate-400" />
          </div>
          <h3 className="text-2xl font-black text-slate-300 tracking-tight">
            ₹{summary.yesterdaySpending.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-slate-500 mt-1">{summary.yesterday}</p>
        </div>

        {/* This Month */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>This Month ({summary.currentMonth})</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <h3 className="text-2xl font-black text-slate-100 tracking-tight">
            ₹{summary.thisMonthSpending.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-slate-400 mt-1">{summary.currentMonth} MTD</p>
        </div>

        {/* Workers Today */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>Workers Today</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-2xl font-black text-slate-100 tracking-tight">
            {summary.workersToday} <span className="text-sm font-medium text-slate-400">workers</span>
          </h3>
          <p className="text-[11px] text-slate-400 mt-1">{Object.entries(roleCounts).map(([r,c]) => `${c} ${r}`).join(', ') || 'No attendance recorded'}</p>
        </div>

        {/* Today's Labour Cost */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>Today's Labour</span>
            <IndianRupee className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-2xl font-black text-slate-100 tracking-tight">
            ₹{summary.todayLabourCost.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-slate-400 mt-1">Daily Wages Paid</p>
        </div>

        {/* Pending Payments */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-rose-500/20 shadow-xl relative overflow-hidden group hover:border-rose-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>Pending Payments</span>
            <AlertCircle className="w-4 h-4 text-rose-400" />
          </div>
          <h3 className="text-2xl font-black text-rose-400 tracking-tight">
            ₹{summary.pendingPayments.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-rose-400/80 mt-1">Contractors & Suppliers</p>
        </div>

        {/* Remaining Budget */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-emerald-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>Remaining Budget</span>
            <CreditCard className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-2xl font-black text-emerald-400 tracking-tight">
            ₹{summary.remainingBudget.toLocaleString('en-IN')}
          </h3>
          <p className="text-[11px] text-slate-400 mt-1">{remainingPct.toFixed(1)}% Available</p>
        </div>

        {/* Construction Progress */}
        <div className="col-span-2 sm:col-span-1 p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-2">
            <span>House Progress</span>
            <HardHat className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-2xl font-black text-slate-100 tracking-tight">
              {summary.constructionProgress}%
            </h3>
            <span className="text-[11px] text-amber-400 font-semibold">Current progress</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full"
              style={{ width: `${summary.constructionProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* 4. TODAY VS YESTERDAY INTERACTIVE COMPARISON (Section 6) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-2xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
              Interactive Daily Comparison (నిన్న vs నేడు)
            </span>
            <h3 className="text-xl font-black text-slate-100 mt-0.5">
              Today vs Yesterday Spending
            </h3>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-extrabold">
              <ArrowUpRight className="w-4 h-4" />
              <span>↑ ₹{summary.comparison.diffAmount.toLocaleString('en-IN')} (+{summary.comparison.diffPct}%)</span>
            </div>
            <button
              onClick={() => onNavigate('daily')}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 hover:text-white transition-colors flex items-center gap-1"
            >
              View Day Breakdown <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Big visual comparison cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-5">
          <div className="p-5 rounded-2xl bg-amber-500/5 border border-amber-500/20 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">TODAY ({summary.today})</span>
              <h4 className="text-3xl font-black text-slate-100 mt-1">
                ₹{summary.todaySpending.toLocaleString('en-IN')}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">{todayWorkers.length} workers • {todayMaterialDeliveries.length} material deliveries</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-lg">
              📅
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">YESTERDAY ({summary.yesterday})</span>
              <h4 className="text-3xl font-black text-slate-300 mt-1">
                ₹{summary.yesterdaySpending.toLocaleString('en-IN')}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">{(attendance.filter(a => a.date === summary.yesterday && (a.status === 'Present' || a.status === 'Half Day'))).length} workers • recorded transactions</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-300 flex items-center justify-center font-bold text-lg">
              ⏮️
            </div>
          </div>
        </div>

        {/* Why spending changed: Category delta pills */}
        <div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
            Today vs yesterday by category:
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {summary.comparison.breakdown.slice(0, 4).map(item => (
              <div key={item.category} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div><p className="text-[11px] text-slate-400 font-medium">{item.category}</p><p className="text-xs font-bold text-slate-200 mt-0.5">₹{item.todayAmount.toLocaleString('en-IN')} vs ₹{item.yesterdayAmount.toLocaleString('en-IN')}</p></div>
                <span className={`text-xs font-black ${item.difference >= 0 ? 'text-amber-400' : 'text-emerald-400'}`}>{item.difference >= 0 ? '+' : '-'}₹{Math.abs(item.difference).toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 5. CHARTS & MONEY DISTRIBUTION (Sections 7, 8, 34) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Spending Chart */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-base font-extrabold text-slate-100">Daily Spending Trend</h3>
              <p className="text-xs text-slate-400">Day-to-day spending pattern for this project</p>
            </div>
            <button
              onClick={() => onNavigate('daily')}
              className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
            >
              See All Days <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={summary.dailySpendingHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="displayDate" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis
                  stroke="#64748b"
                  fontSize={11}
                  tickFormatter={val => `₹${(val / 1000).toFixed(0)}k`}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    fontSize: '12px',
                  }}
                  formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Amount']}
                />
                <Bar dataKey="amount" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* "Where is my money going?" Donut Chart (Section 34) */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-base font-extrabold text-slate-100">Where Is My Money Going?</h3>
              <span className="text-xs text-amber-400 font-telugu font-bold">ఖర్చుల విభజన</span>
            </div>
            <p className="text-xs text-slate-400 mb-4">Category-wise percentage distribution</p>

            <div className="h-44 w-full relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={summary.categoryDistribution}
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="percentage"
                  >
                    {summary.categoryDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '12px',
                      fontSize: '12px',
                    }}
                    formatter={(val: any, name: any) => [`${val}%`, name]}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute text-center pointer-events-none">
                <span className="text-xs text-slate-400 block font-medium">Top Share</span>
                <span className="text-lg font-black text-amber-400">{summary.categoryDistribution[0]?.percentage || 0}%</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800">
            {summary.categoryDistribution.map((cat, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
                <span className="text-xs text-slate-300 font-medium truncate">{cat.name}</span>
                <span className="text-xs font-bold text-slate-400 ml-auto">{cat.percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 6. TODAY'S WORKERS & TODAY'S MATERIALS (Section 56 Exact Hierarchy) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Workers Card */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                  <span>👷</span> Today's Workers (నేటి వర్కర్లు)
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {todayWorkers.length} Present
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Daily labour wages: ₹{summary.todayLabourCost.toLocaleString('en-IN')}
                </p>
              </div>
              <button
                onClick={() => onNavigate('workers')}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
              >
                Manage All <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {todayWorkers.slice(0, 6).map(w => (
                <div
                  key={w.id}
                  className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-slate-800 text-amber-400 font-bold flex items-center justify-center text-xs">
                      {w.name.charAt(0)}
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-200">{w.name}</h5>
                      <span className="text-[10px] text-slate-400">{w.role}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-amber-400">₹{w.dailyWage}</span>
                    <span className="block text-[9px] text-emerald-400 font-bold">Present</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">{Object.entries(roleCounts).map(([r,c]) => `${c} ${r}`).join(', ') || 'No workers recorded today'}</span>
            <span className="font-black text-slate-200">Labour: ₹{summary.todayLabourCost.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Today's Materials Card */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                  <span>🧱</span> Today's Materials (నేడు వచ్చిన సామాగ్రి)
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    {todayMaterialDeliveries.length} Deliveries
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Deliveries recorded for {summary.today}
                </p>
              </div>
              <button
                onClick={() => onNavigate('materials')}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
              >
                Catalog <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {todayMaterialDeliveries.slice(0, 6).map((mat, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs"
                >
                  <div>
                    <h5 className="font-bold text-slate-200">{mat.name}</h5>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {mat.quantity} {mat.unit} • From {mat.supplier}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-amber-400">₹{Number(mat.totalPrice || 0).toLocaleString('en-IN')}</span>
                    <span className="block text-[9px] text-emerald-400 font-bold">{mat.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">Material Subtotal Today</span>
            <span className="font-black text-slate-100">₹{todayMaterialDeliveries.reduce((sum, m) => sum + Number(m.totalPrice || 0), 0).toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* 7. HEALTH SCORE, STREAK & PENDING PAYMENTS (Section 24, 57) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Construction Health & Streak Card */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-extrabold text-slate-100">Construction Health</h3>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-black text-sm border border-emerald-500/20">
              {summary.healthScore}/100
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Budget Adherence:</span>
              <span className="text-emerald-400 font-bold">{budgetPct.toFixed(1)}% used</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Attendance Reliability:</span>
              <span className="text-emerald-400 font-bold">{workers.length ? Math.round((workers.filter(w => w.status === 'active').length / workers.length) * 100) : 0}% Active</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Pending Dues Ratio:</span>
              <span className="text-amber-400 font-bold">{summary.totalSpending ? Math.round((summary.pendingPayments / summary.totalSpending) * 100) : 0}% of spending</span>
            </div>
          </div>

          {/* Streak */}
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold">
              <Flame className="w-5 h-5 animate-bounce-soft" />
            </div>
            <div>
              <p className="text-xs font-bold text-amber-400">{summary.spendingStreak}-Day Spending Streak 🔥</p>
              <p className="text-[11px] text-slate-300">
                Construction expenses recorded consecutively for 14 days.
              </p>
            </div>
          </div>
        </div>

        {/* Pending Payments Widget (Section 24) */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                  Pending Payments
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
                    ₹{summary.pendingPayments.toLocaleString('en-IN')} Due
                  </span>
                </h3>
                <p className="text-xs text-slate-400">Contractors, technicians, and material suppliers</p>
              </div>
              <button
                onClick={() => onNavigate('payments')}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
              >
                All Payments <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {pendingPayments.map(pay => (
                <div
                  key={pay.id}
                  className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <h5 className="font-bold text-slate-200">{pay.recipient}</h5>
                    <p className="text-[11px] text-slate-400 mt-0.5">{pay.notes || pay.category}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-extrabold text-rose-400">
                      ₹{pay.amount.toLocaleString('en-IN')}
                    </span>
                    <button
                      onClick={() => onMarkPaid(pay.id)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/30 font-bold text-xs transition-all"
                    >
                      Mark as Paid
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 8. RECENT TRANSACTIONS LEDGER PREVIEW (Section 9, 56) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-extrabold text-slate-100">Recent Construction Transactions</h3>
            <p className="text-xs text-slate-400">Single source of truth ledger items</p>
          </div>
          <button
            onClick={() => onNavigate('ledger')}
            className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
          >
            Open Full Ledger <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] text-slate-400 uppercase bg-slate-950/60 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 rounded-l-xl">Date</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 rounded-r-xl">Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {ledger.slice(0, 6).map(item => (
                <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-medium text-slate-400">{item.date}</td>
                  <td className="py-3.5 px-4 font-bold text-slate-200">{item.description}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                      {item.category}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-extrabold text-slate-100">
                    ₹{item.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`px-2 py-0.5 rounded-full font-semibold text-[10px] ${
                        item.paymentStatus === 'Paid'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}
                    >
                      {item.paymentStatus}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-400">
                    {item.source === 'Voice Assistant' ? (
                      <span className="inline-flex items-center gap-1 text-amber-400 font-bold">
                        <Mic className="w-3 h-3" /> Voice
                      </span>
                    ) : (
                      item.source
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
