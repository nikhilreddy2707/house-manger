import React, { useState } from 'react';
import {
  Search,
  Plus,
  Mic,
  Sparkles,
  HelpCircle,
  RotateCcw,
  Bell,
  Menu,
  Languages,
  ChevronDown,
  PlusCircle,
  Check,
} from 'lucide-react';

interface HeaderProps {
  onOpenVoice: () => void;
  onOpenAssistant: () => void;
  onQuickAction: (action: string) => void;
  onSearch: (term: string) => void;
  onResetDemo: () => void;
  onOpenMobileMenu: () => void;
  projects: { id: string; name: string; location?: string; active?: boolean }[];
  activeProjectId: string;
  onSwitchProject: (id: string) => void;
  onCreateProject: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenVoice,
  onOpenAssistant,
  onQuickAction,
  onSearch,
  onResetDemo,
  onOpenMobileMenu,
  projects,
  activeProjectId,
  onSwitchProject,
  onCreateProject,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showQuickMenu, setShowQuickMenu] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    onSearch(e.target.value);
  };

  return (
    <header className="sticky top-0 z-20 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 px-4 lg:px-8 py-3.5 flex items-center justify-between gap-4">
      {/* Mobile Menu Button & Title */}
      <div className="flex items-center gap-3 lg:hidden">
        <button
          onClick={onOpenMobileMenu}
          className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors"
        >
          <Menu className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <span className="text-xl">🏠</span>
          <span className="font-extrabold text-sm text-slate-100 tracking-tight">House Manager</span>
        </div>
      </div>

      {/* Desktop Greeting Header */}
      <div className="hidden lg:block">
        <h2 className="text-lg font-extrabold text-slate-100 flex items-center gap-2">
          Good morning <span className="animate-bounce">👋</span>
          <span className="text-xs font-normal text-amber-400 font-telugu ml-2 px-2 py-0.5 bg-amber-500/10 rounded-full border border-amber-500/20">
            శుభోదయం
          </span>
        </h2>
        <p className="text-xs text-slate-400 font-medium">
          Here's what's happening with your construction.
        </p>
      </div>

      {/* Project Switcher */}
      <div className="relative hidden sm:block">
        <select
          value={activeProjectId}
          onChange={e => e.target.value === '__create__' ? onCreateProject() : onSwitchProject(e.target.value)}
          className="appearance-none bg-slate-900 border border-slate-800 hover:border-amber-500/40 rounded-xl pl-3 pr-8 py-2 text-xs font-bold text-slate-100 outline-none cursor-pointer max-w-[220px]"
          aria-label="Switch construction project"
        >
          {projects.map(project => (
            <option key={project.id} value={project.id}>{project.name || 'Untitled Project'}</option>
          ))}
          <option value="__create__">＋ Create New Project</option>
        </select>
        <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-amber-400" />
      </div>

      {/* Global Search */}
      <div className="flex-1 max-w-md hidden md:block">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search worker, material, expense, bill, payment..."
            value={searchTerm}
            onChange={handleSearchChange}
            className="w-full bg-slate-900/80 border border-slate-800 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/30 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 transition-all outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => { setSearchTerm(''); onSearch(''); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-200"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2.5">
        {/* Natural Language Assistant Trigger */}
        <button
          onClick={onOpenAssistant}
          title="Ask Assistant in Telugu or English"
          className="flex items-center gap-2 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-amber-400 border border-slate-800 rounded-xl text-xs font-semibold transition-all shadow-sm group"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400 group-hover:rotate-12 transition-transform" />
          <span className="hidden sm:inline">Ask Assistant</span>
          <span className="text-[10px] font-telugu text-amber-400/80 hidden xl:inline">సహాయకుడు</span>
        </button>

        {/* Global Quick Add Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowQuickMenu(!showQuickMenu)}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 rounded-xl text-xs font-semibold transition-colors"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Quick Add</span>
          </button>

          {showQuickMenu && (
            <>
              <div className="fixed inset-0 z-20" onClick={() => setShowQuickMenu(false)} />
              <div className="absolute right-0 mt-2 w-52 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl py-2 z-30 text-xs text-slate-200 divide-y divide-slate-800/60">
                <div className="py-1">
                  <button
                    onClick={() => { setShowQuickMenu(false); onQuickAction('add-worker'); }}
                    className="w-full px-4 py-2 text-left hover:bg-slate-800/80 flex items-center gap-2.5 font-medium"
                  >
                    <span>👷</span> Add Worker (వర్కర్ చేర్చు)
                  </button>
                  <button
                    onClick={() => { setShowQuickMenu(false); onQuickAction('add-material'); }}
                    className="w-full px-4 py-2 text-left hover:bg-slate-800/80 flex items-center gap-2.5 font-medium"
                  >
                    <span>🧱</span> Add Material (మెటీరియల్)
                  </button>
                  <button
                    onClick={() => { setShowQuickMenu(false); onQuickAction('add-expense'); }}
                    className="w-full px-4 py-2 text-left hover:bg-slate-800/80 flex items-center gap-2.5 font-medium"
                  >
                    <span>💰</span> Add Expense (ఖర్చు)
                  </button>
                  <button
                    onClick={() => { setShowQuickMenu(false); onQuickAction('record-payment'); }}
                    className="w-full px-4 py-2 text-left hover:bg-slate-800/80 flex items-center gap-2.5 font-medium"
                  >
                    <span>💳</span> Record Payment (చెల్లింపు)
                  </button>
                </div>
                <div className="py-1">
                  <button
                    onClick={() => { setShowQuickMenu(false); onQuickAction('add-photo'); }}
                    className="w-full px-4 py-2 text-left hover:bg-slate-800/80 flex items-center gap-2.5 font-medium text-amber-400"
                  >
                    <span>📸</span> Add Construction Photo
                  </button>
                  <button
                    onClick={() => { setShowQuickMenu(false); onQuickAction('add-bill'); }}
                    className="w-full px-4 py-2 text-left hover:bg-slate-800/80 flex items-center gap-2.5 font-medium"
                  >
                    <span>🧾</span> Add Bill / Receipt
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* The Main Voice Action in Header */}
        <button
          onClick={onOpenVoice}
          className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-xs shadow-lg shadow-amber-500/20 transition-all transform active:scale-95"
        >
          <Mic className="w-4 h-4 animate-pulse" />
          <span className="hidden sm:inline">Tell Update</span>
          <span className="font-telugu text-[11px] font-bold">వాయిస్</span>
        </button>

        {/* Reset Demo Button */}
        <button
          onClick={onResetDemo}
          title="Reset Demo Data"
          className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent hover:border-slate-800 rounded-xl transition-all"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
