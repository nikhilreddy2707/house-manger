import React from 'react';
import { Home, Calendar, PlusCircle, BarChart3, Menu, Mic } from 'lucide-react';
import { NavItemKey } from './Sidebar.js';

interface MobileNavProps {
  currentTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  onOpenVoice: () => void;
  onOpenMoreMenu: () => void;
  onQuickAdd: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenVoice,
  onOpenMoreMenu,
  onQuickAdd,
}) => {
  return (
    <>
      {/* Floating Center Microphone Button for Mobile */}
      <div className="fixed bottom-14 left-1/2 -translate-x-1/2 z-40 lg:hidden">
        <button
          onClick={onOpenVoice}
          className="relative group p-4 rounded-full bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-300 text-slate-950 font-black shadow-2xl shadow-amber-500/50 border-4 border-slate-950 transform active:scale-95 transition-all glow-amber"
          title="Tell Today's Update (నేటి పనిని చెప్పండి)"
        >
          <Mic className="w-6 h-6 animate-pulse" />
          <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-500 ring-2 ring-slate-950 animate-ping" />
        </button>
      </div>

      {/* Bottom Bar */}
      <nav className="fixed bottom-0 inset-x-0 z-30 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 py-2 px-3 flex items-center justify-between lg:hidden shadow-2xl">
        <button
          onClick={() => onSelectTab('dashboard')}
          className={`flex flex-col items-center gap-1 flex-1 py-1 transition-colors ${
            currentTab === 'dashboard' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px]">Home</span>
        </button>

        <button
          onClick={() => onSelectTab('daily')}
          className={`flex flex-col items-center gap-1 flex-1 py-1 transition-colors ${
            currentTab === 'daily' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-5 h-5" />
          <span className="text-[10px]">Work</span>
        </button>

        {/* Placeholder spacer for floating mic */}
        <div className="w-12 pointer-events-none" />

        <button
          onClick={() => onSelectTab('reports')}
          className={`flex flex-col items-center gap-1 flex-1 py-1 transition-colors ${
            currentTab === 'reports' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-5 h-5" />
          <span className="text-[10px]">Reports</span>
        </button>

        <button
          onClick={onOpenMoreMenu}
          className="flex flex-col items-center gap-1 flex-1 py-1 text-slate-400 hover:text-slate-200 transition-colors"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px]">More</span>
        </button>
      </nav>
    </>
  );
};
