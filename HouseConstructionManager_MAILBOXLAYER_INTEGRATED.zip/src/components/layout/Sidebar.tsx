import React from 'react';
import {
  Home,
  Calendar,
  Users,
  Layers,
  IndianRupee,
  CreditCard,
  PieChart,
  HardHat,
  BarChart3,
  Mic,
  Receipt,
  Settings,
  Sparkles,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

export type NavItemKey =
  | 'dashboard'
  | 'daily'
  | 'workers'
  | 'materials'
  | 'expenses'
  | 'ledger'
  | 'payments'
  | 'budget'
  | 'progress'
  | 'reports'
  | 'voice'
  | 'bills'
  | 'settings';

interface SidebarProps {
  currentTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  onOpenVoice: () => void;
  healthScore?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  onOpenVoice,
  healthScore = 82,
}) => {
  const navItems = [
    { key: 'dashboard', label: 'Dashboard', icon: Home, telugu: 'డ్యాష్‌బోర్డ్' },
    { key: 'daily', label: 'Daily Work', icon: Calendar, telugu: 'నేటి పని & ఖర్చు' },
    { key: 'workers', label: 'Workers', icon: Users, telugu: 'కూలీలు / కార్మికులు' },
    { key: 'materials', label: 'Materials', icon: Layers, telugu: 'నిర్మాణ సామాగ్రి' },
    { key: 'expenses', label: 'Expenses', icon: IndianRupee, telugu: 'మొత్తం ఖర్చులు' },
    { key: 'ledger', label: 'Money Ledger', icon: IndianRupee, telugu: 'డబ్బు లెడ్జర్' },
    { key: 'payments', label: 'Payments', icon: CreditCard, telugu: 'చెల్లింపులు & బకాయి' },
    { key: 'budget', label: 'Budget', icon: PieChart, telugu: 'బడ్జెట్ నిర్వహణ' },
    { key: 'progress', label: 'Progress', icon: HardHat, telugu: 'నిర్మాణ ప్రగతి' },
    { key: 'reports', label: 'Reports', icon: BarChart3, telugu: 'నివేదికలు (Reports)' },
    { key: 'voice', label: 'Voice Assistant', icon: Mic, telugu: 'తెలుగు వాయిస్ అసిస్టెంట్', highlight: true },
    { key: 'bills', label: 'Bills & Receipts', icon: Receipt, telugu: 'బిల్లులు & రసీదులు' },
    { key: 'settings', label: 'Settings', icon: Settings, telugu: 'సెట్టింగులు' },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-72 bg-slate-900/90 border-r border-slate-800 backdrop-blur-xl h-screen sticky top-0 select-none z-30">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-300 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950 font-extrabold text-xl">
            🏠
          </div>
          <div>
            <h1 className="font-extrabold text-slate-100 text-base leading-tight tracking-tight">
              House Construction
            </h1>
            <p className="text-xs text-amber-400/90 font-medium font-telugu">
              గృహ నిర్మాణ మేనేజర్
            </p>
          </div>
        </div>
      </div>

      {/* Voice CTA Button in Sidebar */}
      <div className="px-4 pt-5 pb-2">
        <button
          onClick={onOpenVoice}
          className="w-full relative group overflow-hidden rounded-2xl p-[1px] focus:outline-none transition-transform active:scale-[0.98]"
        >
          <span className="absolute inset-0 bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 rounded-2xl transition-all duration-300 group-hover:opacity-100 opacity-90 animate-pulse-slow" />
          <div className="relative px-4 py-3 bg-slate-950/80 rounded-2xl flex items-center justify-between gap-3 text-white transition-all group-hover:bg-slate-950/50">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-500 text-slate-950 rounded-xl shadow-md font-bold">
                <Mic className="w-5 h-5 animate-pulse" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-amber-300 tracking-wide uppercase">Voice Update</p>
                <p className="text-sm font-extrabold text-white font-telugu">నేటి పనిని చెప్పండి</p>
              </div>
            </div>
            <Sparkles className="w-4 h-4 text-amber-400 group-hover:rotate-12 transition-transform" />
          </div>
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto px-4 py-3 space-y-1">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onSelectTab(item.key as NavItemKey)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                isActive
                  ? 'bg-amber-500/10 text-amber-400 font-bold border border-amber-500/20 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-amber-400' : 'text-slate-500 group-hover:text-slate-300'
                  }`}
                />
                <span className="tracking-wide">{item.label}</span>
              </div>
              {isActive && (
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400/50" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Health Score Mini Card */}
      <div className="p-4 m-4 rounded-2xl bg-gradient-to-b from-slate-800/80 to-slate-900 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-slate-300">Construction Health</span>
          </div>
          <span className="text-xs font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            {healthScore}/100
          </span>
        </div>
        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full transition-all duration-700"
            style={{ width: `${healthScore}%` }}
          />
        </div>
        <p className="text-[11px] text-slate-400 leading-tight">
          Budget on track • 14-day record streak
        </p>
      </div>

      {/* User Footer */}
      <div className="p-4 border-t border-slate-800/80 flex items-center justify-between bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-slate-700 to-slate-800 border border-slate-700 flex items-center justify-center text-sm font-bold text-amber-400 shadow">
            VS
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-200 truncate">Venkata Satyanarayana</p>
            <p className="text-[10px] text-slate-400 truncate">Dream Haven Villa</p>
          </div>
        </div>
      </div>
    </aside>
  );
};
