import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Send,
  HelpCircle,
  MessageSquare,
  Bot,
  RefreshCw,
  TrendingUp,
  Volume2,
} from 'lucide-react';
import { api } from '../../api/apiClient.js';

interface AssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  answerTelugu?: string;
  answerEnglish?: string;
  metricValue?: string;
  timestamp: string;
}

const COMMON_QUESTIONS = [
  'ఈరోజు ఎంత ఖర్చు చేశాను? (Today\'s spend?)',
  'నిన్న ఎంత ఖర్చు చేశాను? (Yesterday\'s spend?)',
  'ఎంత మంది వర్కర్స్ ఈరోజు వచ్చారు? (Workers today?)',
  'రవి కి ఎంత డబ్బు ఇచ్చాను? (How much paid to Ravi?)',
  'సిమెంట్ మీద ఎంత ఖర్చు చేశాను? (Cement spend?)',
  'కాంట్రాక్టర్ కి ఇంకా ఎంత ఇవ్వాలి? (Contractor pending?)',
  'ఇంకా నా బడ్జెట్ లో ఎంత ఉంది? (Remaining budget?)',
  'Which material is costing the most?',
  'What percentage of the house is complete?',
];

export const AssistantDrawer: React.FC<AssistantDrawerProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init_1',
      sender: 'assistant',
      text: 'నమస్కారం! నేను మీ గృహ నిర్మాణ సహాయకుడిని (Construction Assistant). మీరు నన్ను తెలుగులో లేదా ఇంగ్లీషులో మీ ఖర్చులు, లేబర్, మెటీరియల్స్, బకాయిల గురించి ఏదైనా అడగవచ్చు. (Ask me any question in Telugu or English).',
      answerTelugu: 'నమస్కారం! మీ ఖర్చులు మరియు నిర్మాణ వివరాల గురించి నన్ను అడగండి.',
      answerEnglish: 'Hello! Ask me any question regarding your construction spending, workers, or budget.',
      timestamp: 'Just now',
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const speakMessage = (text: string, lang = 'te-IN') => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      window.speechSynthesis.speak(utterance);
    }
  };

  if (!isOpen) return null;

  const handleSend = async (queryToSend: string) => {
    const q = queryToSend.trim();
    if (!q) return;

    const userMsg: Message = {
      id: `msg_${Date.now()}`,
      sender: 'user',
      text: q,
      timestamp: 'Just now',
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const response = await api.queryAssistant(q);
      const assistantMsg: Message = {
        id: `msg_resp_${Date.now()}`,
        sender: 'assistant',
        text: response.answerEnglish,
        answerTelugu: response.answerTelugu,
        answerEnglish: response.answerEnglish,
        metricValue: response.metricValue,
        timestamp: 'Just now',
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Query error:', err);
      setMessages(prev => [
        ...prev,
        {
          id: `msg_err_${Date.now()}`,
          sender: 'assistant',
          text: 'క్షమించండి, సర్వర్ నుండి వివరాలు పొందలేకపోయాను. దయచేసి మళ్ళీ ప్రయత్నించండి.',
          timestamp: 'Just now',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl relative">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-100 flex items-center gap-2">
                Construction Assistant
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Live Database
                </span>
              </h3>
              <p className="text-xs text-amber-400 font-telugu font-medium">
                తెలుగు & ఇంగ్లీష్ నిర్మాణ సహాయకుడు
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[90%] rounded-2xl p-4 text-xs leading-relaxed shadow-lg ${
                  msg.sender === 'user'
                    ? 'bg-amber-500 text-slate-950 font-bold font-telugu'
                    : 'bg-slate-950/80 border border-slate-800 text-slate-200'
                }`}
              >
                {msg.sender === 'assistant' ? (
                  <div>
                    {msg.metricValue && (
                      <div className="flex items-center justify-between gap-2 mb-2.5">
                        <div className="inline-block px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-extrabold text-sm">
                          {msg.metricValue}
                        </div>
                        {msg.answerTelugu && (
                          <button
                            type="button"
                            onClick={() => speakMessage(msg.answerTelugu || msg.text)}
                            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-400 hover:text-white transition-colors"
                            title="Listen in Telugu (వినండి)"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}
                    {msg.answerTelugu && (
                      <p className="font-telugu text-amber-300 font-semibold mb-2 leading-relaxed text-[13px]">
                        {msg.answerTelugu}
                      </p>
                    )}
                    {msg.answerEnglish && (
                      <p className="text-slate-300 pt-2 border-t border-slate-800/80">
                        {msg.answerEnglish}
                      </p>
                    )}
                    {!msg.answerTelugu && !msg.answerEnglish && <p>{msg.text}</p>}
                  </div>
                ) : (
                  <p>{msg.text}</p>
                )}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 px-1">{msg.timestamp}</span>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 p-3 bg-slate-950/60 rounded-2xl border border-slate-800 w-fit">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              <span className="text-xs text-slate-400 font-telugu">డేటాబేస్ విశ్లేషిస్తోంది...</span>
            </div>
          )}
        </div>

        {/* Suggested Quick Questions */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Suggested Inquiries (త్వరిత ప్రశ్నలు):
          </p>
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {COMMON_QUESTIONS.slice(0, 5).map((q, i) => (
              <button
                key={i}
                onClick={() => handleSend(q.split(' (')[0])}
                className="whitespace-nowrap px-3 py-1.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-[11px] text-slate-300 hover:text-amber-400 border border-slate-700/60 transition-colors font-telugu"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Query Input Box */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/90">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSend(inputQuery);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask anything in Telugu or English (ఉదా: ఈరోజు ఖర్చు ఎంత?)"
              value={inputQuery}
              onChange={e => setInputQuery(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-800 focus:border-amber-500/60 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder:text-slate-500 outline-none font-telugu"
            />
            <button
              type="submit"
              disabled={!inputQuery.trim() || isLoading}
              className="p-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 rounded-xl font-bold transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
