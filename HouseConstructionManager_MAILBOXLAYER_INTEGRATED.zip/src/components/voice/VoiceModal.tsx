import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Sparkles,
  Check,
  X,
  Edit3,
  AlertCircle,
  Save,
  Volume2,
  HelpCircle,
  RefreshCw,
  Plus,
  Trash2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { VoiceExtractedData, WorkerRole, ExpenseCategory } from '../../types.js';
import { api } from '../../api/apiClient.js';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  showToast: (title: string, message?: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
}

const PRESET_EXAMPLES = [
  {
    title: '4 Masons + 3 Helpers + 4000 Bricks + Wires',
    text: 'ఈరోజు నలుగురు మేస్త్రీలు వచ్చారు. ఒక్కొక్కరికి 800 రూపాయలు ఇచ్చాను. ముగ్గురు హెల్పర్లు వచ్చారు, ఒక్కొక్కరికి 500 రూపాయలు ఇచ్చాను. 4000 ఇటుకలు వచ్చాయి, వాటికి 40 వేల రూపాయలు అయ్యాయి. ఎలక్ట్రికల్ వైర్లు 4500 రూపాయలు అయ్యాయి.',
    badge: 'Standard Workday',
  },
  {
    title: '5 Masons + 2 Helpers + 3000 Bricks + 10 Cement + Transport',
    text: 'ఈరోజు ఐదుగురు మేస్త్రీలు వచ్చారు. ఒక్కొక్కరికి 800 ఇచ్చాను. ఇద్దరు హెల్పర్లు వచ్చారు. ఒక్కొక్కరికి 500 ఇచ్చాను. 3000 ఇటుకలు 30000 రూపాయలు. 10 బస్తాల సిమెంట్ 4200 రూపాయలు. వైర్లు 5000 రూపాయలు. ట్రాన్స్పోర్ట్ 1000.',
    badge: 'Heavy Material Day',
  },
  {
    title: 'English / Mixed Site Update',
    text: 'Today 4 masons came 800 each. 3 helpers 500 each. 4000 bricks 40000 rupees. Electrical wire 4500.',
    badge: 'English Speech',
  }
];

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  showToast,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [spokenText, setSpokenText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState<VoiceExtractedData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);

  const recognitionRef = useRef<any>(null);

  // Initialize Web Speech API if supported
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'te-IN'; // Telugu default, can also understand numbers and keywords

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setSpokenText(transcript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  if (!isOpen) return null;

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      if (spokenText.trim()) {
        handleProcessSpeech(spokenText);
      }
    } else {
      setSpokenText('');
      setExtractedData(null);
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        console.error('Failed to start speech recognition:', err);
        showToast('Speech recognition unavailable', 'Please type or select a sample preset below.', 'warning');
      }
    }
  };

  const handleProcessSpeech = async (textToParse: string) => {
    if (!textToParse.trim()) {
      showToast('Empty speech', 'Please speak or select a preset example.', 'warning');
      return;
    }
    setIsProcessing(true);
    try {
      const result = await api.parseVoice(textToParse);
      setExtractedData(result.extracted);
      setIsEditing(false);
    } catch (err) {
      console.error('Parse error:', err);
      showToast('Parsing Failed', 'Could not parse voice recording.', 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmAndSave = async () => {
    if (!extractedData) return;
    setIsSaving(true);
    try {
      await api.confirmVoice(extractedData, spokenText);

      // Trigger celebration confetti!
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#10b981', '#3b82f6'],
      });

      showToast(
        "✓ Today's construction update saved successfully.",
        `Recorded ₹${extractedData.grandTotal.toLocaleString('en-IN')} across workers, materials & expenses.`,
        'success'
      );

      onSuccess();
      handleClose();
    } catch (err) {
      console.error('Save error:', err);
      showToast('Save Failed', 'Could not save voice records to database.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleClose = () => {
    if (recognitionRef.current) {
      recognitionRef.current.abort();
    }
    setIsListening(false);
    setSpokenText('');
    setExtractedData(null);
    setIsEditing(false);
    onClose();
  };

  // Recalculate totals during editing
  const recalculateData = (updated: VoiceExtractedData) => {
    const labourTotal = updated.workers.reduce((s, w) => s + w.count * w.wagePerPerson, 0);
    const materialTotal = updated.materials.reduce((s, m) => s + m.totalPrice, 0);
    const expensesTotal = updated.expenses.reduce((s, e) => s + e.amount, 0);

    updated.workers.forEach(w => {
      w.subtotal = w.count * w.wagePerPerson;
    });

    updated.labourTotal = labourTotal;
    updated.materialTotal = materialTotal;
    updated.grandTotal = labourTotal + materialTotal + expensesTotal;

    setExtractedData({ ...updated });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative my-auto max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            Telugu Voice Assistant
          </div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center justify-center gap-2 font-telugu">
            🎙️ నేటి పనిని చెప్పండి
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            "Tell Today's Update" — Speak naturally in Telugu or English.
          </p>
        </div>

        {/* Voice Input Section (Shown when no extracted data or when recording) */}
        {!extractedData && (
          <div className="flex flex-col items-center justify-center py-4 flex-1">
            {/* Big Pulsing Mic Button */}
            <div className="relative mb-6">
              {isListening && (
                <>
                  <div className="absolute inset-0 rounded-full bg-amber-500/30 animate-pulse-ring scale-125" />
                  <div className="absolute inset-0 rounded-full bg-amber-400/20 animate-ping" />
                </>
              )}
              <button
                onClick={toggleListening}
                className={`relative z-10 w-24 h-24 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl ${
                  isListening
                    ? 'bg-rose-500 text-white shadow-rose-500/50 scale-105'
                    : 'bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-300 text-slate-950 hover:scale-105 shadow-amber-500/40 glow-amber'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-8 h-8 animate-bounce" />
                    <span className="text-[10px] font-black uppercase mt-1">Stop</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-8 h-8" />
                    <span className="text-[10px] font-black uppercase mt-1">Speak</span>
                  </>
                )}
              </button>
            </div>

            {/* Status & Live Wave */}
            {isListening ? (
              <div className="flex flex-col items-center gap-2 mb-4">
                <div className="flex items-center gap-1.5 h-6">
                  {[40, 70, 90, 60, 100, 50, 80, 45, 95].map((h, i) => (
                    <div
                      key={i}
                      className="w-1 bg-amber-400 rounded-full animate-pulse"
                      style={{
                        height: `${h}%`,
                        animationDelay: `${i * 0.15}s`,
                        animationDuration: '0.8s'
                      }}
                    />
                  ))}
                </div>
                <p className="text-xs font-bold text-amber-400 animate-pulse font-telugu">
                  మీ మాటలను వింటున్నాను... (Listening in Telugu...)
                </p>
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center max-w-sm mb-4">
                Tap the microphone and describe today's workers, wages, bricks, cement, wires, or transport.
              </p>
            )}

            {/* Spoken Text Area / Direct Typing */}
            <div className="w-full bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 mb-5 focus-within:border-amber-500/60 transition-colors">
              <label className="text-[11px] font-bold text-slate-400 block mb-1">
                Spoken or Typed Text (తెలుగు వాక్యం):
              </label>
              <textarea
                rows={3}
                value={spokenText}
                onChange={e => setSpokenText(e.target.value)}
                placeholder="ఉదాహరణ: ఈరోజు 4 మేస్త్రీలు (800), 3 హెల్పర్లు (500) వచ్చారు. 4000 ఇటుకలు 40 వేలు, ఎలక్ట్రికల్ వైర్లు 4500 అయ్యాయి..."
                className="w-full bg-transparent text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none resize-none font-telugu"
              />
              <div className="flex justify-end gap-2 mt-2">
                <button
                  disabled={!spokenText.trim() || isProcessing}
                  onClick={() => handleProcessSpeech(spokenText)}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-extrabold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Processing AI...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" /> Extract Information (విశ్లేషించు)
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Realistic One-Click Telugu Presets */}
            <div className="w-full">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <span>⚡</span> Quick Voice Presets (ఒక్క క్లిక్‌తో పరీక్షించండి):
              </p>
              <div className="grid grid-cols-1 gap-2">
                {PRESET_EXAMPLES.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSpokenText(preset.text);
                      handleProcessSpeech(preset.text);
                    }}
                    className="p-3 bg-slate-800/40 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/40 rounded-xl text-left transition-all group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-amber-400 group-hover:text-amber-300">
                        {preset.title}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 border border-slate-700">
                        {preset.badge}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-2 font-telugu leading-relaxed">
                      "{preset.text}"
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VOICE EXTRACTION REVIEW & SAFETY CONFIRMATION CARD (Section 12 Safety Rule) */}
        {extractedData && (
          <div className="flex-1 overflow-y-auto pr-1 space-y-4">
            {/* Safety Banner */}
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500 text-slate-950 font-bold">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-extrabold text-amber-300 font-telugu">
                  Is this information correct? / ఈ వివరాలు సరైనవేనా?
                </h4>
                <p className="text-[11px] text-slate-300">
                  Please review the extracted line items before confirming. Data will ONLY be written to database after your approval.
                </p>
              </div>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
                  isEditing ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-200 hover:text-white'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                {isEditing ? 'Done Editing' : 'Edit'}
              </button>
            </div>

            {/* Extracted Workers Card */}
            <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-base">👷</span>
                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                    Workers & Labour (కూలీలు)
                  </h4>
                </div>
                <span className="text-xs font-extrabold text-amber-400">
                  Subtotal: ₹{extractedData.labourTotal.toLocaleString('en-IN')}
                </span>
              </div>

              {extractedData.workers.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No workers extracted from speech.</p>
              ) : (
                <div className="space-y-2">
                  {extractedData.workers.map((w, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-200">{w.role}</span>
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="1"
                              value={w.count}
                              onChange={e => {
                                const copy = { ...extractedData };
                                copy.workers[i].count = parseInt(e.target.value) || 0;
                                recalculateData(copy);
                              }}
                              className="w-14 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center text-amber-400 font-bold"
                            />
                            <span className="text-slate-500">count</span>
                          </div>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md bg-slate-800 text-amber-400 font-bold">
                            {w.count} workers
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <span className="text-slate-500">₹</span>
                            <input
                              type="number"
                              step="50"
                              value={w.wagePerPerson}
                              onChange={e => {
                                const copy = { ...extractedData };
                                copy.workers[i].wagePerPerson = parseInt(e.target.value) || 0;
                                recalculateData(copy);
                              }}
                              className="w-20 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-right text-slate-100 font-bold"
                            />
                            <span className="text-slate-500">each</span>
                          </div>
                        ) : (
                          <span className="text-slate-400">@ ₹{w.wagePerPerson} each</span>
                        )}
                        <span className="font-extrabold text-slate-100 w-20 text-right">
                          ₹{w.subtotal.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Extracted Materials Card */}
            <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-base">🧱</span>
                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                    Materials Purchased (మెటీరియల్స్)
                  </h4>
                </div>
                <span className="text-xs font-extrabold text-amber-400">
                  Subtotal: ₹{extractedData.materialTotal.toLocaleString('en-IN')}
                </span>
              </div>

              {extractedData.materials.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No materials extracted from speech.</p>
              ) : (
                <div className="space-y-2">
                  {extractedData.materials.map((m, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-200">{m.name}</span>
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              value={m.quantity}
                              onChange={e => {
                                const copy = { ...extractedData };
                                copy.materials[i].quantity = parseInt(e.target.value) || 0;
                                recalculateData(copy);
                              }}
                              className="w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center text-amber-400 font-bold"
                            />
                            <span className="text-slate-500">{m.unit}</span>
                          </div>
                        ) : (
                          <span className="text-slate-400">
                            ({m.quantity.toLocaleString('en-IN')} {m.unit})
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <span className="text-slate-500">₹</span>
                            <input
                              type="number"
                              value={m.totalPrice}
                              onChange={e => {
                                const copy = { ...extractedData };
                                copy.materials[i].totalPrice = parseInt(e.target.value) || 0;
                                recalculateData(copy);
                              }}
                              className="w-24 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-right text-slate-100 font-bold"
                            />
                          </div>
                        ) : (
                          <span className="font-extrabold text-slate-100">
                            ₹{m.totalPrice.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Extracted Other Expenses Card */}
            {extractedData.expenses.length > 0 && (
              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">⚡</span>
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                      Electrical & Other Expenses (ఇతర ఖర్చులు)
                    </h4>
                  </div>
                  <span className="text-xs font-extrabold text-amber-400">
                    Subtotal: ₹{extractedData.expenses.reduce((s, e) => s + e.amount, 0).toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="space-y-2">
                  {extractedData.expenses.map((e, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-200">{e.description}</span>
                        <span className="text-[10px] text-slate-400 ml-2 px-1.5 py-0.5 bg-slate-800 rounded">
                          {e.category}
                        </span>
                      </div>
                      {isEditing ? (
                        <div className="flex items-center gap-1">
                          <span className="text-slate-500">₹</span>
                          <input
                            type="number"
                            value={e.amount}
                            onChange={ev => {
                              const copy = { ...extractedData };
                              copy.expenses[i].amount = parseInt(ev.target.value) || 0;
                              recalculateData(copy);
                            }}
                            className="w-24 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-right text-slate-100 font-bold"
                          />
                        </div>
                      ) : (
                        <span className="font-extrabold text-slate-100">
                          ₹{e.amount.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Grand Total Bar */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-amber-500/10 to-transparent border border-amber-500/30 flex items-center justify-between">
              <div>
                <p className="text-xs text-amber-300 font-bold font-telugu">నేటి మొత్తం ఖర్చు</p>
                <h3 className="text-lg font-black text-white">Today's Grand Total</h3>
              </div>
              <div className="text-right">
                <p className="text-2xl font-black text-amber-400 tracking-tight">
                  ₹{extractedData.grandTotal.toLocaleString('en-IN')}
                </p>
                <p className="text-[10px] text-slate-400">Atomic Multi-Record Commit</p>
              </div>
            </div>

            {/* Verification Action Buttons (Strict Prompt Requirement Section 12) */}
            <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setExtractedData(null);
                  setIsEditing(false);
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                <X className="w-4 h-4 text-rose-400" />
                Cancel (రద్దు చేయి)
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(!isEditing)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Edit3 className="w-4 h-4 text-amber-400" />
                  {isEditing ? 'Save Changes' : 'Edit Records'}
                </button>

                <button
                  type="button"
                  disabled={isSaving}
                  onClick={handleConfirmAndSave}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/30 flex items-center gap-2 transition-all transform active:scale-95"
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Saving to Database...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      Confirm & Save (ధృవీకరించి సేవ్ చేయి)
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
