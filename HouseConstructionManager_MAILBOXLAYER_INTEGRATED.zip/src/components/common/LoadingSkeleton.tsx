import React from 'react';

export const LoadingSkeleton: React.FC<{ rows?: number; height?: string }> = ({ rows = 4, height = 'h-16' }) => {
  return (
    <div className="space-y-4 w-full animate-pulse">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className={`w-full ${height} bg-slate-900/60 border border-slate-800/80 rounded-2xl relative overflow-hidden`}>
          <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-slate-800/30 to-transparent animate-shimmer" />
        </div>
      ))}
    </div>
  );
};
