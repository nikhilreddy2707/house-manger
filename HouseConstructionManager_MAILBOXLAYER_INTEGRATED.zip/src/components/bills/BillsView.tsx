import React, { useState } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Scan,
  CheckCircle2,
  FileText,
  AlertCircle,
  X,
  Eye,
  Check,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { BillReceipt, ExpenseCategory } from '../../types.js';
import { localDateInputValue } from '../../api/validation.js';
import { api } from '../../api/apiClient.js';

interface BillsViewProps {
  bills: BillReceipt[];
  onAddBill: (bill: any) => void;
  onViewProof: (url: string, title: string) => void;
  showToast: (title: string, message?: string, type?: any) => void;
}

export const BillsView: React.FC<BillsViewProps> = ({
  bills,
  onAddBill,
  onViewProof,
  showToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isManualOpen, setIsManualOpen] = useState(false);
  const [isOcrOpen, setIsOcrOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [ocrResult, setOcrResult] = useState<any>(null);
  const [ocrFile, setOcrFile] = useState<File | null>(null);

  // Manual bill form
  const [title, setTitle] = useState('');
  const [supplier, setSupplier] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Materials');
  const [amount, setAmount] = useState<number>(0);
  const [date, setDate] = useState(localDateInputValue());
  const [fileUrl, setFileUrl] = useState('');
  const [billFile, setBillFile] = useState<File | null>(null);

  const filteredBills = bills.filter(
    b =>
      b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOcr = async () => {
    if (!ocrFile) { showToast('Select a bill', 'Choose an image or PDF before starting OCR.', 'warning'); return; }
    setIsScanning(true);
    try {
      const result = await (api as any).scanBill(ocrFile);
      setOcrResult(result);
    } catch (err: any) {
      showToast('OCR unavailable', err?.message || 'Configure a real OCR endpoint before scanning.', 'warning');
    } finally { setIsScanning(false); }
  };

  const handleConfirmOcr = () => {
    if (!ocrResult) return;
    onAddBill({
      title: `${ocrResult.supplier} Tax Invoice`,
      fileUrl: '',
      file: ocrFile || undefined,
      fileType: ocrFile?.type === 'application/pdf' ? 'pdf' : 'image',
      date: ocrResult.date,
      category: ocrResult.category,
      amount: ocrResult.totalAmount,
      supplier: ocrResult.supplier,
      ocrData: ocrResult,
    });
    showToast('Bill Saved', `Added invoice from ${ocrResult.supplier} for ₹${ocrResult.totalAmount}`, 'success');
    setIsOcrOpen(false);
    setOcrResult(null);
    setOcrFile(null);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || amount <= 0) return;
    onAddBill({
      title,
      supplier: supplier || 'Vendor',
      category,
      amount: Number(amount),
      date,
      fileUrl,
      file: billFile || undefined,
      fileType: billFile?.type === 'application/pdf' ? 'pdf' : 'image',
    });
    setIsManualOpen(false);
    setTitle('');
    setAmount(0);
    setSupplier('');
    setBillFile(null);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            🧾 Bills, Invoices & Receipts
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              బిల్లులు & రసీదులు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Secure document repository with real document OCR integration with review-before-save controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsOcrOpen(true);
              setOcrResult(null);
              setOcrFile(null);
            }}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-lg shadow-amber-500/20"
          >
            <Scan className="w-4 h-4" /> 🤖 Scan Bill (OCR)
          </button>
          <button
            onClick={() => setIsManualOpen(true)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <Plus className="w-4 h-4" /> Upload Bill
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search invoices by supplier, item, date, or category..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
        />
      </div>

      {/* Bills Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBills.map(bill => (
          <div
            key={bill.id}
            className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800/90 hover:border-amber-500/40 shadow-xl transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <h4 className="font-extrabold text-slate-100 text-sm">{bill.title}</h4>
                  <p className="text-xs text-amber-400 font-medium">{bill.supplier}</p>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  {bill.status}
                </span>
              </div>

              <div className="my-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 text-[10px] block">Date</span>
                  <span className="font-bold text-slate-300">{bill.date}</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 text-[10px] block">Invoice Amount</span>
                  <span className="text-base font-black text-slate-100">
                    ₹{bill.amount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {bill.ocrData && (
                <div className="text-[11px] text-slate-400 space-y-1 mb-2 bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60">
                  <span className="text-[10px] font-bold text-amber-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Extracted Line Items:
                  </span>
                  {bill.ocrData.items?.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between">
                      <span>{item.name} ({item.quantity} pcs)</span>
                      <span className="font-bold text-slate-300">₹{item.total}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]">
                {bill.category}
              </span>

              {bill.fileUrl ? <button
                onClick={() => onViewProof(bill.fileUrl, bill.title)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 hover:text-white text-xs font-bold transition-colors flex items-center gap-1"
              >
                <Eye className="w-3.5 h-3.5" /> View Receipt
              </button> : <span className="text-[10px] text-slate-500">No receipt attached</span>}
            </div>
          </div>
        ))}
      </div>

      {/* FUTURE READY OCR MODAL (Section 26 Strict Rule) */}
      {isOcrOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative">
            <button
              onClick={() => {
                setIsOcrOpen(false);
                setOcrResult(null);
                setOcrFile(null);
              }}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold mb-2">
                <Sparkles className="w-3.5 h-3.5" /> Bill Scanner
              </div>
              <h3 className="text-xl font-black text-slate-100">
                Document OCR
              </h3>
              <p className="text-xs text-slate-400">
                Extracts supplier, line items, and totals from uploaded tax invoices.
              </p>
            </div>

            <div className="mb-4 p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
              <label className="text-xs font-bold text-slate-300 block mb-2">Invoice file</label>
              <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={e => setOcrFile(e.target.files?.[0] || null)} className="w-full text-xs text-slate-400 file:mr-3 file:rounded-lg file:border-0 file:bg-amber-500 file:px-3 file:py-2 file:font-bold file:text-slate-950" />
              <button type="button" onClick={handleOcr} disabled={!ocrFile || isScanning} className="mt-3 px-4 py-2 rounded-xl bg-amber-500 disabled:opacity-40 text-slate-950 text-xs font-black">
                {isScanning ? 'Scanning…' : 'Run OCR'}
              </button>
              <p className="text-[10px] text-slate-500 mt-2">OCR runs only when a real VITE_OCR_ENDPOINT is configured.</p>
            </div>

            {isScanning ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3">
                <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
                <p className="text-xs font-bold text-slate-300">
                  Scanning invoice & extracting items...
                </p>
              </div>
            ) : ocrResult ? (
              <div className="space-y-4">
                {/* Strict Safety Confirmation Banner */}
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center gap-3 text-xs">
                  <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
                  <div>
                    <h4 className="font-extrabold text-amber-300">Is this information correct?</h4>
                    <p className="text-slate-300">
                      OCR results must be reviewed before saving. {ocrResult.confidence ? 'Confidence is shown from the configured OCR service.' : 'No confidence score was supplied by the OCR service.'}
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Supplier:</span>
                    <strong className="text-slate-100">{ocrResult.supplier}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Date:</span>
                    <strong className="text-slate-100">{ocrResult.date}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Category:</span>
                    <strong className="text-amber-400">{ocrResult.category}</strong>
                  </div>

                  <div className="pt-2 border-t border-slate-800">
                    <p className="font-bold text-slate-300 mb-1">Line Items:</p>
                    {ocrResult.items?.map((it: any, idx: number) => (
                      <div key={idx} className="flex justify-between text-slate-400 py-0.5">
                        <span>{it.name} ({it.quantity}x @ ₹{it.unitPrice})</span>
                        <span className="font-bold text-slate-200">₹{it.total}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex justify-between text-sm font-black">
                    <span className="text-slate-300">Total Bill Amount:</span>
                    <span className="text-amber-400">₹{ocrResult.totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* Section 26 Action Buttons */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsOcrOpen(false);
                      setOcrResult(null);
                    }}
                    className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl font-bold text-xs hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmOcr}
                    className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20"
                  >
                    <Check className="w-4 h-4" /> Confirm & Save Bill
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Manual Add Bill Modal */}
      {isManualOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setIsManualOpen(false)}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black text-slate-100 mb-1 flex items-center gap-2">
              🧾 Upload Invoice or Receipt
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Attach a digital bill for financial audits and material warranties.
            </p>

            <form onSubmit={handleManualSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Invoice Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UltraTech Cement Cash Invoice"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Supplier / Kiln</label>
                  <input
                    type="text"
                    placeholder="e.g. Sri Balaji Building Materials"
                    value={supplier}
                    onChange={e => setSupplier(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  >
                    <option value="Materials">Materials</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Plumbing">Plumbing</option>
                    <option value="Labour">Labour</option>
                    <option value="Contractor">Contractor</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Receipt / Invoice File</label>
                <input type="file" accept="image/*,.pdf" onChange={e => setBillFile(e.target.files?.[0] || null)} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300" />
                <p className="text-[10px] text-slate-500 mt-1">JPG, PNG, WEBP or PDF. Uploaded files are stored in Supabase Storage.</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Total Bill (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={amount || ''}
                    onChange={e => setAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsManualOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Save Bill Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
