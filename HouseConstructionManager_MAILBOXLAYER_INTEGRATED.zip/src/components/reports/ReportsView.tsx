import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  FileSpreadsheet,
  Printer,
  Calendar,
  Layers,
  Users,
  IndianRupee,
  CheckCircle2,
} from 'lucide-react';
import { SummaryData, ConstructionLedgerItem } from '../../types.js';

interface ReportsViewProps {
  summary: SummaryData;
  ledger: ConstructionLedgerItem[];
  showToast: (title: string, message?: string, type?: any) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ summary, ledger, showToast }) => {
  const [reportType, setReportType] = useState('full-summary');

  const handleExportCSV = () => {
    // Generate CSV content
    const headers = ['Date', 'Description', 'Category', 'Amount', 'Payment Status', 'Supplier/Recipient', 'Source'];
    const rows = ledger.map(l => [
      l.date,
      `"${l.description.replace(/"/g, '""')}"`,
      l.category,
      l.amount,
      l.paymentStatus,
      `"${l.recipientOrSupplier || ''}"`,
      l.source
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `house_construction_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Export Successful', 'Construction ledger exported as CSV', 'success');
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            📊 Financial Reports & Audits
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              నివేదికలు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Export comprehensive cost audits, contractor statements, and tax summaries.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> Export CSV
          </button>
          <button
            onClick={handlePrintReport}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
          >
            <Printer className="w-4 h-4" /> Print / Export PDF
          </button>
        </div>
      </div>

      {/* Top Audit Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
          <span className="text-xs text-slate-400 font-bold uppercase">Total Capital Deployed</span>
          <h3 className="text-3xl font-black text-white mt-1">
            ₹{summary.totalSpending.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">Paid/settled transactions</p>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900/90 border border-amber-500/20 shadow-xl">
          <span className="text-xs text-amber-400 font-bold uppercase">Materials Spending</span>
          <h3 className="text-3xl font-black text-amber-400 mt-1">
            ₹{summary.categoryDistribution.find(c => c.name === 'Materials')?.value.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">{summary.categoryDistribution.find(c => c.name === 'Materials')?.percentage ?? 0}% of paid spending</p>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900/90 border border-blue-500/20 shadow-xl">
          <span className="text-xs text-blue-400 font-bold uppercase">Labour Wages</span>
          <h3 className="text-3xl font-black text-blue-400 mt-1">
            ₹{summary.categoryDistribution.find(c => c.name === 'Labour')?.value.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">{summary.categoryDistribution.find(c => c.name === 'Labour')?.percentage ?? 0}% of paid spending</p>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="p-8 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row justify-between pb-6 border-b border-slate-800">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
              OFFICIAL CONSTRUCTION AUDIT STATEMENT
            </span>
            <h3 className="text-2xl font-black text-slate-100 mt-1">
              {summary.house.name}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {summary.house.location || 'Construction site'} • Owner: {summary.house.ownerName || 'Not set'}
            </p>
          </div>
          <div className="mt-4 sm:mt-0 text-left sm:text-right text-xs text-slate-400">
            <p><strong>Report Date:</strong> {summary.today}</p>
            <p><strong>Overall Status:</strong> {summary.constructionProgress}% Complete</p>
            <p><strong>Total Transactions:</strong> {ledger.length} recorded transactions</p>
            <p><strong>Committed:</strong> ₹{summary.committedSpending.toLocaleString('en-IN')}</p>
            <p><strong>Outstanding:</strong> ₹{summary.outstandingAmount.toLocaleString('en-IN')}</p>
          </div>
        </div>

        {/* Category breakdown table */}
        <div>
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
            Category Spending Summary
          </h4>
          <div className="rounded-2xl border border-slate-800 overflow-hidden">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-4">Category</th>
                  <th className="py-2.5 px-4 text-center">Share %</th>
                  <th className="py-2.5 px-4 text-right">Total Amount</th>
                  <th className="py-2.5 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                {summary.categoryDistribution.map((c, i) => (
                  <tr key={i} className="hover:bg-slate-800/30">
                    <td className="py-3 px-4 font-bold text-slate-100">{c.name}</td>
                    <td className="py-3 px-4 text-center font-semibold text-amber-400">
                      {c.percentage}%
                    </td>
                    <td className="py-3 px-4 text-right font-black text-slate-100">
                      ₹{c.value.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-slate-400 font-bold text-[10px]">RECORDED</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
