import React, { useEffect, useState } from 'react';
import { Settings, Home, RotateCcw, Shield, Bell, Languages, Check } from 'lucide-react';
import { House } from '../../types.js';

interface SettingsViewProps {
  house: House;
  onResetDemo: () => void;
  onUpdateProject: (updates: Partial<House>) => Promise<void>;
  showToast: (title: string, message?: string, type?: any) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ house, onResetDemo, onUpdateProject, showToast }) => {
  const [houseName, setHouseName] = useState(house.name);
  const [ownerName, setOwnerName] = useState(house.ownerName);
  const [location, setLocation] = useState(house.location);
  const [totalBudget, setTotalBudget] = useState(house.totalBudget);
  useEffect(() => { setHouseName(house.name); setOwnerName(house.ownerName); setLocation(house.location); setTotalBudget(house.totalBudget); }, [house.id, house.name, house.ownerName, house.location, house.totalBudget]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await onUpdateProject({ name: houseName.trim() || 'My Construction Project', ownerName, location, totalBudget: Math.max(0, totalBudget) });
    showToast('Settings Saved', 'House project profile updated successfully.', 'success');
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-4xl">
      <div>
        <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
          ⚙️ Construction & System Settings
        </h2>
        <p className="text-xs text-slate-400">
          Configure house profile, target budgets, notification thresholds, and voice preferences.
        </p>
      </div>

      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-5">
        <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
          <Home className="w-4 h-4 text-amber-400" />
          House Project Profile
        </h3>

        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-300 mb-1">House Project Name</label>
              <input
                type="text"
                value={houseName}
                onChange={e => setHouseName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-300 mb-1">Owner Name</label>
              <input
                type="text"
                value={ownerName}
                onChange={e => setOwnerName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Construction Site Location</label>
              <input
                type="text"
                value={location}
                onChange={e => setLocation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-300 mb-1">Total Target Budget (₹)</label>
              <input
                type="number"
                value={totalBudget}
                onChange={e => setTotalBudget(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none font-bold"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-md"
            >
              Save Project Settings
            </button>
          </div>
        </form>
      </div>

      {import.meta.env.DEV && (
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-rose-500/20 shadow-xl space-y-3">
                <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-rose-400" />
                  Reset Demo State
                </h3>
                <p className="text-xs text-slate-400">
                  Restore the sample demo records for testing. This replaces the current project data with demo data.
                </p>
                <button
                  onClick={onResetDemo}
                  className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/30 rounded-xl text-xs font-bold transition-all"
                >
                  Reset All Data to Demo Baseline
                </button>
              </div>
      )}

    </div>
  );
};
