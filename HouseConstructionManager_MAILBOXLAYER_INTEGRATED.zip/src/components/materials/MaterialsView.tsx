import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Calendar,
  Search,
  IndianRupee,
  TrendingUp,
  Clock,
  History,
  X,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { Material, MaterialPurchase } from '../../types.js';
import { localDateInputValue } from '../../api/validation.js';

interface MaterialsViewProps {
  materials: Material[];
  purchases: MaterialPurchase[];
  onAddPurchase: (purchase: any) => void;
}

export const MaterialsView: React.FC<MaterialsViewProps> = ({
  materials,
  purchases,
  onAddPurchase,
}) => {
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Add purchase form state
  const [date, setDate] = useState(localDateInputValue());
  const [materialId, setMaterialId] = useState('mat_01');
  const [materialName, setMaterialName] = useState('Bricks (ఇటుకలు)');
  const [quantity, setQuantity] = useState<number>(1000);
  const [unit, setUnit] = useState('pieces');
  const [pricePerUnit, setPricePerUnit] = useState<number>(10);
  const [supplier, setSupplier] = useState('');
  const [notes, setNotes] = useState('');

  const totalPrice = quantity * pricePerUnit;

  const filteredMaterials = materials.filter(m =>
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalSpentAllMaterials = materials.reduce((s, m) => s + m.totalAmountSpent, 0);

  const handleMaterialSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const m = materials.find(mat => mat.id === e.target.value);
    if (m) {
      setMaterialId(m.id);
      setMaterialName(m.name);
      setUnit(m.defaultUnit);
      if (m.averagePrice > 0) setPricePerUnit(Math.round(m.averagePrice));
    }
  };

  const handlePurchaseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddPurchase({
      materialId,
      materialName,
      date,
      quantity: Number(quantity),
      unit,
      pricePerUnit: Number(pricePerUnit),
      totalPrice,
      supplier: supplier || 'Local Vendor',
      paymentStatus: 'Paid',
      notes,
    });
    setIsAddOpen(false);
  };

  // Get history for selected material
  const materialPurchases = selectedMaterial
    ? purchases.filter(p => p.materialId === selectedMaterial.id || p.materialName.toLowerCase().includes(selectedMaterial.name.toLowerCase()))
    : [];

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            🧱 Materials & Purchase Analytics
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              నిర్మాణ సామాగ్రి
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Track cement bags, brick counts, steel tonnage, wires, and pipes with unit costs and price trends.
          </p>
        </div>

        <button
          onClick={() => setIsAddOpen(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> Add Material Purchase
        </button>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400">Tracked Materials</span>
          <p className="text-2xl font-black text-slate-100 mt-1">{materials.length} types</p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/20">
          <span className="text-xs text-amber-400 font-bold">Total Material Spend</span>
          <p className="text-2xl font-black text-amber-400 mt-1">
            ₹{totalSpentAllMaterials.toLocaleString('en-IN')}
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400">Total Purchase Deliveries</span>
          <p className="text-2xl font-black text-slate-100 mt-1">{purchases.length} logged</p>
        </div>
      </div>

      {/* Search Filter */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search materials (e.g. Bricks, Cement, Steel, Wires)..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
        />
      </div>

      {/* Materials Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMaterials.map(mat => (
          <div
            key={mat.id}
            className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800/90 hover:border-amber-500/40 shadow-xl transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <h4 className="font-extrabold text-slate-100 text-sm">{mat.name}</h4>
                  <span className="text-[10px] text-slate-400">{mat.category}</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-800 text-amber-400">
                  <Layers className="w-4 h-4" />
                </div>
              </div>

              {/* Material Stats (Section 20) */}
              <div className="space-y-1.5 my-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Quantity:</span>
                  <span className="font-bold text-slate-200">
                    {mat.totalQuantityPurchased.toLocaleString('en-IN')} {mat.defaultUnit}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Spent:</span>
                  <span className="font-black text-amber-400">
                    ₹{mat.totalAmountSpent.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Average Unit Price:</span>
                  <span className="font-semibold text-slate-300">
                    {mat.averagePrice > 0 ? `₹${mat.averagePrice.toLocaleString('en-IN')} / ${mat.defaultUnit}` : '—'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Deliveries:</span>
                  <span className="text-slate-400">{mat.purchaseCount} purchases</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-500">
                Latest: {mat.latestPurchaseDate || 'No record'}
              </span>
              <button
                onClick={() => setSelectedMaterial(mat)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 hover:text-white font-bold transition-colors flex items-center gap-1"
              >
                <History className="w-3.5 h-3.5" /> View History
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Material History Modal (Section 19) */}
      {selectedMaterial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedMaterial(null)}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-5">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                Purchase History & Pricing Analytics
              </span>
              <h3 className="text-2xl font-black text-slate-100 mt-1">{selectedMaterial.name}</h3>
              <p className="text-xs text-slate-400">
                Total purchased: {selectedMaterial.totalQuantityPurchased.toLocaleString('en-IN')} {selectedMaterial.defaultUnit} • Spent: ₹{selectedMaterial.totalAmountSpent.toLocaleString('en-IN')}
              </p>
            </div>

            <div className="rounded-2xl border border-slate-800 overflow-hidden mb-4">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Quantity</th>
                    <th className="py-2.5 px-3">Rate</th>
                    <th className="py-2.5 px-3 text-right">Total</th>
                    <th className="py-2.5 px-3">Supplier</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                  {materialPurchases.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-500">
                        No purchase records found for this material.
                      </td>
                    </tr>
                  ) : (
                    materialPurchases.map(p => (
                      <tr key={p.id} className="hover:bg-slate-800/30">
                        <td className="py-2.5 px-3 font-medium text-slate-400">{p.date}</td>
                        <td className="py-2.5 px-3 font-bold text-slate-200">
                          {p.quantity} {p.unit}
                        </td>
                        <td className="py-2.5 px-3 text-slate-400">₹{p.pricePerUnit}</td>
                        <td className="py-2.5 px-3 text-right font-black text-amber-400">
                          ₹{p.totalPrice.toLocaleString('en-IN')}
                        </td>
                        <td className="py-2.5 px-3 text-slate-400 truncate max-w-[120px]">
                          {p.supplier}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSelectedMaterial(null)}
                className="px-4 py-2 bg-slate-800 text-slate-200 rounded-xl font-bold text-xs hover:bg-slate-700"
              >
                Close History
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Material Purchase Modal (Section 18) */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setIsAddOpen(false)}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black text-slate-100 mb-1 flex items-center gap-2">
              🧱 Add Material Purchase
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Record a delivery of bricks, cement, sand, or custom materials.
            </p>

            <form onSubmit={handlePurchaseSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Purchase Date *</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Material Name *</label>
                <select
                  value={materialId}
                  onChange={handleMaterialSelect}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                >
                  {materials.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.category})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Quantity *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={e => setQuantity(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Unit</label>
                  <input
                    type="text"
                    value={unit}
                    onChange={e => setUnit(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Price Per Unit (₹) *</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    required
                    value={pricePerUnit}
                    onChange={e => setPricePerUnit(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Calculated Total (₹)</label>
                  <div className="w-full bg-slate-950/80 border border-amber-500/40 rounded-xl px-3.5 py-2.5 text-amber-400 font-black text-sm flex items-center">
                    ₹{totalPrice.toLocaleString('en-IN')}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Supplier / Vendor</label>
                <input
                  type="text"
                  placeholder="e.g. Sri Balaji Building Materials"
                  value={supplier}
                  onChange={e => setSupplier(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Save Material Purchase
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
