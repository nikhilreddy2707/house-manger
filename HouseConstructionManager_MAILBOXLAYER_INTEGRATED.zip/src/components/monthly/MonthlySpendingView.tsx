import React, { useMemo, useState } from 'react';
import {
  TrendingUp,
  Calendar,
  Layers,
  Users,
  IndianRupee,
  HardHat,
  ChevronRight,
  PieChart,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { SummaryData } from '../../types.js';

interface MonthlySpendingViewProps {
  summary: SummaryData;
}

export const MonthlySpendingView: React.FC<MonthlySpendingViewProps> = ({ summary }) => {
  const [viewMode, setViewMode] = useState<'Daily' | 'Weekly' | 'Monthly' | 'Entire Construction'>('Monthly');

  const monthlyHistory = useMemo(() => (summary.monthlySpendingHistory || []).map((m:any) => ({
    ...m,
    month: m.month,
    total: m.amount,
    materials: m.materials || 0,
    labour: m.labour || 0,
    other: m.other || 0,
    electrical: m.electrical || 0,
    transport: m.transport || 0,
    workerDays: m.workerDays || 0,
    milestone: 'Recorded construction activity',
  })), [summary.monthlySpendingHistory]);
  const currentMonth = summary.currentMonth;
  const currentMonthData: any = monthlyHistory.find((m:any) => m.month === currentMonth) || { amount: 0, materials: 0, labour: 0, other: 0 };


  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            📊 Monthly Spending & Trajectory
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              నెలవారీ విశ్లేషణ
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Compare monthly capital flow, stage progress, and labour allocation across the entire construction lifespan.
          </p>
        </div>

        {/* View Switcher (Section 8) */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-2xl">
          {(['Daily', 'Weekly', 'Monthly', 'Entire Construction'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                viewMode === mode
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Month-End Summary Card (Section 36) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              Current Month In Focus
            </span>
            <h3 className="text-2xl font-black text-slate-100 mt-1">
              {currentMonth} SUMMARY
            </h3>
          </div>

          <div className="flex items-center gap-4 text-xs font-bold">
            <span className="px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              Budget Used: {summary.house.totalBudget ? `${((summary.thisMonthSpending / summary.house.totalBudget) * 100).toFixed(1)}%` : '0.0%'}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              Progress: {summary.constructionProgress}%
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 my-5">
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-xs text-slate-400">Worker Days</p>
            <p className="text-xl font-black text-slate-100 mt-1">{currentMonthData.workerDays || 0} days</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-xs text-slate-400">Labour</p>
            <p className="text-xl font-black text-slate-100 mt-1">₹{Number(currentMonthData.labour || 0).toLocaleString('en-IN')}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-xs text-slate-400">Materials</p>
            <p className="text-xl font-black text-amber-400 mt-1">₹{Number(currentMonthData.materials || 0).toLocaleString('en-IN')}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-xs text-slate-400">Electrical</p>
            <p className="text-xl font-black text-blue-400 mt-1">₹{Number(currentMonthData.electrical || 0).toLocaleString('en-IN')}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-xs text-slate-400">Transport</p>
            <p className="text-xl font-black text-slate-100 mt-1">₹{Number(currentMonthData.transport || 0).toLocaleString('en-IN')}</p>
          </div>
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30">
            <p className="text-xs text-amber-400 font-bold">TOTAL MONTH</p>
            <p className="text-xl font-black text-white mt-1">₹{Number(currentMonthData.amount || 0).toLocaleString('en-IN')}</p>
          </div>
        </div>
      </div>

      {/* Monthly Comparison Bar Chart (Section 8) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl">
        <h3 className="text-base font-extrabold text-slate-100 mb-1">
          Month-over-Month Capital Inflow (Recorded Months)
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Visual comparison of total monthly investments from construction kickoff
        </p>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis
                stroke="#64748b"
                fontSize={11}
                tickFormatter={v => `₹${(v / 1000).toFixed(0)}k`}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '12px',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Spending']}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Bar dataKey="materials" name="Materials (సామాగ్రి)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              <Bar dataKey="labour" name="Labour (కూలీ)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="total" name="Total Month (మొత్తం)" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Construction Start-to-End Cumulative History (Section 37) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl space-y-4">
        <div>
          <h3 className="text-base font-extrabold text-slate-100">
            Full Construction Lifespan Traceability (మొత్తం నిర్మాణ చరిత్ర)
          </h3>
          <p className="text-xs text-slate-400">
            Every rupee from groundbreaking on the project start to today is fully accounted for.
          </p>
        </div>

        <div className="space-y-3">
          {monthlyHistory.map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm text-slate-200">{item.month}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    {item.workerDays} worker-days
                  </span>
                </div>
                <p className="text-[11px] text-amber-400 font-medium mt-1">
                  Milestone: {item.milestone}
                </p>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-[11px] text-slate-400">Materials: ₹{item.materials.toLocaleString('en-IN')}</p>
                  <p className="text-[11px] text-slate-400">Labour: ₹{item.labour.toLocaleString('en-IN')}</p>
                </div>
                <div className="text-right">
                  <span className="text-base font-black text-slate-100">
                    ₹{item.total.toLocaleString('en-IN')}
                  </span>
                  <span className="block text-[10px] text-emerald-400 font-bold">Traceable</span>
                </div>
              </div>
            </div>
          ))}

          {/* Grand Cumulative Total */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-slate-950 to-slate-950 border border-amber-500/30 flex items-center justify-between text-xs">
            <div>
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                Cumulative Lifespan Total (మొత్తం ఖర్చు)
              </span>
              <p className="text-xs text-slate-300 mt-0.5">Project start → today</p>
            </div>
            <span className="text-2xl font-black text-amber-400">
              ₹{summary.totalSpending.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
