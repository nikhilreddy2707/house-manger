import React, { useState } from 'react';
import {
  Camera,
  Plus,
  Calendar,
  X,
  Eye,
  Layers,
  Sparkles,
  ChevronRight,
  Maximize2,
} from 'lucide-react';
import { ProgressPhoto } from '../../types.js';
import { localDateInputValue } from '../../api/validation.js';

interface PhotosViewProps {
  photos: ProgressPhoto[];
  onAddPhoto: (photo: any) => void;
}

export const PhotosView: React.FC<PhotosViewProps> = ({ photos, onAddPhoto }) => {
  const [selectedPhoto, setSelectedPhoto] = useState<ProgressPhoto | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [stageFilter, setStageFilter] = useState<string>('All');

  // Add form state
  const [stageName, setStageName] = useState('Roof Slab & Centering');
  const [photoUrl, setPhotoUrl] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [date, setDate] = useState(localDateInputValue());
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');

  const stages = [
    'Foundation & Footing',
    'Pillars & Columns',
    'Brick Walls & Partitions',
    'Roof Slab & Centering',
    'Electrical Conduit Work',
    'Plumbing & Drainage',
    'Flooring & Tiling',
    'Painting & Putty',
    'Doors & Windows (UPVC/Wood)',
    'Finishing & Handover',
  ];

  const filteredPhotos = photos.filter(p => {
    if (stageFilter !== 'All' && p.stageName !== stageFilter) return false;
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoUrl && !photoFile) return;
    onAddPhoto({
      stageName,
      photoUrl,
      file: photoFile || undefined,
      date,
      description: description || 'Site construction update',
      notes,
    });
    setIsUploadOpen(false);
    setPhotoUrl('');
    setPhotoFile(null);
    setDescription('');
    setNotes('');
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            📸 Construction Photos & Visual Timeline
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              నిర్మాణ ఫోటోలు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Compare progress over time across Foundation, Pillars, Walls, and Roof stages.
          </p>
        </div>

        <button
          onClick={() => setIsUploadOpen(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md self-start sm:self-auto"
        >
          <Camera className="w-4 h-4" /> Add Construction Photo
        </button>
      </div>

      {/* Stage Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setStageFilter('All')}
          className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
            stageFilter === 'All'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          All Stages ({photos.length})
        </button>
        {stages.map(s => {
          const count = photos.filter(p => p.stageName === s).length;
          return (
            <button
              key={s}
              onClick={() => setStageFilter(s)}
              className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                stageFilter === s
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {s.split(' & ')[0]} {count > 0 && `(${count})`}
            </button>
          );
        })}
      </div>

      {/* Photo Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPhotos.map(photo => (
          <div
            key={photo.id}
            className="group rounded-3xl bg-slate-900/90 border border-slate-800/90 hover:border-amber-500/40 shadow-xl overflow-hidden transition-all flex flex-col justify-between"
          >
            <div className="relative aspect-video overflow-hidden bg-slate-950">
              <img
                src={photo.photoUrl}
                alt={photo.description}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none" />

              <div className="absolute top-3 left-3">
                <span className="px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md text-amber-400 text-[10px] font-bold border border-amber-500/20">
                  {photo.stageName}
                </span>
              </div>

              <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
                <button
                  onClick={() => setSelectedPhoto(photo)}
                  className="p-2 rounded-xl bg-slate-950/80 backdrop-blur-md text-slate-200 hover:text-amber-400 border border-slate-700 text-xs transition-colors"
                  title="View Fullscreen"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="p-4 space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  {photo.date}
                </span>
              </div>
              <h4 className="font-extrabold text-slate-100 text-xs line-clamp-2">
                {photo.description}
              </h4>
              {photo.notes && (
                <p className="text-[11px] text-slate-400 italic line-clamp-2">"{photo.notes}"</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Fullscreen Lightbox Modal */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in">
          <div className="relative max-w-4xl w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute right-4 top-4 z-10 p-2 rounded-xl bg-slate-950/80 text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={selectedPhoto.photoUrl}
              alt={selectedPhoto.description}
              className="w-full max-h-[65vh] object-contain bg-slate-950"
            />
            <div className="p-5">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-amber-400">{selectedPhoto.stageName}</span>
                <span className="text-xs text-slate-500">• {selectedPhoto.date}</span>
              </div>
              <h3 className="text-base font-bold text-slate-100">{selectedPhoto.description}</h3>
              {selectedPhoto.notes && (
                <p className="text-xs text-slate-400 mt-2">{selectedPhoto.notes}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add Photo Modal */}
      {isUploadOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setIsUploadOpen(false)}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black text-slate-100 mb-1 flex items-center gap-2">
              📸 Upload Construction Site Photo
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Document stage progress to compare milestones over time.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Stage *</label>
                <select
                  value={stageName}
                  onChange={e => setStageName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                >
                  {stages.map(s => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Upload Photo</label>
                <input type="file" accept="image/*" onChange={e => setPhotoFile(e.target.files?.[0] || null)} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300" />
                <p className="text-[10px] text-slate-500 mt-1">Upload JPG, PNG or WEBP. The file is stored securely in cloud storage.</p>
                <div className="text-center text-[10px] text-slate-500">or paste an image URL</div>
                <input type="url" placeholder="https://..." value={photoUrl} onChange={e => setPhotoUrl(e.target.value)} className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none" />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Date Taken *</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Description</label>
                <input
                  type="text"
                  placeholder="e.g. First floor slab centering completed"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Engineer / Site Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Mortar curing checked by site supervisor"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsUploadOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Save Photo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
