import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  CheckCircle2,
  Clock,
  ExternalLink,
  Search,
  IndianRupee,
  Check,
  X,
  Eye,
  FileCheck,
  Upload,
} from 'lucide-react';
import { Payment, PaymentMethod, ExpenseCategory } from '../../types.js';
import { localDateInputValue } from '../../api/validation.js';

interface PaymentsViewProps {
  payments: Payment[];
  onMarkPaid: (id: string, method?: string) => void;
  onRecordPayment: (payment: any) => void;
  onViewProof: (url: string, title: string) => void;
  onAttachProof: (paymentId: string, file: File) => Promise<void>;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  payments,
  onMarkPaid,
  onRecordPayment,
  onViewProof,
  onAttachProof,
}) => {
  const [isRecordOpen, setIsRecordOpen] = useState(false);
  const [filter, setFilter] = useState<'All' | 'Paid' | 'Pending'>('All');
  const [searchTerm, setSearchTerm] = useState('');

  // Record payment form state
  const [recipient, setRecipient] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Contractor');
  const [amount, setAmount] = useState<number>(0);
  const [date, setDate] = useState(localDateInputValue());
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<Payment['status']>('Paid');
  const [uploadingProofId, setUploadingProofId] = useState<string | null>(null);

  const totalPaid = payments
    .filter(p => p.status === 'Paid')
    .reduce((s, p) => s + p.amount, 0);

  const totalPending = payments
    .filter(p => p.status === 'Pending')
    .reduce((s, p) => s + p.amount, 0);
  const activePayees = new Set(payments.map(p => p.recipient.trim().toLowerCase()).filter(Boolean)).size;

  const filteredPayments = payments.filter(p => {
    if (filter !== 'All' && p.status !== filter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        p.recipient.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.notes && p.notes.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipient || amount <= 0) return;
    onRecordPayment({
      recipient,
      category,
      amount: Number(amount),
      date,
      paymentMethod,
      reference: reference || 'UPI/DIRECT',
      notes,
      paymentProofUrl: proofUrl,
      paymentProofFile: proofFile || undefined,
      status: paymentStatus,
    });
    setIsRecordOpen(false);
    setRecipient('');
    setAmount(0);
    setNotes('');
    setReference('');
    setProofUrl('');
    setProofFile(null);
    setPaymentStatus('Paid');
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            💳 Contractor & Supplier Payments
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              చెల్లింపులు & బకాయిలు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Track milestone payments, UPI transfer screenshots, and pending supplier dues.
          </p>
        </div>

        <button
          onClick={() => setIsRecordOpen(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> Record New Payment
        </button>
      </div>

      {/* KPI Cards: Paid vs Pending (Section 22) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-slate-900/90 border border-emerald-500/20 shadow-xl">
          <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider">
            Total Completed Payments
          </span>
          <h3 className="text-3xl font-black text-emerald-400 mt-1">
            ₹{totalPaid.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">Settled with verified receipts</p>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900/90 border border-rose-500/30 shadow-xl">
          <span className="text-xs text-rose-400 font-bold uppercase tracking-wider">
            Total Pending Dues (బకాయి)
          </span>
          <h3 className="text-3xl font-black text-rose-400 mt-1">
            ₹{totalPending.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-400 mt-1">Due for contractors & materials</p>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">
            Active Payees
          </span>
          <h3 className="text-3xl font-black text-slate-100 mt-1">{activePayees} payees</h3>
          <p className="text-xs text-slate-400 mt-1">Civil, Electrical, Plumbing, Steel</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search payments by contractor, category, or notes..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-2xl w-full sm:w-auto">
          {(['All', 'Pending', 'Paid'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filter === tab
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Payments List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPayments.map(pay => (
          <div
            key={pay.id}
            className={`p-5 rounded-3xl bg-slate-900/90 border shadow-xl flex flex-col justify-between transition-all ${
              pay.status === 'Pending' ? 'border-rose-500/30' : 'border-slate-800/90'
            }`}
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <h4 className="font-extrabold text-slate-100 text-base">{pay.recipient}</h4>
                  <span className="text-xs text-amber-400 font-semibold">{pay.category}</span>
                </div>
                <span
                  className={`text-xs font-black px-2.5 py-1 rounded-full flex items-center gap-1 ${
                    pay.status === 'Paid'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}
                >
                  {pay.status === 'Paid' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                  {pay.status}
                </span>
              </div>

              <p className="text-xs text-slate-400 my-2 leading-relaxed">
                {pay.notes || 'Milestone payment scheduled.'}
              </p>

              <div className="flex items-center justify-between text-xs py-2 px-3 rounded-xl bg-slate-950/60 border border-slate-800/80 my-3">
                <span className="text-slate-400">Due/Payment Date: {pay.date}</span>
                <span className="text-slate-400 font-medium">via {pay.paymentMethod}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-500 block">Amount</span>
                <span className="text-xl font-black text-slate-100">
                  ₹{pay.amount.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {pay.paymentProofUrl && (
                  <button
                    onClick={() => onViewProof(pay.paymentProofUrl!, `Payment Proof: ${pay.recipient}`)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 hover:text-white font-bold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" /> View Proof
                  </button>
                )}

                {!pay.paymentProofUrl && (
                  <label className={`px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors ${uploadingProofId === pay.id ? 'opacity-50 pointer-events-none' : ''}`}>
                    <Upload className="w-3.5 h-3.5" /> {uploadingProofId === pay.id ? 'Uploading…' : 'Add Receipt'}
                    <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="hidden" disabled={uploadingProofId === pay.id} onChange={async e => {
                      const file = e.target.files?.[0];
                      e.currentTarget.value = '';
                      if (!file) return;
                      if (file.size > 10 * 1024 * 1024) return;
                      try { setUploadingProofId(pay.id); await onAttachProof(pay.id, file); } finally { setUploadingProofId(null); }
                    }} />
                  </label>
                )}

                {pay.status === 'Pending' && (
                  <button
                    onClick={() => onMarkPaid(pay.id)}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-md transition-all flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" /> Mark as Paid
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Record Payment Modal */}
      {isRecordOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setIsRecordOpen(false)}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black text-slate-100 mb-1 flex items-center gap-2">
              💳 Record Construction Payment
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Record a milestone disbursement to a contractor, supplier, or technician.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Paid To / Recipient *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. ABC Civil Contractors"
                  value={recipient}
                  onChange={e => setRecipient(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Category *</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  >
                    <option value="Contractor">Contractor (కాంట్రాక్టర్)</option>
                    <option value="Materials">Materials (సామాగ్రి)</option>
                    <option value="Labour">Labour (లేబర్)</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Plumbing">Plumbing</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Amount (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={amount || ''}
                    onChange={e => setAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Method</label>
                  <select
                    value={paymentMethod}
                    onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  >
                    <option value="UPI">UPI (PhonePe / GPay)</option>
                    <option value="Bank Transfer">Bank Transfer (NEFT/RTGS)</option>
                    <option value="Cash">Cash (నగదు)</option>
                    <option value="Cheque">Cheque</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Payment Status</label>
                <select
                  value={paymentStatus}
                  onChange={e => setPaymentStatus(e.target.value as Payment['status'])}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                >
                  <option value="Paid">Paid / Completed</option>
                  <option value="Pending">Pending / Due</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">UPI / Bank Reference Number</label>
                <input
                  type="text"
                  placeholder="e.g. UPI/6253489110 or NEFT/HDFC/..."
                  value={reference}
                  onChange={e => setReference(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Slab casting stage 2 milestone payment"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Payment Receipt / Proof</label>
                <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-amber-400">
                    <Upload className="w-4 h-4" />
                    <span>{proofFile ? proofFile.name : 'Attach UPI screenshot, bank receipt, cheque image or PDF'}</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp,application/pdf"
                      className="hidden"
                      onChange={e => {
                        const file = e.target.files?.[0] || null;
                        if (file && file.size > 10 * 1024 * 1024) {
                          e.currentTarget.value = '';
                          setProofFile(null);
                          return;
                        }
                        setProofFile(file);
                      }}
                    />
                  </label>
                  <p className="text-[10px] text-slate-500 mt-2">Recommended: upload the actual payment confirmation. Maximum 10 MB.</p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRecordOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Record Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
