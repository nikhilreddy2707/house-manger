import React, { useEffect, useMemo, useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Search,
  Filter,
  Users,
  IndianRupee,
  Layers,
  ArrowRight,
  Clock,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { ConstructionLedgerItem, SummaryData } from '../../types.js';

interface DailySpendingViewProps {
  ledger: ConstructionLedgerItem[];
  summary: SummaryData;
}

export const DailySpendingView: React.FC<DailySpendingViewProps> = ({ ledger, summary }) => {
  const [selectedDate, setSelectedDate] = useState<string>(summary.today);
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');

  useEffect(() => { setSelectedDate(summary.today); }, [summary.today]);

  const dailyCards = useMemo(() => {
    return (summary.dailySpendingHistory || []).map((d: any) => ({
      ...d,
      displayDate: d.date === summary.today ? 'Today' : d.date,
      label: d.date === summary.today ? 'Today' : d.date === summary.yesterday ? 'Yesterday' : 'Recorded Day',
      electrical: d.electrical || 0,
      transport: d.transport || 0,
    }));
  }, [summary.dailySpendingHistory, summary.today, summary.yesterday]);

  // Transactions for selected date
  let selectedTransactions = ledger.filter(l => l.date === selectedDate);
  if (categoryFilter !== 'All') {
    selectedTransactions = selectedTransactions.filter(l => l.category === categoryFilter);
  }
  if (searchTerm) {
    selectedTransactions = selectedTransactions.filter(l =>
      l.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (l.recipientOrSupplier && l.recipientOrSupplier.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }

  const activeDayCard = dailyCards.find(d => d.date === selectedDate) || {
    date: selectedDate,
    displayDate: selectedDate,
    label: '',
    workers: (summary.dailySpendingHistory || []).find((d:any) => d.date === selectedDate)?.workers || 0,
    labour: selectedTransactions.filter(t => t.category === 'Labour').reduce((s, t) => s + t.amount, 0),
    materials: selectedTransactions.filter(t => t.category === 'Materials').reduce((s, t) => s + t.amount, 0),
    electrical: selectedTransactions.filter(t => t.category === 'Electrical').reduce((s, t) => s + t.amount, 0),
    transport: selectedTransactions.filter(t => t.category === 'Transport').reduce((s, t) => s + t.amount, 0),
    other: selectedTransactions.filter(t => !['Labour', 'Materials', 'Electrical', 'Transport'].includes(t.category)).reduce((s, t) => s + t.amount, 0),
    total: selectedTransactions.reduce((s, t) => s + t.amount, 0),
  };

  const handlePrevDay = () => {
    const idx = dailyCards.findIndex(d => d.date === selectedDate);
    if (idx < dailyCards.length - 1 && idx !== -1) {
      setSelectedDate(dailyCards[idx + 1].date);
    }
  };

  const handleNextDay = () => {
    const idx = dailyCards.findIndex(d => d.date === selectedDate);
    if (idx > 0) {
      setSelectedDate(dailyCards[idx - 1].date);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            📅 Daily Spending Analysis
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              రోజువారీ ఖర్చులు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Day-by-day construction breakdown with worker attendance, labour, materials, and transactions.
          </p>
        </div>

        {/* Date Stepper Controls */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1.5 rounded-2xl shadow-lg">
          <button
            onClick={handlePrevDay}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            title="Previous Day"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 px-3">
            <CalendarIcon className="w-4 h-4 text-amber-400" />
            <input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="bg-transparent text-xs font-bold text-slate-100 outline-none cursor-pointer"
            />
          </div>
          <button
            onClick={handleNextDay}
            disabled={selectedDate === summary.today}
            className="p-2 text-slate-400 hover:text-white disabled:opacity-30 rounded-xl hover:bg-slate-800 transition-colors"
            title="Next Day"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Selected Day Summary Card (Section 7) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                {activeDayCard.label || 'Selected Day'}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {activeDayCard.displayDate}
              </span>
            </div>
            <h3 className="text-2xl font-black text-white mt-1">
              Daily Total: ₹{activeDayCard.total.toLocaleString('en-IN')}
            </h3>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold text-slate-400">
            <div className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>{activeDayCard.workers} Workers Came</span>
            </div>
          </div>
        </div>

        {/* 6 Category Breakdown Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-4">
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-[11px] text-slate-400">Labour (కూలీ)</p>
            <p className="text-base font-extrabold text-slate-100 mt-1">
              ₹{activeDayCard.labour.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-[11px] text-slate-400">Materials (సామాగ్రి)</p>
            <p className="text-base font-extrabold text-amber-400 mt-1">
              ₹{activeDayCard.materials.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-[11px] text-slate-400">Electrical (వైరింగ్)</p>
            <p className="text-base font-extrabold text-blue-400 mt-1">
              ₹{activeDayCard.electrical.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-[11px] text-slate-400">Transport (రవాణా)</p>
            <p className="text-base font-extrabold text-slate-100 mt-1">
              ₹{activeDayCard.transport.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <p className="text-[11px] text-slate-400">Other (ఇతర)</p>
            <p className="text-base font-extrabold text-slate-100 mt-1">
              ₹{activeDayCard.other.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20">
            <p className="text-[11px] text-amber-400 font-bold">TOTAL</p>
            <p className="text-base font-black text-white mt-1">
              ₹{activeDayCard.total.toLocaleString('en-IN')}
            </p>
          </div>
        </div>
      </div>

      {/* Daily Spending Trend Chart (Section 7) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl">
        <h3 className="text-base font-extrabold text-slate-100 mb-1">Daily Spending Chart</h3>
        <p className="text-xs text-slate-400 mb-4">Click any bar to view that day's complete transactions</p>
        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={summary.dailySpendingHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              <XAxis dataKey="displayDate" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis
                stroke="#64748b"
                fontSize={11}
                tickFormatter={v => `₹${(v / 1000).toFixed(0)}k`}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '12px',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Spending']}
              />
              <Bar dataKey="amount" fill="#f59e0b" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Transactions for the Selected Date */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-extrabold text-slate-100">
              All Transactions for {activeDayCard.displayDate}
            </h3>
            <p className="text-xs text-slate-400">
              Showing {selectedTransactions.length} transaction records
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search in day..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-100 outline-none"
            />
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none"
            >
              <option value="All">All Categories</option>
              <option value="Materials">Materials</option>
              <option value="Labour">Labour</option>
              <option value="Electrical">Electrical</option>
              <option value="Transport">Transport</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        {selectedTransactions.length === 0 ? (
          <div className="p-8 text-center bg-slate-950/40 rounded-2xl border border-dashed border-slate-800 text-slate-500 text-xs">
            No transactions found for this date with selected filters.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60">
            {selectedTransactions.map(item => (
              <div
                key={item.id}
                className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <h4 className="font-bold text-slate-200 text-sm">{item.description}</h4>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                    <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {item.category}
                    </span>
                    {item.recipientOrSupplier && (
                      <span>• Paid to: {item.recipientOrSupplier}</span>
                    )}
                    {item.paymentMethod && <span>• via {item.paymentMethod}</span>}
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="text-base font-extrabold text-slate-100">
                      ₹{item.amount.toLocaleString('en-IN')}
                    </span>
                    <span
                      className={`block text-[10px] font-bold ${
                        item.paymentStatus === 'Paid' ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {item.paymentStatus}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
