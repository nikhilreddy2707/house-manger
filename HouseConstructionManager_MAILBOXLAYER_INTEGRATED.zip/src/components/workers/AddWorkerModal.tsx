import React, { useState } from 'react';
import { X, Plus, UserCheck } from 'lucide-react';
import { WorkerRole } from '../../types.js';

interface AddWorkerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (worker: { name: string; role: WorkerRole; workerType: string; dailyWage: number; phone?: string; notes?: string }) => void;
}

export const AddWorkerModal: React.FC<AddWorkerModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState<WorkerRole>('Mason');
  const [workerType, setWorkerType] = useState('Head Mason');
  const [dailyWage, setDailyWage] = useState(800);
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({
      name: name.trim(),
      role,
      workerType: workerType || role,
      dailyWage: Number(dailyWage) || 500,
      phone: phone.trim(),
      notes: notes.trim(),
    });
    setName('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl font-black text-slate-100 mb-1 flex items-center gap-2">
          👷 Add New Construction Worker
        </h3>
        <p className="text-xs text-slate-400 mb-5">
          Register a mason, helper, carpenter, or technician to track their daily attendance and wages.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-300 mb-1">Worker Full Name (పేరు) *</label>
            <input
              type="text"
              required
              placeholder="e.g. Ramesh Kumar"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Primary Role *</label>
              <select
                value={role}
                onChange={e => {
                  const r = e.target.value as WorkerRole;
                  setRole(r);
                  if (r === 'Mason') setDailyWage(800);
                  else if (r === 'Helper') setDailyWage(500);
                  else if (r === 'Carpenter') setDailyWage(700);
                  else if (r === 'Electrician' || r === 'Plumber') setDailyWage(700);
                }}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
              >
                <option value="Mason">Mason (మేస్త్రీ)</option>
                <option value="Helper">Helper (హెల్పర్ / కూలీ)</option>
                <option value="Carpenter">Carpenter (కార్పెంటర్)</option>
                <option value="Electrician">Electrician (ఎలక్ట్రీషియన్)</option>
                <option value="Plumber">Plumber (ప్లంబర్)</option>
                <option value="Painter">Painter (పెయింటర్)</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Daily Wage (₹) *</label>
              <input
                type="number"
                step="50"
                required
                value={dailyWage}
                onChange={e => setDailyWage(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-300 mb-1">Phone Number (Optional)</label>
            <input
              type="text"
              placeholder="+91 98480 XXXXX"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-300 mb-1">Notes</label>
            <textarea
              rows={2}
              placeholder="e.g. Recommended by civil contractor..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20"
            >
              Add Worker
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
