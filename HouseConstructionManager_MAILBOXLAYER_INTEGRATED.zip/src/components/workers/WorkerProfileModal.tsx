import React from 'react';
import { X, Calendar, IndianRupee, Phone, CheckCircle, Clock, Award } from 'lucide-react';
import { Worker } from '../../types.js';

interface WorkerProfileModalProps {
  worker: Worker | null;
  attendance?: any[];
  onClose: () => void;
}

export const WorkerProfileModal: React.FC<WorkerProfileModalProps> = ({ worker, attendance = [], onClose }) => {
  if (!worker) return null;

  const monthly = new Map<string, { days: number; wages: number; paid: number }>();
  for (const record of attendance.filter(a => a.workerId === worker.id && a.status !== 'Absent')) {
    const key = String(record.date || '').slice(0, 7);
    if (!key) continue;
    const row = monthly.get(key) || { days: 0, wages: 0, paid: 0 };
    row.days += record.status === 'Half Day' ? 0.5 : 1;
    row.wages += Number(record.wageAmount) || 0;
    row.paid += Number(record.paidAmount) || 0;
    monthly.set(key, row);
  }
  const monthlyBreakdown = [...monthly.entries()]
    .sort((a, b) => b[0].localeCompare(a[0]))
    .slice(0, 12)
    .map(([month, row]) => ({ month: new Intl.DateTimeFormat('en-IN', { month: 'long', year: 'numeric' }).format(new Date(`${month}-01T00:00:00`)), ...row }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-300 text-slate-950 font-black text-2xl flex items-center justify-center shadow-lg shadow-amber-500/20">
            {worker.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-black text-slate-100">{worker.name}</h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {worker.status.toUpperCase()}
              </span>
            </div>
            <p className="text-xs text-amber-400 font-semibold mt-0.5">
              {worker.role} • {worker.workerType}
            </p>
            {worker.phone && (
              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-slate-500" /> {worker.phone}
              </p>
            )}
          </div>
        </div>

        {/* Wages KPI Cards (Section 15) */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">Total Days Worked</span>
            <p className="text-lg font-black text-slate-100 mt-1">{worker.totalDaysWorked} days</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">Total Wages</span>
            <p className="text-lg font-black text-slate-100 mt-1">
              ₹{worker.totalWagesEarned.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">Daily Wage</span>
            <p className="text-lg font-black text-amber-400 mt-1">₹{worker.dailyWage}</p>
          </div>
        </div>

        {/* Paid vs Pending Bar */}
        <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 mb-6 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400">Amount Paid:</span>
            <p className="text-base font-extrabold text-emerald-400 mt-0.5">
              ₹{worker.totalPaid.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-400">Pending Balance:</span>
            <p className="text-base font-extrabold text-rose-400 mt-0.5">
              ₹{worker.pendingBalance.toLocaleString('en-IN')}
            </p>
          </div>
        </div>

        {/* Monthly Attendance Table (Section 15) */}
        <div>
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-amber-400" />
            Monthly Attendance Breakdown (నెలవారీ హాజరు)
          </h4>
          <div className="rounded-2xl border border-slate-800 overflow-hidden">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Month</th>
                  <th className="py-2.5 px-3 text-center">Days</th>
                  <th className="py-2.5 px-3 text-right">Earned</th>
                  <th className="py-2.5 px-3 text-right">Paid</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                {monthlyBreakdown.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-800/30">
                    <td className="py-2.5 px-3 font-medium text-slate-200">{row.month}</td>
                    <td className="py-2.5 px-3 text-center font-bold text-amber-400">
                      {row.days} days
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold text-slate-300">
                      ₹{row.wages.toLocaleString('en-IN')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-extrabold text-emerald-400">
                      ₹{row.paid.toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Notes */}
        {worker.notes && (
          <div className="mt-5 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60 text-xs text-slate-400">
            <strong className="text-slate-300">Notes:</strong> {worker.notes}
          </div>
        )}
      </div>
    </div>
  );
};
