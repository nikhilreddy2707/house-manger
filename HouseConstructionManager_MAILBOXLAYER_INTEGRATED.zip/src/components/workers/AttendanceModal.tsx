import React, { useState } from 'react';
import { X, Calendar, Check, Users, IndianRupee, Sparkles } from 'lucide-react';
import { Worker } from '../../types.js';
import { localDateInputValue } from '../../api/validation.js';

interface AttendanceModalProps {
  isOpen: boolean;
  workers: Worker[];
  onClose: () => void;
  onSubmit: (items: { workerId: string; status: 'Present' | 'Absent'; date: string; paidAmount?: number }[]) => void;
}

export const AttendanceModal: React.FC<AttendanceModalProps> = ({
  isOpen,
  workers,
  onClose,
  onSubmit,
}) => {
  const [date, setDate] = useState(localDateInputValue());
  const [attendanceMap, setAttendanceMap] = useState<Record<string, boolean>>(() => {
    const map: Record<string, boolean> = {};
    workers.forEach(w => {
      map[w.id] = true; // default present
    });
    return map;
  });

  if (!isOpen) return null;

  const toggleWorker = (id: string) => {
    setAttendanceMap(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const presentWorkers = workers.filter(w => attendanceMap[w.id]);
  const totalLabourCost = presentWorkers.reduce((sum, w) => sum + w.dailyWage, 0);

  // Group by role for summary
  const roleCounts: Record<string, number> = {};
  presentWorkers.forEach(w => {
    roleCounts[w.role] = (roleCounts[w.role] || 0) + 1;
  });

  const handleSave = () => {
    const items = workers.map(w => ({
      workerId: w.id,
      status: attendanceMap[w.id] ? ('Present' as const) : ('Absent' as const),
      date,
      paidAmount: attendanceMap[w.id] ? w.dailyWage : 0,
    }));
    onSubmit(items);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl relative max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-4">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
            Daily Labour Entry
          </span>
          <h3 className="text-xl font-black text-slate-100 mt-0.5 flex items-center gap-2">
            👷 Record Worker Attendance
          </h3>
          <p className="text-xs text-slate-400">
            Select workers present on site. Daily wages will be automatically synchronized with your expense ledger.
          </p>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800 mb-4">
          <Calendar className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-slate-300 font-bold">Attendance Date:</span>
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            className="bg-transparent text-xs text-amber-400 font-bold outline-none cursor-pointer"
          />
        </div>

        {/* Live Calculation Banner (Section 16) */}
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 mb-4 flex items-center justify-between text-xs">
          <div>
            <div className="flex items-center gap-2 text-amber-300 font-bold">
              <Users className="w-4 h-4" />
              <span>{presentWorkers.length} Workers Present</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {Object.entries(roleCounts)
                .map(([role, count]) => `${count} ${role}s`)
                .join(', ')}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-400 text-[11px]">Total Labour Cost</span>
            <p className="text-lg font-black text-white">₹{totalLabourCost.toLocaleString('en-IN')}</p>
          </div>
        </div>

        {/* Workers Checklist */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-2 mb-4">
          {workers.map(w => {
            const isPresent = !!attendanceMap[w.id];
            return (
              <div
                key={w.id}
                onClick={() => toggleWorker(w.id)}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                  isPresent
                    ? 'bg-slate-800/80 border-amber-500/40 text-slate-100 shadow-sm'
                    : 'bg-slate-950/40 border-slate-800 text-slate-500 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center border text-xs font-bold transition-colors ${
                      isPresent
                        ? 'bg-amber-500 border-amber-500 text-slate-950'
                        : 'border-slate-700 bg-slate-900'
                    }`}
                  >
                    {isPresent && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                  <div>
                    <h5 className="font-bold text-xs">{w.name}</h5>
                    <p className="text-[11px] text-slate-400">
                      {w.role} • {w.workerType}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-black text-amber-400">₹{w.dailyWage}</span>
                  <span className="block text-[10px] text-slate-400">/ day</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-slate-800 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" /> Save Attendance & Wages
          </button>
        </div>
      </div>
    </div>
  );
};
