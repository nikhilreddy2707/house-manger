import React, { useState } from 'react';
import {
  Users,
  Plus,
  Calendar,
  IndianRupee,
  Phone,
  Eye,
  CheckCircle2,
  Clock,
  Search,
  Filter,
} from 'lucide-react';
import { Worker, WorkerRole } from '../../types.js';
import { WorkerProfileModal } from './WorkerProfileModal.js';
import { AttendanceModal } from './AttendanceModal.js';
import { AddWorkerModal } from './AddWorkerModal.js';

interface WorkersViewProps {
  workers: Worker[];
  onAddWorker: (worker: any) => void;
  onRecordAttendance: (items: any) => void;
  onUpdateWorker: (id: string, updates: any) => void;
  attendance?: any[];
}

export const WorkersView: React.FC<WorkersViewProps> = ({
  workers,
  onAddWorker,
  onRecordAttendance,
  onUpdateWorker,
  attendance = [],
}) => {
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);
  const [isAttendanceOpen, setIsAttendanceOpen] = useState(false);
  const [isAddWorkerOpen, setIsAddWorkerOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('All');

  const filteredWorkers = workers.filter(w => {
    if (roleFilter !== 'All' && w.role !== roleFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return w.name.toLowerCase().includes(q) || w.role.toLowerCase().includes(q);
    }
    return true;
  });

  const totalWagesAll = workers.reduce((s, w) => s + w.totalWagesEarned, 0);
  const totalPaidAll = workers.reduce((s, w) => s + w.totalPaid, 0);
  const totalPendingAll = workers.reduce((s, w) => s + w.pendingBalance, 0);

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            👷 Construction Workers & Attendance
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              వర్కర్లు & హాజరు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Track daily attendance, wages earned, payments, and balances for masons, helpers, and technicians.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAttendanceOpen(true)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <Calendar className="w-4 h-4 text-amber-400" /> Record Attendance
          </button>
          <button
            onClick={() => setIsAddWorkerOpen(true)}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
          >
            <Plus className="w-4 h-4" /> Add Worker
          </button>
        </div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400">Total Registered Workers</span>
          <p className="text-2xl font-black text-slate-100 mt-1">{workers.length}</p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400">Total Wages Earned</span>
          <p className="text-2xl font-black text-slate-100 mt-1">₹{totalWagesAll.toLocaleString('en-IN')}</p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/20">
          <span className="text-xs text-emerald-400 font-bold">Total Paid</span>
          <p className="text-2xl font-black text-emerald-400 mt-1">₹{totalPaidAll.toLocaleString('en-IN')}</p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-rose-500/20">
          <span className="text-xs text-rose-400 font-bold">Pending Wages</span>
          <p className="text-2xl font-black text-rose-400 mt-1">₹{totalPendingAll.toLocaleString('en-IN')}</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search workers by name or role..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
          />
        </div>

        <select
          value={roleFilter}
          onChange={e => setRoleFilter(e.target.value)}
          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none w-full sm:w-44"
        >
          <option value="All">All Roles</option>
          <option value="Mason">Mason (మేస్త్రీ)</option>
          <option value="Helper">Helper (హెల్పర్)</option>
          <option value="Carpenter">Carpenter (కార్పెంటర్)</option>
          <option value="Electrician">Electrician</option>
          <option value="Plumber">Plumber</option>
          <option value="Painter">Painter</option>
        </select>
      </div>

      {/* Workers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredWorkers.map(worker => (
          <div
            key={worker.id}
            className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800/90 hover:border-amber-500/40 shadow-xl transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 text-amber-400 font-black text-lg flex items-center justify-center border border-slate-700">
                    {worker.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-100 text-sm">{worker.name}</h4>
                    <span className="inline-block px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 text-[10px] font-bold mt-0.5">
                      {worker.role}
                    </span>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    worker.status === 'active'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {worker.status}
                </span>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center my-3 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block">Daily Wage</span>
                  <span className="font-bold text-slate-200">₹{worker.dailyWage}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Days Worked</span>
                  <span className="font-bold text-slate-200">{worker.totalDaysWorked}d</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Pending</span>
                  <span
                    className={`font-bold ${
                      worker.pendingBalance > 0 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    ₹{worker.pendingBalance}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
              {worker.phone ? (
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-500" /> {worker.phone}
                </span>
              ) : (
                <span className="text-[11px] text-slate-500 italic">No phone logged</span>
              )}

              <button
                onClick={() => setSelectedWorker(worker)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-400 hover:text-white transition-colors flex items-center gap-1"
              >
                <Eye className="w-3.5 h-3.5" /> View Profile
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Worker Profile Modal */}
      <WorkerProfileModal
        worker={selectedWorker}
        attendance={attendance}
        onClose={() => setSelectedWorker(null)}
      />

      {/* Bulk Attendance Modal */}
      <AttendanceModal
        isOpen={isAttendanceOpen}
        workers={workers}
        onClose={() => setIsAttendanceOpen(false)}
        onSubmit={items => {
          onRecordAttendance(items);
          setIsAttendanceOpen(false);
        }}
      />

      {/* Add Worker Modal */}
      <AddWorkerModal
        isOpen={isAddWorkerOpen}
        onClose={() => setIsAddWorkerOpen(false)}
        onSubmit={onAddWorker}
      />
    </div>
  );
};
