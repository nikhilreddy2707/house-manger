import React, { useState } from 'react';
import {
  IndianRupee,
  Plus,
  Trash2,
  Eye,
  Search,
  Filter,
  CreditCard,
  X,
  FileText,
  Mic,
} from 'lucide-react';
import { Expense, ExpenseCategory, PaymentMethod } from '../../types.js';
import { localDateInputValue } from '../../api/validation.js';
import { ConfirmationDialog } from '../common/ConfirmationDialog.js';

interface ExpensesViewProps {
  expenses: Expense[];
  onAddExpense: (expense: any) => void;
  onDeleteExpense: (id: string) => void;
  onViewProof: (url: string, title: string) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses,
  onAddExpense,
  onDeleteExpense,
  onViewProof,
}) => {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [deleteCandidate, setDeleteCandidate] = useState<Expense | null>(null);

  // Form State
  const [date, setDate] = useState(localDateInputValue());
  const [category, setCategory] = useState<ExpenseCategory>('Electrical');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [recipient, setRecipient] = useState('');
  const [notes, setNotes] = useState('');
  const [receiptFile, setReceiptFile] = useState<File | null>(null);

  const categories: ExpenseCategory[] = [
    'Materials',
    'Labour',
    'Transport',
    'Electrical',
    'Plumbing',
    'Flooring',
    'Painting',
    'Contractor',
    'Equipment',
    'Doors/Windows',
    'Other',
  ];

  const filteredExpenses = expenses.filter(exp => {
    if (categoryFilter !== 'All' && exp.category !== categoryFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        exp.description.toLowerCase().includes(q) ||
        exp.recipient.toLowerCase().includes(q) ||
        exp.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalFilteredAmount = filteredExpenses.reduce((s, e) => s + e.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || amount <= 0) return;
    onAddExpense({
      date,
      category,
      description,
      amount: Number(amount),
      paymentMethod,
      paymentStatus: 'Paid',
      recipient: recipient || 'Vendor',
      notes,
      receiptFile: receiptFile || undefined,
    });
    setIsAddOpen(false);
    setDescription('');
    setAmount(0);
    setNotes('');
    setReceiptFile(null);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            💰 Construction Expenses Management
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              ఖర్చుల వివరాలు
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Categorized daily site costs with payment methods, supplier attribution, and digital receipts.
          </p>
        </div>

        <button
          onClick={() => setIsAddOpen(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> Add Expense
        </button>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search expenses by description, vendor, or category..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none w-full sm:w-48"
        >
          <option value="All">All Categories</option>
          {categories.map(c => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Expenses Table */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] text-slate-400 uppercase bg-slate-950/80 border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4 font-bold">Date</th>
                <th className="py-3.5 px-4 font-bold">Category</th>
                <th className="py-3.5 px-4 font-bold">Description</th>
                <th className="py-3.5 px-4 font-bold">Paid To</th>
                <th className="py-3.5 px-4 font-bold">Method</th>
                <th className="py-3.5 px-4 font-bold text-right">Amount</th>
                <th className="py-3.5 px-4 font-bold">Source</th>
                <th className="py-3.5 px-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredExpenses.map(exp => (
                <tr key={exp.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-medium text-slate-400 whitespace-nowrap">
                    {exp.date}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                      {exp.category}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-slate-100">{exp.description}</td>
                  <td className="py-3.5 px-4 text-slate-400">{exp.recipient}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-slate-950 text-slate-400 border border-slate-800 text-[10px]">
                      {exp.paymentMethod}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-black text-slate-100 whitespace-nowrap">
                    ₹{exp.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    {exp.source?.includes('Voice') ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400">
                        <Mic className="w-3 h-3" /> Voice
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">{exp.source || 'Manual'}</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    {exp.receiptUrl && (
                      <button onClick={() => onViewProof(exp.receiptUrl!, `Expense Receipt: ${exp.description}`)} className="p-1.5 rounded-lg text-amber-400 hover:text-white hover:bg-slate-800 transition-colors" title="View Receipt">
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => setDeleteCandidate(exp)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Delete Expense"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation */}
      <ConfirmationDialog
        isOpen={!!deleteCandidate}
        title="Delete this expense?"
        message={`Are you sure you want to delete "${deleteCandidate?.description}" for ₹${deleteCandidate?.amount.toLocaleString('en-IN')}?`}
        confirmLabel="Delete Expense"
        cancelLabel="Cancel"
        isDestructive={true}
        onConfirm={() => {
          if (deleteCandidate) {
            onDeleteExpense(deleteCandidate.id);
            setDeleteCandidate(null);
          }
        }}
        onCancel={() => setDeleteCandidate(null)}
      />

      {/* Add Expense Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setIsAddOpen(false)}
              className="absolute right-5 top-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black text-slate-100 mb-1 flex items-center gap-2">
              💰 Add Construction Expense
            </h3>
            <p className="text-xs text-slate-400 mb-5">Record a daily expense at the job site.</p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Category *</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Description *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Finolex electrical wires bundle"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Amount (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={amount || ''}
                    onChange={e => setAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                  >
                    <option value="UPI">UPI (GPay / PhonePe)</option>
                    <option value="Cash">Cash (నగదు)</option>
                    <option value="Bank Transfer">Bank Transfer (NEFT)</option>
                    <option value="Cheque">Cheque</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Paid To / Supplier</label>
                <input
                  type="text"
                  placeholder="e.g. Lakshmi Electricals"
                  value={recipient}
                  onChange={e => setRecipient(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Receipt / Payment Proof</label>
                <label className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-950 p-3 cursor-pointer text-xs font-bold text-amber-400">
                  <FileText className="w-4 h-4" />
                  <span className="truncate">{receiptFile ? receiptFile.name : 'Attach receipt image or PDF'}</span>
                  <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="hidden" onChange={e => { const f=e.target.files?.[0]||null; if(f && f.size<=10*1024*1024) setReceiptFile(f); else if(f) setReceiptFile(null); }} />
                </label>
                <p className="text-[10px] text-slate-500 mt-1">Maximum 10 MB. Store the actual proof for audit purposes.</p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
