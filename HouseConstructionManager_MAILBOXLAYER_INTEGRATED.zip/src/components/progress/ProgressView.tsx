import React, { useState } from 'react';
import {
  HardHat,
  CheckCircle2,
  Clock,
  AlertCircle,
  Calendar,
  Sparkles,
  ChevronRight,
  Edit2,
  Check,
} from 'lucide-react';
import { ConstructionStage, StageStatus } from '../../types.js';

interface ProgressViewProps {
  progressData: {
    overallPercentage: number;
    stages: ConstructionStage[];
  };
  onUpdateStage: (id: string, percentage: number, status?: string, notes?: string) => void;
}

export const ProgressView: React.FC<ProgressViewProps> = ({ progressData, onUpdateStage }) => {
  const [editingStageId, setEditingStageId] = useState<string | null>(null);
  const [editPercentage, setEditPercentage] = useState<number>(0);
  const [editStatus, setEditStatus] = useState<StageStatus>('In Progress');
  const [editNotes, setEditNotes] = useState('');

  const handleStartEdit = (stage: ConstructionStage) => {
    setEditingStageId(stage.id);
    setEditPercentage(stage.percentageComplete);
    setEditStatus(stage.status);
    setEditNotes(stage.notes || '');
  };

  const handleSaveStage = (stageId: string) => {
    onUpdateStage(stageId, editPercentage, editStatus, editNotes);
    setEditingStageId(null);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2">
            🏗️ Construction Progress & Milestones
            <span className="text-xs font-bold font-telugu text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              నిర్మాణ పురోగతి
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Track all 10 stages from deep foundation and RCC framing to plastering and finishing.
          </p>
        </div>

        <div className="px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center gap-2 font-bold text-xs">
          <HardHat className="w-4 h-4" />
          <span>Current Active Stage: First Floor Roof Slab</span>
        </div>
      </div>

      {/* Overall Progress Meter Card (Section 29) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-amber-500/30 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">
              House Construction Completion
            </span>
            <h3 className="text-3xl font-black text-white mt-0.5">
              Overall Progress: {progressData.overallPercentage}%
            </h3>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400 block">Target Completion</span>
            <span className="text-xs font-bold text-slate-200">31 December 2026</span>
          </div>
        </div>

        {/* Master Progress Bar */}
        <div className="w-full bg-slate-950 h-4 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-400 rounded-full transition-all duration-1000"
            style={{ width: `${progressData.overallPercentage}%` }}
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>2 Stages Completed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span>4 Stages In Progress</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-600" />
            <span>4 Stages Upcoming</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>On Schedule</span>
          </div>
        </div>
      </div>

      {/* 10 Construction Stages Grid (Section 29) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {progressData.stages.map((stage, idx) => {
          const isEditing = editingStageId === stage.id;
          const statusColors = {
            Completed: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
            'In Progress': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
            'Not Started': 'bg-slate-800 text-slate-400 border-slate-700',
            Delayed: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
          };

          return (
            <div
              key={stage.id}
              className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-xl bg-slate-800 text-amber-400 font-black text-xs flex items-center justify-center border border-slate-700">
                      {idx + 1}
                    </span>
                    <div>
                      <h4 className="font-extrabold text-slate-100 text-sm">{stage.stageName}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {stage.startDate ? `Started: ${stage.startDate}` : 'Upcoming stage'}
                      </p>
                    </div>
                  </div>

                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${statusColors[stage.status]}`}>
                    {stage.status}
                  </span>
                </div>

                {/* Percentage progress bar */}
                <div className="my-3">
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="text-slate-400">Completion</span>
                    <span className="text-amber-400">{stage.percentageComplete}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all ${
                        stage.percentageComplete === 100
                          ? 'bg-emerald-500'
                          : 'bg-gradient-to-r from-amber-500 to-amber-400'
                      }`}
                      style={{ width: `${stage.percentageComplete}%` }}
                    />
                  </div>
                </div>

                {stage.notes && (
                  <p className="text-xs text-slate-400 leading-relaxed bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/60">
                    {stage.notes}
                  </p>
                )}

                {/* Inline Stage Editor */}
                {isEditing && (
                  <div className="mt-3 p-3 bg-slate-950 rounded-2xl border border-amber-500/40 space-y-3 text-xs">
                    <div>
                      <div className="flex justify-between font-bold mb-1">
                        <label>Update Percentage:</label>
                        <span className="text-amber-400">{editPercentage}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={editPercentage}
                        onChange={e => setEditPercentage(Number(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    <div className="flex gap-2">
                      <select
                        value={editStatus}
                        onChange={e => setEditStatus(e.target.value as StageStatus)}
                        className="bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-slate-200 outline-none flex-1 text-xs"
                      >
                        <option value="Not Started">Not Started</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Delayed">Delayed</option>
                      </select>

                      <button
                        onClick={() => handleSaveStage(stage.id)}
                        className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Save
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {!isEditing && (
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-slate-500 text-[11px]">
                    Target: {stage.targetDate || 'TBD'}
                  </span>
                  <button
                    onClick={() => handleStartEdit(stage)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 hover:text-white font-bold transition-colors flex items-center gap-1"
                  >
                    <Edit2 className="w-3 h-3" /> Update Progress
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
