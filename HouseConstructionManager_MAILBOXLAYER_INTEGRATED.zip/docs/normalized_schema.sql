-- Production data layer for House Construction Manager.
-- Run after schema.sql. The app automatically uses this table when present.
-- Each project record is stored independently instead of rewriting one giant JSON document.

create table if not exists public.hcm_records (
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id text not null,
  entity_type text not null check (entity_type in ('meta','project','workers','attendance','materials','purchases','expenses','payments','budgets','stages','photos','bills')),
  record_id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, project_id, entity_type, record_id)
);

create index if not exists hcm_records_user_project_idx
  on public.hcm_records(user_id, project_id);
create index if not exists hcm_records_user_entity_idx
  on public.hcm_records(user_id, entity_type);
create index if not exists hcm_records_updated_idx
  on public.hcm_records(updated_at desc);

alter table public.hcm_records enable row level security;

drop policy if exists "Users can view own HCM records" on public.hcm_records;
create policy "Users can view own HCM records" on public.hcm_records
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Users can insert own HCM records" on public.hcm_records;
create policy "Users can insert own HCM records" on public.hcm_records
  for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "Users can update own HCM records" on public.hcm_records;
create policy "Users can update own HCM records" on public.hcm_records
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users can delete own HCM records" on public.hcm_records;
create policy "Users can delete own HCM records" on public.hcm_records
  for delete to authenticated using (auth.uid() = user_id);

-- Optional one-time migration helper for an existing installation:
-- The web application migrates a user's legacy hcm_user_data into hcm_records
-- automatically on first login after this table exists.
