-- House Construction Manager — production Supabase setup
-- Run this entire file once in Supabase SQL Editor.
-- It enables customer isolation, private receipts, and scalable record-level storage.

create table if not exists public.hcm_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.hcm_user_data enable row level security;
drop policy if exists "Users can view own construction data" on public.hcm_user_data;
create policy "Users can view own construction data" on public.hcm_user_data for select using (auth.uid() = user_id);
drop policy if exists "Users can insert own construction data" on public.hcm_user_data;
create policy "Users can insert own construction data" on public.hcm_user_data for insert with check (auth.uid() = user_id);
drop policy if exists "Users can update own construction data" on public.hcm_user_data;
create policy "Users can update own construction data" on public.hcm_user_data for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.hcm_records (
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id text not null,
  entity_type text not null check (entity_type in ('meta','project','workers','attendance','materials','purchases','expenses','payments','budgets','stages','photos','bills')),
  record_id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, project_id, entity_type, record_id)
);
create index if not exists hcm_records_user_project_idx on public.hcm_records(user_id, project_id);
create index if not exists hcm_records_user_entity_idx on public.hcm_records(user_id, entity_type);
create index if not exists hcm_records_updated_idx on public.hcm_records(updated_at desc);
alter table public.hcm_records enable row level security;
drop policy if exists "Users can view own HCM records" on public.hcm_records;
create policy "Users can view own HCM records" on public.hcm_records for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert own HCM records" on public.hcm_records;
create policy "Users can insert own HCM records" on public.hcm_records for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update own HCM records" on public.hcm_records;
create policy "Users can update own HCM records" on public.hcm_records for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own HCM records" on public.hcm_records;
create policy "Users can delete own HCM records" on public.hcm_records for delete to authenticated using (auth.uid() = user_id);

insert into storage.buckets (id, name, public)
values ('construction-files', 'construction-files', false)
on conflict (id) do update set public = false;
update storage.buckets set public = false, file_size_limit = 10485760,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','application/pdf']
where id = 'construction-files';

drop policy if exists "Users can upload construction files" on storage.objects;
create policy "Users can upload construction files" on storage.objects for insert to authenticated
  with check (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users can view construction files" on storage.objects;
create policy "Users can view construction files" on storage.objects for select to authenticated
  using (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users can update construction files" on storage.objects;
create policy "Users can update construction files" on storage.objects for update to authenticated
  using (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users can delete construction files" on storage.objects;
create policy "Users can delete construction files" on storage.objects for delete to authenticated
  using (bucket_id = 'construction-files' and (storage.foldername(name))[1] = auth.uid()::text);
