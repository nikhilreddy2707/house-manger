See ../REAL_WORLD_DEPLOYMENT.md for the production multi-account, payment-receipt, Supabase Auth, storage-security, and launch acceptance checklist.
