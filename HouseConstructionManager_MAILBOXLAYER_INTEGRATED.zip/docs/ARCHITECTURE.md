# Architecture

## Current compatibility architecture

The application keeps a per-user compatibility workspace snapshot so existing deployments and data are not broken. The UI is still split into lazy-loaded feature modules, while `src/api/localApi.ts` owns domain state and `src/api/remoteApi.ts` owns Supabase persistence and secure file URL resolution.

## Boundaries

- `src/components/` — presentation and feature workflows
- `src/api/localApi.ts` — domain operations and compatibility state engine
- `src/api/remoteApi.ts` — authenticated cloud persistence, file uploads, signed URLs, OCR integration
- `src/api/supabaseClient.ts` — low-level Supabase Auth/REST/Storage transport
- `src/api/validation.ts` — reusable input/file validation
- `src/types.ts` — shared domain contracts
- `supabase/schema.sql` — RLS, storage security and current compatibility table

## Scale-up path

For a large multi-user deployment, move each domain collection out of the JSONB snapshot and into normalized PostgreSQL tables. Keep the current API surface so the React UI does not need a full rewrite.

Recommended indexes:

- every `project_id` / `house_id` foreign key
- `date` on attendance, expenses, purchases and payments
- `status` on payments/attendance
- `(project_id, date)` composite indexes for dashboard/report queries

Use SQL aggregation and pagination for reports instead of downloading the entire project history.
