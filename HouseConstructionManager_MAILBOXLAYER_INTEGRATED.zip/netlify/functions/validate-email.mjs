export default async (request) => {
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ ok: false, error: 'Method not allowed' }), {
      status: 405,
      headers: { 'content-type': 'application/json' },
    });
  }

  const key = process.env.MAILBOXLAYER_API_KEY;
  if (!key) {
    return new Response(JSON.stringify({ ok: true, skipped: true, reason: 'Mailboxlayer is not configured' }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  }

  let body;
  try { body = await request.json(); } catch {
    return new Response(JSON.stringify({ ok: false, error: 'Invalid JSON' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }

  const email = String(body?.email || '').trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return new Response(JSON.stringify({ ok: false, valid: false, error: 'Enter a valid email address.' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }

  try {
    const url = new URL('https://apilayer.net/api/check');
    url.searchParams.set('access_key', key);
    url.searchParams.set('email', email);
    url.searchParams.set('format', '1');

    const upstream = await fetch(url, { signal: AbortSignal.timeout(8000) });
    const data = await upstream.json();

    if (!upstream.ok || data?.success === false) {
      return new Response(JSON.stringify({ ok: true, skipped: true, reason: data?.error?.info || 'Mailboxlayer unavailable' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      });
    }

    const valid = Boolean(data.format_valid && data.mx_found && !data.disposable);
    return new Response(JSON.stringify({
      ok: true,
      skipped: false,
      valid,
      format_valid: Boolean(data.format_valid),
      mx_found: Boolean(data.mx_found),
      smtp_check: data.smtp_check === true,
      disposable: data.disposable === true,
      free: data.free === true,
      score: typeof data.score === 'number' ? data.score : null,
      did_you_mean: data.did_you_mean || null,
      error: valid ? null : 'This email address could not be verified. Please check it and try again.',
    }), { status: 200, headers: { 'content-type': 'application/json' } });
  } catch (error) {
    // Email validation must never make the whole product unusable when the third-party API is down.
    return new Response(JSON.stringify({ ok: true, skipped: true, reason: 'Mailboxlayer temporarily unavailable' }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  }
};
